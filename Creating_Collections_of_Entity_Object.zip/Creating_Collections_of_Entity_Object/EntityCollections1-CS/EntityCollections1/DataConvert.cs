﻿using System;

namespace EntityCollections
{
  public class DataConvert
  {
    public static T ConvertTo<T>(object value, object defaultValue) where T : struct
    {
      if (value.Equals(DBNull.Value))
        return (T)defaultValue;
      else
        return (T)value;
    }
  }
}
