﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Documents;

namespace EntityCollections
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnDataTable_Click(object sender, RoutedEventArgs e)
    {
      lstData.DataContext = GetProducts();
    }

    public List<Product> GetProducts()
    {
      List<Product> ret = new List<Product>();
      Product entity;
      SqlDataAdapter da;
      DataTable dt = new DataTable();

      da = new SqlDataAdapter("SELECT * FROM Product",
        "Server=Localhost;Database=Sandbox;Integrated Security=Yes");

      da.Fill(dt);

      foreach (DataRow dr in dt.Rows)
      {
        entity = new Product();

        // ProductId is a NOT NULL field
        entity.ProductId = Convert.ToInt32(dr["ProductId"]);
        // Strings automatically convert to "" if null.
        entity.ProductName = dr["ProductName"].ToString();
        entity.IntroductionDate =
                DataConvert.ConvertTo<DateTime>(dr["IntroductionDate"],
                  default(DateTime));
        entity.Cost =
                DataConvert.ConvertTo<decimal>(dr["Cost"],
                  default(decimal));
        entity.Price =
                DataConvert.ConvertTo<decimal>(dr["Price"],
                  default(decimal));
        entity.IsDiscontinued =
                DataConvert.ConvertTo<bool>(dr["IsDiscontinued"],
                  default(bool));

        ret.Add(entity);
      }

      return ret;
    }
  }
}