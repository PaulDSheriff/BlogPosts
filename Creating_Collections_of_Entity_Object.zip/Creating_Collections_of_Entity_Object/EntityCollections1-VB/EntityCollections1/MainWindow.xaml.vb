﻿Imports System.Data.SqlClient
Imports System.Data

Class MainWindow

  Private Sub btnDataTable_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnDataTable.Click
    lstData.DataContext = GetProducts()
  End Sub

  Public Function GetProducts() As List(Of Product)
    Dim ret As New List(Of Product)()
    Dim entity As Product
    Dim da As SqlDataAdapter
    Dim dt As New DataTable()

    da = New SqlDataAdapter("SELECT * FROM Product", "Server=Localhost;Database=Sandbox;Integrated Security=Yes")

    da.Fill(dt)

    For Each dr As DataRow In dt.Rows
      entity = New Product()

      ' ProductId is a NOT NULL field
      entity.ProductId = Convert.ToInt32(dr("ProductId"))
      ' Strings automatically convert to "" if null.
      entity.ProductName = dr("ProductName").ToString()
      entity.IntroductionDate = DataConvert.ConvertTo(Of DateTime)(dr("IntroductionDate"), DateTime.MinValue)
      entity.Cost = DataConvert.ConvertTo(Of Decimal)(dr("Cost"), 0D)
      entity.Price = DataConvert.ConvertTo(Of Decimal)(dr("Price"), 0D)
      entity.IsDiscontinued = DataConvert.ConvertTo(Of Boolean)(dr("IsDiscontinued"), False)

      ret.Add(entity)
    Next

    Return ret
  End Function
End Class
