﻿Public Class Product
  Public Property ProductId As Integer
  Public Property ProductName As String
  Public Property IntroductionDate As DateTime
  Public Property Cost As Decimal
  Public Property Price As Decimal
  Public Property IsDiscontinued As Boolean
End Class
