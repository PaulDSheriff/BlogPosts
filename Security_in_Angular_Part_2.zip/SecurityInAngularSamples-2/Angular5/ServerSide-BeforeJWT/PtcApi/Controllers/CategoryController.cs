using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PtcApi.Model;

namespace PtcApi.Controllers
{
  [Route("api/[controller]")]
  public class CategoryController : Controller
  {
    // GET api/values
    [HttpGet]
    public IActionResult Get()
    {
      List<Category> list = new List<Category>();

      list.Add(new Category() { CategoryId = 1, CategoryName = "Services" });
      list.Add(new Category() { CategoryId = 2, CategoryName = "Training" });
      list.Add(new Category() { CategoryId = 3, CategoryName = "Information" });
    
      return StatusCode(StatusCodes.Status200OK, list);
    }
  }
}
