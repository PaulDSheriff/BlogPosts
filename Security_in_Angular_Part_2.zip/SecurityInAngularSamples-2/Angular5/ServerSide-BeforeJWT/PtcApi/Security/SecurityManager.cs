using System;
using System.Collections.Generic;
using System.Linq;
using PtcApi.Model;

namespace PtcApi.Security
{
  public class SecurityManager
  {
    private AppUser _user = null;
    private AppUserAuth _auth = null;

    public AppUserAuth ValidateUser(AppUser user)
    {
      // Assign current user
      _user = user;

      // Attempt to validate user
      _user = CreateMockUsers().Where(
        u => u.UserName.ToLower() == _user.UserName.ToLower()
        && u.Password == _user.Password).FirstOrDefault();

      // Build User Security Object
      BuildUserAuthObject();

      return _auth;
    }

    protected void BuildUserAuthObject()
    {
      if (_user != null)
      {
        _auth = CreateMockSecurityObjects()
          .Where(u => u.UserName == _user.UserName).FirstOrDefault();
      }

      if (_auth == null)
      {
        _auth = new AppUserAuth();
      }
    }

    private List<AppUser> CreateMockUsers()
    {
      List<AppUser> list = new List<AppUser>();

      list.Add(new AppUser()
      {
        UserId = 1,
        UserName = "PSheriff",
        Password = "P@ssw0rd"
      });
      list.Add(new AppUser()
      {
        UserId = 2,
        UserName = "Bjones",
        Password = "P@ssw0rd"
      });

      return list;
    }

    private List<AppUserAuth> CreateMockSecurityObjects()
    {
      List<AppUserAuth> list = new List<AppUserAuth>();

      list.Add(new AppUserAuth()
      {
        UserName = "PSheriff",
        BearerToken = "abi393kdkd9393ikd",
        IsAuthenticated = true,
        CanAccessProducts = true,
        CanAddProduct = true,
        CanSaveProduct = true,
        CanAccessCategories = true,
        CanAddCategory = false
      });
      list.Add(new AppUserAuth()
      {
        UserName = "Bjones",
        BearerToken = "sd9f923k3kdmcjkhd",
        IsAuthenticated = true,
        CanAccessProducts = true,
        CanAddProduct = false,
        CanSaveProduct = false,
        CanAccessCategories = true,
        CanAddCategory = true
      });

      return list;
    }
  }
}
