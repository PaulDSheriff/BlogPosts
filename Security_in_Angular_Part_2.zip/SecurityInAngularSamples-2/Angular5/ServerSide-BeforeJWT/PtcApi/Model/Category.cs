using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PtcApi.Model
{
  public partial class Category
  {
    public int CategoryId { get; set; }

    public string CategoryName { get; set; }
  }
}
