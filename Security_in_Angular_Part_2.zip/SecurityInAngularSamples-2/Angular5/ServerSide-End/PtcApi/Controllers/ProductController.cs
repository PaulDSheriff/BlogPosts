﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using PtcApi.Model;
using Microsoft.AspNetCore.Authorization;

namespace PtcApi.Controllers
{
  [Route("api/[controller]")]
  public class ProductController : Controller
  {
    [HttpGet]
    [Authorize(Policy = "CanAccessProducts")]
    public IActionResult Get()
    {
      List<Product> list = new List<Product>();

      list = CreateMockProducts();

      return StatusCode(StatusCodes.Status200OK, list);
    }

    [HttpGet("{id}", Name = "Get")]
    public IActionResult Get(int id)
    {
      IActionResult ret = null;
      Product entity = null;
      List<Product> list = new List<Product>();

      list = CreateMockProducts();
      entity = list.Where(p => p.ProductId == id).FirstOrDefault();
      if (entity != null)
      {
        ret = StatusCode(StatusCodes.Status200OK, entity);
      }
      else
      {
        ret = StatusCode(StatusCodes.Status404NotFound, "Can't find product: " + id.ToString());
      }

      return ret;
    }

    [HttpPost()]
    public IActionResult Post([FromBody]Product entity)
    {
      List<Product> list = new List<Product>();

      list = CreateMockProducts();
      list.Add(entity);

      return StatusCode(StatusCodes.Status200OK, entity); ;
    }

    public List<Product> CreateMockProducts()
    {
      List<Product> list = new List<Product>();

      list.Add(new Product()
      {
        ProductId = 1,
        ProductName = "Building Business Components using Angular",
        IntroductionDate = Convert.ToDateTime("1/23/2017"),
        Price = 20,
        Url = "http://bit.ly/2k5ogPH",
        CategoryId = 2
      });
      list.Add(new Product()
      {
        ProductId = 2,
        ProductName = "The Journey from MVC to Angular",
        IntroductionDate = Convert.ToDateTime("7/22/2016"),
        Price = 20,
        Url = "http =//bit.ly/2a3wVNU",
        CategoryId = 2
      });
      list.Add(new Product()
      {
        ProductId = 3,
        ProductName = "Build an HTML Helper Library for ASP.NET MVC 5",
        IntroductionDate = Convert.ToDateTime("1/05/2016"),
        Price = 20,
        Url = "http =//bit.ly/1myXBwj",
        CategoryId = 2
      });
      list.Add(new Product()
      {
        ProductId = 4,
        ProductName = "Mentoring Services",
        IntroductionDate = Convert.ToDateTime("3/01/1991"),
        Price = 200,
        Url = "http =//www.fairwaytech.com",
        CategoryId = 1
      });

      return list;
    }
  }
}
