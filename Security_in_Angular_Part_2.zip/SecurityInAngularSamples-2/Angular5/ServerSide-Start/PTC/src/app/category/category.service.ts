import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Category } from './category';
import { of } from 'rxjs/observable/of';
import { CATEGORIES_MOCK } from './categories-mock';
import { HttpClient } from '@angular/common/http';

const API_URL = "http://localhost:5000/api/category/";

@Injectable()
export class CategoryService {

  constructor(private http: HttpClient) { }
  
  getCategories(): Observable<Category[]> {
    return this.http.get<Category[]>(API_URL);
  }  
}
