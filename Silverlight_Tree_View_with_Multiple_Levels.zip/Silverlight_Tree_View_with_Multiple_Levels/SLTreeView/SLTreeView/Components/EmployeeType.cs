﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SLTreeView
{
public class EmployeeType
{
  public EmployeeType(string empType)
  {
    EmpType = empType;
    Employees = new List<Employee>();
  }

  public string EmpType { get; set; }
  public List<Employee> Employees { get; set; }
}

public class EmployeeTypes : List<EmployeeType>
{
  public EmployeeTypes()
  {
    EmployeeType type;
        
    type = new EmployeeType("Manager");
    type.Employees.Add(new Employee("Michael"));
    type.Employees.Add(new Employee("Paul"));
    this.Add(type);

    type = new EmployeeType("Project Managers");
    type.Employees.Add(new Employee("Tim"));
    type.Employees.Add(new Employee("John"));
    type.Employees.Add(new Employee("David"));
    this.Add(type);
  }
}
}
