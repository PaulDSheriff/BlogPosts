﻿Silverlight Tree View with 3 Levels
-------------------------------------------------------

When creating a hierarchy you need to think backwards when laying out your data templates.

For example, given this hierarchy:
  - EmployeeTypes  (Has a property called Employees)
      - Employees     (Has a property called ManagedEmployees)
          - ManagedEmployee

Your last leaf node in the hierarchy (Sub-Employee) should just be a <DataTemplate> and needs to be the first template listed in your resource area.

<DataTemplate x:Key="managedEmployeeTemplate">
   <TextBlock Text="{Binding Path=SubName}" />
</DataTemplate>

Next, you layout a HierarchicalDataTemplate for the next level up which is Employees

<sdk:HierarchicalDataTemplate x:Key="employeeTemplate"
                              ItemsSource="{Binding ManagedEmployees}"
                              ItemTemplate="{StaticResource managedEmployeeTemplate}">
  <TextBlock Text="{Binding Path=Name}" />
</sdk:HierarchicalDataTemplate>

The ItemTemplate for this is the 'managedEmployeeTemplate' which is the <DataTemplate> you first created.
The ItemsSource is bound to the ManagedEmployees property of the Employees class

Now, you can layout your top level hierarchy for the Employee Types

<sdk:HierarchicalDataTemplate x:Key="employeeTypeTemplate"
                              ItemsSource="{Binding Employees}"
                              ItemTemplate="{StaticResource employeeTemplate}">
  <TextBlock Text="{Binding Path=EmpType}" />
</sdk:HierarchicalDataTemplate>

The ItemTemplate for this is 'employeeTemplate' which is the previous HierarchicalDataTemplate.
The ItemsSource is bound to the Employees property of the EmployeeTypes class
