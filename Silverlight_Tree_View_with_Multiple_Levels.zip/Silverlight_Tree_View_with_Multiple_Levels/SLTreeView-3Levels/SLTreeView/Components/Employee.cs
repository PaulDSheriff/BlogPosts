﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SLTreeView
{
  public class Employee
  {
    public Employee(string name)
    {
      Name = name;
      ManagedEmployees = new List<Employee>();
    }

    public string Name { get; set; }
    public List<Employee> ManagedEmployees { get; set; }
  }
}
