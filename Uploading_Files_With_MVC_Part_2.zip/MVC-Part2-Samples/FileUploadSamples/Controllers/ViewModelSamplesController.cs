﻿using System.Web.Mvc;
using FileUploadSamples.ViewModels;

namespace FileUploadSamples.Controllers
{
  public class ViewModelSamplesController : Controller
  {
    #region Sample 1
    public ActionResult Sample01()
    {
      VMSample01ViewModel vm = new VMSample01ViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Sample01(VMSample01ViewModel vm)
    {
      // Set file info properties from file upload control
      vm.SetFileInfoProperties();

      // Look at properties of View Model
      System.Diagnostics.Debugger.Break();

      // TODO: Do something with the file data

      return View(vm);
    }
    #endregion

    #region Sample 2
    public ActionResult Sample02()
    {
      VMSample02ViewModel vm = new VMSample02ViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Sample02(VMSample02ViewModel vm)
    {
      // Set file info properties from file upload control
      vm.SetFileInfoProperties();

      // Look at properties of View Model
      System.Diagnostics.Debugger.Break();

      // TODO: Do something with the file data

      return View(vm);
    }
    #endregion
  }
}