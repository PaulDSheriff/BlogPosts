﻿Before Using This Sample
------------------------
Open the Web.config file and modify the path to the .mdf file located in the App_Data folder in this project.
Or, create a SQL Server database and use the .sql file located in the \SqlScripts folder and modify the connection string


\StyleSamples
------------------------
Sample01.cshmtl - Normal look and feel of file upload control
Sample02.cshmtl - Style file upload control as a button
Sample03.cshmtl - Style file upload control as a text box and a glyph
                - Get the file uploaded, plus other file information


\ViewModelSamples
------------------------
Sample01.cshmtl - Use a view model, use method to gather file info properties
Sample02.cshmtl - Use a FileUpload class


\ThumbnailSamples
------------------------
Sample01.cshmtl - Create a thumbnail, use a view model base class


\FileStorageSamples
------------------------
Sample01.cshmtl - Store images on file system


\SQLServerSamples
------------------------
Sample01.cshmtl - Store images in an SQL Server table


\ExceptionSamples
------------------------
Sample01.cshmtl - Store images in an SQL Server table
\Errors\FileTooBig.cshtml - Page displayed if file uploaded is too large


\FileUpload
------------------------
FileUploadList.cshtml - Display list of files from SQL Server
FileUploadDetail.cshtml
  - Insert file data into SQL Server
  - Create a thumbnail of an image
  - Display image retrieved from SQL Server


Notes
--------------------------
'name' attribute must be set on file upload input
  The 'name' attribute must match the parameter name on the controller method
Must add the attribute to the form when uploading input
  enctype="multipart/form-data"
