﻿using System;
using System.IO;
using System.Web;
using FileUploadSamples.Components;
using FileUploadSamples.Models;

namespace FileUploadSamples.ViewModels
{
  public class ExceptionsViewModel
  {
    #region Constructor
    public ExceptionsViewModel()
    {
      FileUploadInfo = new FileUpload();
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the maximum file upload size
    /// </summary>
    public int MaxFileUploadSize { get; set; }
    /// <summary>
    /// Get/Set file upload information
    /// </summary>
    public FileUpload FileUploadInfo { get; set; }

    /// <summary>
    /// Get/Set HTTP File Input Object
    /// </summary>
    public HttpPostedFileBase FileToUpload { get; set; }
    #endregion

    #region SetFileInfoProperties Method
    public void SetFileInfoProperties()
    {
      if (FileToUpload != null && FileToUpload.ContentLength > 0) {
        // Get the uploaded file
        using (MemoryStream ms = new MemoryStream()) {
          FileToUpload.InputStream.CopyTo(ms);
          FileUploadInfo.Contents = ms.ToArray();
        }

        // Fill in other file information
        FileUploadInfo.ContentLength = FileToUpload.ContentLength;
        FileUploadInfo.ContentType = FileToUpload.ContentType;
        FileUploadInfo.FilePath = Path.GetDirectoryName(FileToUpload.FileName);
        FileUploadInfo.FileName = Path.GetFileName(FileToUpload.FileName);
      }
    }
    #endregion

    #region CreateThumbnail Method
    public void CreateThumbnail()
    {
      ImageThumbnailConverter conv = new ImageThumbnailConverter();

      // Create thumbnail
      FileUploadInfo.Thumbnail = conv.ConvertToThumbnail(FileUploadInfo.Contents, FileUploadInfo.ContentType);
    }
    #endregion

    #region SetServerUrlProperties Method
    public void SetServerUrlProperties()
    {
      string date;

      date = DateTime.Now.ToString("s").Replace(":", "-");

      FileUploadInfo.ServerUrl = AppSettings.UploadFolderName + date + "-" + FileUploadInfo.FileName;
      FileUploadInfo.ServerThumbnailUrl = AppSettings.UploadFolderName + date + "-thumbnail-" + FileUploadInfo.FileName;
    }
    #endregion

    #region Save Method
    public void Save()
    {
      // Set file info properties from file upload control
      SetFileInfoProperties();

      // Create thumbnail
      CreateThumbnail();

      // Set Server URL properties
      SetServerUrlProperties();

      // Save on file system
      SaveToFileSystem();

      // Save to SQL Server
      SaveToSQLServer();
    }
    #endregion

    #region SaveToFileSystem Method
    protected void SaveToFileSystem()
    {
      try {
        File.WriteAllBytes(HttpContext.Current.Server.MapPath(FileUploadInfo.ServerUrl), FileUploadInfo.Contents);
        File.WriteAllBytes(HttpContext.Current.Server.MapPath(FileUploadInfo.ServerThumbnailUrl), FileUploadInfo.Thumbnail);
      }
      catch (Exception ex) {
        System.Diagnostics.Debug.WriteLine(ex.ToString());
      }
    }
    #endregion

    #region SaveToSQLServer Method
    protected void SaveToSQLServer()
    {
      FileUploadDB db = null;

      try {
        using (db = new FileUploadDB()) {
          // Add file upload info object
          db.FileUploads.Add(FileUploadInfo);
          // Store into SQL Server
          db.SaveChanges();
        }
      }
      catch (Exception ex) {
        System.Diagnostics.Debug.WriteLine(ex.ToString());
      }
    }
    #endregion
  }
}