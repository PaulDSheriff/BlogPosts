﻿using System;
using System.Configuration;
using System.Web.Configuration;
using System.Web.Mvc;
using FileUploadSamples.ViewModels;

namespace FileUploadSamples.Controllers
{
  public class ExceptionSamplesController : Controller
  {
    #region Sample 1
    public ActionResult Sample01()
    {
      ExceptionsViewModel vm = new ExceptionsViewModel();

      vm.MaxFileUploadSize = GetMaxFileUploadSize();

      return View(vm);
    }

    private int GetMaxFileUploadSize()
    {
      int maxRequestLength = 4096;  // Default size
      HttpRuntimeSection section = ConfigurationManager.GetSection("system.web/httpRuntime") as HttpRuntimeSection;
      if (section != null) {
        maxRequestLength = section.MaxRequestLength;
      }

      return Convert.ToInt32(maxRequestLength / 1024);
    }

    [HttpPost]
    public ActionResult Sample01(ExceptionsViewModel vm)
    {
      // Store to SQL Server
      vm.Save();

      // Look in SQL Server for the new uploaded file
      System.Diagnostics.Debugger.Break();

      // TODO: Do something with the file data

      return View(vm);
    }
    #endregion
  }
}