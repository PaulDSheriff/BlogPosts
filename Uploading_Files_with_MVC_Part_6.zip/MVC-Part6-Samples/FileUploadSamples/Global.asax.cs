﻿using System;
using System.Web;
using System.Web.Management;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using FileUploadSamples.Components;

namespace FileUploadSamples
{
  public class MvcApplication : System.Web.HttpApplication
  {
    protected void Application_Start()
    {
      AreaRegistration.RegisterAllAreas();
      FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
      RouteConfig.RegisterRoutes(RouteTable.Routes);
      BundleConfig.RegisterBundles(BundleTable.Bundles);

      // Load default values from config file
      AppSettings.LoadDefaults();

      // Set full path for 'No Preview' image
      AppSettings.NoPreviewFileName = Server.MapPath(AppSettings.NoPreviewFileName);
    }

    protected void Application_Error(object sender, EventArgs e)
    {
      // Get last server error
      HttpException err = Server.GetLastError() as HttpException;
      // Is the error because the file posted is too large?
      if (err != null &&
          err.WebEventCode == WebEventCodes.RuntimeErrorPostTooLarge) {
        // Clear server error
        Server.ClearError();
        // Redirect to a "File too Big" page
        ((HttpApplication)sender).Context.Response.Redirect("~/Errors/FileTooBig");
      }
    }
  }
}
