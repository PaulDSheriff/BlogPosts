﻿using UploadVMSample.EntityClasses;

namespace UploadVMSample.ViewModelClasses;

public class FileSystemViewModel : FileUploadViewModelBase
{
  /// <summary>
  /// Save to Server File System 
  /// </summary>
  /// <returns>A Task with true=successful, false=unsuccessful</returns>
  protected override async Task<bool> SaveToDataStoreAsync()
  {
    bool ret = false;

    if (FileToUpload != null) {
      // Set Server Location to Store File
      FileInfo.ServerLocation = UploadSettings.UploadFolderPath + @"\";

      if (FileInfo.Type.StartsWith("image")) {
        // Create a random file name for this new file
        // Leave the file extension in place if it is an image file
        string ext = Path.GetExtension(FileInfo.FileName).ToLower();
        string fileName = Path.GetFileNameWithoutExtension(Path.GetRandomFileName());
        FileInfo.FileNameOnServer = Path.Combine(FileInfo.ServerLocation, fileName + ext);
      }
      else {
        // Create a random file name for this new file
        FileInfo.FileNameOnServer = Path.Combine(FileInfo.ServerLocation, Path.GetRandomFileName());
      }

      // Create a stream to write the file to
      using var stream = File.Create(FileInfo.FileNameOnServer);

      // Upload file and copy to the stream
      await FileToUpload.CopyToAsync(stream);

      ret = true;
    }

    return ret;
  }
}
