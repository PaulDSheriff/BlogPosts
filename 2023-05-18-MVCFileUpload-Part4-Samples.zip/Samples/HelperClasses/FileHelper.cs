﻿namespace UploadVMSample.HelperClasses;

public static class FileHelper
{
  public enum FileSizeUnits
  {
    Byte, KB, MB, GB, TB, PB, EB, ZB, YB
  }

  public static string ConvertSizeUnits(long value, FileSizeUnits unit)
  {
    return (value / (double)Math.Pow(1024, (long)unit)).ToString("0") + unit.ToString();
  }
}
