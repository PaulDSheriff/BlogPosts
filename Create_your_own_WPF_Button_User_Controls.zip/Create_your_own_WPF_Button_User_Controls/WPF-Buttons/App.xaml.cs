﻿using System.Windows;

namespace WPF_Buttons
{
  public partial class App : Application
  {
  }
}
