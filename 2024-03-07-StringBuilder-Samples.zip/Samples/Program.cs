﻿using System.Text;

StringBuilder sb = new();
// StringBuilder sb = new(200);
// StringBuilder sb = new("Acme Anvil");
// StringBuilder sb = new("Acme Anvil", 200);
sb.Append("The answer is always 42.");
sb.AppendLine("Line 1");
sb.AppendLine("Line 2");
sb.AppendLine("Line 3");

string name = "Acme Anvil";
decimal price = 99.99M;

sb.AppendFormat(
  "{0} is selling for {1:c}", name, price);
// sb.Append($"{name} is selling for {price:c}");

string value = sb.ToString();
Console.WriteLine(value);
// Console.WriteLine(sb.ToString());
// Console.WriteLine(sb);

string[] names = ["Acme Anvil", "Acme Rocket Skates"];
sb.AppendJoin(", ", names);

List<string> nameList = ["Acme Bazooka", "Acme Rocket Skates"];
sb.AppendJoin(", ", nameList);

// Search & Replace
sb.Replace("Line ", "New Line ");

DisplaySBInfo(sb);

sb.Clear();
Console.WriteLine();

DisplaySBInfo(sb);


// Call to display StringBuilder information
void DisplaySBInfo(StringBuilder sb)
{
  // Number of characters preallocated
  Console.WriteLine($"Capacity = {sb.Capacity}");
  // Total number of characters it can hold
  Console.WriteLine($"Max Capacity = {sb.MaxCapacity}");
  // Number of characters in the buffer
  Console.WriteLine($"Length = {sb.Length}");
}
