﻿using System.Collections.Generic;

namespace BootstrapRadio2
{
  public class MusicGenreViewModel
  {
    #region Constructor
    public MusicGenreViewModel()
    {
      Genres = new List<MusicGenre>();
      LoadGenres();
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the collection of Music Genres
    /// </summary>
    public List<MusicGenre> Genres { get; set; }
    /// <summary>
    /// Get/Set the Selected ID
    /// </summary>
    public int SelectedId { get; set; }
    #endregion

    #region LoadGenres Method
    public void LoadGenres()
    {
      MusicGenreManager mgr = new MusicGenreManager();

      // Get list of Music Genres
      Genres = mgr.Genres;
    }
    #endregion
  }
}
