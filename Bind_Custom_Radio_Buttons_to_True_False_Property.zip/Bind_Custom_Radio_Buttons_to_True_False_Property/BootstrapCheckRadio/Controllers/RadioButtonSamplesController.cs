﻿using System.Web.Mvc;

namespace BootstrapRadio2.Controllers
{
  public class RadioButtonSamplesController : Controller
  {
    public ActionResult Radio06()
    {
      Product entity = new Product();

      entity.IsDiscontinued = true;

      return View(entity);
    }

    [HttpPost]
    public ActionResult Radio06(Product entity)
    {
      System.Diagnostics.Debugger.Break();

      return View(entity);
    }

public ActionResult Radio07()
{
  MusicGenreViewModel vm = new MusicGenreViewModel();

  return View(vm);
}

[HttpPost]
public ActionResult Radio07(MusicGenreViewModel vm)
{
  MusicGenre entity;

  entity = vm.Genres.Find(g => g.GenreId == vm.SelectedId);

  System.Diagnostics.Debugger.Break();

  return View(vm);
}
  }
}