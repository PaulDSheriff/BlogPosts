﻿using ADONET_Samples.DataLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;

namespace ADONET_Samples.ViewModels
{
  public class DataReaderViewModel : ViewModelBase
  {
    #region Private Variables
    private List<Product> _Products = new List<Product>();
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set Products collection
    /// </summary>
    public List<Product> Products
    {
      get { return _Products; }
      set {
        _Products = value;
        RaisePropertyChanged("Products");
      }
    }
    #endregion

    #region GetProductsUsingDataReader Method
    public List<Product> GetProductsUsingDataReader()
    {
      List<Product> ret = new List<Product>();

      System.Diagnostics.Stopwatch stopWatch = new System.Diagnostics.Stopwatch();
      stopWatch.Start();

      // Create a connection
      using (SqlConnection cnn = new SqlConnection(AppSettings.ConnectionString)) {
        // Create command object
        using (SqlCommand cmd = new SqlCommand("SELECT * FROM SalesLT.Product", cnn)) {
          // Open the connection
          cnn.Open();

          using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)) {
            while (dr.Read()) {
              ret.Add(new Product
              {
                // NOTE: GetFieldValue() does not work on nullable fields
                ProductID = dr.GetFieldValue<int>(dr.GetOrdinal("ProductID")),
                Name = dr.GetFieldValue<string>(dr.GetOrdinal("Name")),
                ProductNumber = dr.GetFieldValue<string>(dr.GetOrdinal("ProductNumber")),
                Color = dr.IsDBNull(dr.GetOrdinal("Color")) ? (string)null : Convert.ToString(dr["Color"]),
                StandardCost = dr.GetFieldValue<decimal>(dr.GetOrdinal("StandardCost")),
                ListPrice = dr.GetFieldValue<decimal>(dr.GetOrdinal("ListPrice")),
                Size = dr.IsDBNull(dr.GetOrdinal("Size")) ? (string)null : Convert.ToString(dr["Size"]),
                Weight = dr.IsDBNull(dr.GetOrdinal("Weight")) ? (decimal?)null : Convert.ToDecimal(dr["Weight"]),
                ProductCategoryID = dr.IsDBNull(dr.GetOrdinal("ProductCategoryID")) ? (int?)null : Convert.ToInt32(dr["ProductCategoryID"]),
                ProductModelID = dr.IsDBNull(dr.GetOrdinal("ProductModelID")) ? (int?)null : Convert.ToInt32(dr["ProductModelID"]),
                SellStartDate = dr.GetFieldValue<DateTime>(dr.GetOrdinal("SellStartDate")),
                SellEndDate = dr.IsDBNull(dr.GetOrdinal("SellEndDate")) ? (DateTime?)null : Convert.ToDateTime(dr["SellEndDate"]),
                DiscontinuedDate = dr.IsDBNull(dr.GetOrdinal("DiscontinuedDate")) ? (DateTime?)null : Convert.ToDateTime(dr["DiscontinuedDate"]),
                ModifiedDate = dr.GetFieldValue<DateTime>(dr.GetOrdinal("ModifiedDate")),
              });
            }
          }
        }
      }

      stopWatch.Stop();
      // Get the elapsed time as a TimeSpan value.
      TimeSpan ts = stopWatch.Elapsed;
      // Format and display the TimeSpan value.
      ResultText += "GetProductsUsingDataReader() - RunTime " + String.Format("{0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10) + Environment.NewLine;

      return ret;
    }
    #endregion

    #region GetProductsUsingGenericToList Method
    public List<Product> GetProductsUsingGenericToList()
    {      
      System.Diagnostics.Stopwatch stopWatch = new System.Diagnostics.Stopwatch();
      stopWatch.Start();

      // Create a connection
      using (SqlConnection cnn = new SqlConnection(AppSettings.ConnectionString)) {
        // Create command object
        using (SqlCommand cmd = new SqlCommand("SELECT * FROM SalesLT.Product", cnn)) {
          // Open the connection
          cnn.Open();

          using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)) {
            Products = ToList<Product>(dr);
          }
        }
      }

      stopWatch.Stop();
      // Get the elapsed time as a TimeSpan value.
      TimeSpan ts = stopWatch.Elapsed;
      // Format and display the TimeSpan value.
      ResultText += "GetProductsUsingGenericToList() - RunTime " + String.Format("{0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10) + Environment.NewLine;

      return Products;
    }
    #endregion

    #region GetProductsUsingGenericMethod Method
    public List<Product> GetProductsUsingGenericMethod()
    {
      System.Diagnostics.Stopwatch stopWatch = new System.Diagnostics.Stopwatch();
      stopWatch.Start();

      Products = GetRecords<Product>("SELECT * FROM SalesLT.Product", AppSettings.ConnectionString);

      stopWatch.Stop();
      // Get the elapsed time as a TimeSpan value.
      TimeSpan ts = stopWatch.Elapsed;
      // Format and display the TimeSpan value.
      ResultText += "GetProductsUsingGenericMethod() - RunTime " + String.Format("{0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10) + Environment.NewLine;

      return Products;
    }
    #endregion

    #region GetRecords Method
    public List<T> GetRecords<T>(string sql, string connectionString)
    {
      List<T> ret = new List<T>();

      // Create a connection
      using (SqlConnection cnn = new SqlConnection(connectionString)) {
        // Create command object
        using (SqlCommand cmd = new SqlCommand(sql, cnn)) {
          // Open the connection
          cnn.Open();

          using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)) {
            ret = ToList<T>(dr);
          }
        }
      }

      return ret;
    }
    #endregion

    #region ToList Method
    public virtual List<T> ToList<T>(IDataReader rdr)
    {
      List<T> ret = new List<T>();
      T entity;
      Type typ = typeof(T);
      PropertyInfo col;
      List<PropertyInfo> columns = new List<PropertyInfo>();

      // Get all the properties in Entity Class
      PropertyInfo[] props = typ.GetProperties();

      // Loop through one time to map columns to properties
      // NOTES:
      //   Assumes your column names are the same name as your class property names
      //   Any properties not in the data reader column list are not set
      for (int index = 0; index < rdr.FieldCount; index++) {
        // See if column name maps directly to property name
        col = props.FirstOrDefault(c => c.Name == rdr.GetName(index));
        if (col != null) {
          columns.Add(col);
        }
      }

      // Loop through all records
      while (rdr.Read()) {
        // Create new instance of Entity
        entity = Activator.CreateInstance<T>();

        // Loop through columns to assign data
        for (int i = 0; i < columns.Count; i++) {
          if (rdr[columns[i].Name].Equals(DBNull.Value)) {
            columns[i].SetValue(entity, null, null);
          }
          else {
            columns[i].SetValue(entity, rdr[columns[i].Name], null);
          }
        }

        ret.Add(entity);
      }

      return ret;
    }
    #endregion
  }
}
