﻿using ADONET_Samples.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace ADONET_Samples.UserControls
{
  public partial class DataReaderControl : UserControl
  {
    public DataReaderControl()
    {
      InitializeComponent();

      _viewModel = (DataReaderViewModel)this.Resources["viewModel"];
    }

    private readonly DataReaderViewModel _viewModel;

    private void DataReader_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Products = _viewModel.GetProductsUsingDataReader();
    }

    private void GenericList_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetProductsUsingGenericToList();
    }

    private void GenericMethod_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetProductsUsingGenericMethod();
    }
  }
}
