﻿ADO.NET Samples
----------------------------------------------
DataReaderControl - Using the SqlDataReader
  - Hard-coded DataReader
  - DataReader to Generic List<Product>
  - DataReader using a Generic method and Generic List

NOTES
--------------------------------------
Data readers are read-only, forward-only cursors
Until you close a data reader, no other operations can be done on that connection