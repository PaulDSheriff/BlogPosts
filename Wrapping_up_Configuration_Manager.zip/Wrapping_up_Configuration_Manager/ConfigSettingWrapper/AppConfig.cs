﻿using System;
using System.Configuration;

namespace ConfigSettingWrapper
{
public class AppConfig
{
  public string XmlPath { get; set; }
  public int DefaultType { get; set; }

  //private static AppConfig _Instance = null;

  //public static AppConfig Instance
  //{
  //  get
  //  {
  //    if (_Instance == null)
  //      _Instance = new AppConfig();

  //    return _Instance;
  //  }
  //  set
  //  {
  //    _Instance = value;
  //  }
  //}
 

  protected string GetSetting(string key)
  {
    return ConfigurationManager.AppSettings[key];
  }

  /// <summary>
  /// Get a Setting from the &lt;appSettings&gt; element in your .Config file
  /// </summary>
  /// <param name="key">The key to locate</param>
  /// <param name="defaultValue">The value to return if the value is not found.</param>
  /// <returns>A string value</returns>
  public string GetSetting(string key, string defaultValue)
  {
    string value;

    value = GetSetting(key);
    if (value == null)
      value = defaultValue;

    return value;
  }

  /// <summary>
  /// Get a Setting from the &lt;appSettings&gt; element in your .Config file
  /// </summary>
  /// <param name="key">The key to locate</param>
  /// <param name="defaultValue">The value to return if the value is not found.</param>
  /// <returns>A string value</returns>
  public int GetSetting(string key, int defaultValue)
  {
    int ret;
    string value;

    value = GetSetting(key);
    if (value == null)
      ret = defaultValue;
    else
      ret = Convert.ToInt32(value);

    return ret;
  }
}
}
