﻿using System.Windows;

namespace WPF_ButtonImageText
{
  public partial class App : Application
  {
  }
}
