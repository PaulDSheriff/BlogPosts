﻿Upload Multiple Files Asynchronously
---------------------------------------
These samples show how to upload multiple files asynchronously and display a progress bar

Sample01 - Upload multiple files
Sample02 - Add title and description on client
  Modified controller to get title and description information

Sample03 - Upload to Server, Generate Thumbnail, update title and description and send back to server to match up with each picture