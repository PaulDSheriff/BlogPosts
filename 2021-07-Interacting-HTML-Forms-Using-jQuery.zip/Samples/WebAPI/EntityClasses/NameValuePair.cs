namespace WebAPI {
  public class NameValuePair {
    public string Name { get; set; }
    public string Value { get; set; }
  }
}
