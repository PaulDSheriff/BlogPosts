﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Newtonsoft.Json.Serialization;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace PTC
{
  public class MvcApplication : System.Web.HttpApplication
  {
    protected void Application_Start() {
      AreaRegistration.RegisterAllAreas();
      FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);

      // Add Web API
      GlobalConfiguration.Configure(WebApiConfig.Register);

      RouteConfig.RegisterRoutes(RouteTable.Routes);
      BundleConfig.RegisterBundles(BundleTable.Bundles);

      // Get Global Configuration
      HttpConfiguration config =
            GlobalConfiguration.Configuration;

      // Convert to camelCase
      var jsonFormatter = config.Formatters
        .OfType<JsonMediaTypeFormatter>()
          .FirstOrDefault();

      jsonFormatter.SerializerSettings
        .ContractResolver = new
            CamelCasePropertyNamesContractResolver();
    }
  }
}
