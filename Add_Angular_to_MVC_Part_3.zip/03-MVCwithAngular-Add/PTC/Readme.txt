﻿Once you load this project, right mouse click on the package.json and select the "Restore Packages" menu.

Create the Product table in a SQL Server database by running the script in the \SqlScripts folder.
Update the connection string in Web.config to point to your server and database name.