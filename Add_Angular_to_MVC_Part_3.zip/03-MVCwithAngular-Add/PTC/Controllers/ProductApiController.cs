﻿using PTC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.ModelBinding;

namespace PTC.Controllers
{
  public class ProductApiController : ApiController
  {
    public IHttpActionResult Get() {
      IHttpActionResult ret;
      ProductViewModel vm = new ProductViewModel();

      vm.LoadProducts();
      if (vm.Products.Count() > 0) {
        ret = Ok(vm.Products);
      }
      else {
        ret = NotFound();
      }

      return ret;
    }

    [HttpPost()]
    public IHttpActionResult Post(Product product) {
      IHttpActionResult ret = null;
      ProductViewModel vm = new ProductViewModel();

      if (product != null) {
        if (vm.Insert(product)) {
          ret = Created<Product>(
                Request.RequestUri +
                vm.Entity.ProductId.ToString(),
                  vm.Entity);
        }
        else {
          if (vm.Messages.Count > 0) {
            ret = BadRequest(ConvertMessagesToModelState(vm.Messages));
          }
          else if (vm.LastException != null) {
            ret = InternalServerError(vm.LastException);
          }
        }
      }
      else {
        ret = NotFound();
      }

      return ret;
    }

    private ModelStateDictionary ConvertMessagesToModelState(List<KeyValuePair<string, string>> messages) {
      ModelStateDictionary ret = new ModelStateDictionary();

      foreach (KeyValuePair<string, string> msg in messages) {
        ret.AddModelError(msg.Key, msg.Value);
      }

      return ret;
    }
  }
}