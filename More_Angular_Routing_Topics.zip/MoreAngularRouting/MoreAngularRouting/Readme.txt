﻿\app folder
-----------------------------------------
All the samples are located in this folder

\sample01 - Add controller for 2nd page
\sample02 - Using controllerAs

\sample03 - Pass parameter to a route
\sample04 - Use $location.path() to navigate to a route
