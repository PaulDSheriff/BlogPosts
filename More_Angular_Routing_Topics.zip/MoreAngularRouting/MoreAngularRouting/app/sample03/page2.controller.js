﻿(function () {
  'use strict';
  
  angular.module('app')
   .controller('Page2Controller', Page2Controller);

  function Page2Controller($routeParams) {
    var vm = this;
    vm.message = '';

    if ($routeParams.id) {
      vm.message = 'The id passed in was: ' + $routeParams.id;
    }

    if ($routeParams.extraText) {
      vm.message = vm.message + ', extraText=' + $routeParams.extraText;
    }

    if (!vm.message) {
      vm.message = 'Page 2 says \'Hello\'';
    }
  }
})();