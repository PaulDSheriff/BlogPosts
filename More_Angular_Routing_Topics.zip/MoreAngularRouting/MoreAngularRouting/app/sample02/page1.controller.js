﻿(function () {
  'use strict';
  
  angular.module('app')
   .controller('Page1Controller', Page1Controller);

  function Page1Controller() {
    var page1 = this;

    page1.message = 'Hello from Page One!';
  }
})();