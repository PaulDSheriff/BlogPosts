﻿(function () {
  'use strict';

  angular.module('app', ['ngRoute']);

  angular.module('app')
    .config(function ($routeProvider) {
      $routeProvider
      .when('/',
      {
        template: ''
      })
      .when('/page1',
      {
        templateUrl: 'page1.template.html',
        controllerAs: 'page1',
        controller: 'Page1Controller'
      })
      .when('/page2',
      {
        templateUrl: 'page2.template.html',
        controllerAs: 'page2',
        controller: 'Page2Controller'
      })
      .otherwise(
      {
        redirectTo: '/'
      });
    });
})();