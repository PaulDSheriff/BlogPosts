﻿(function () {
  'use strict';
  
  angular.module('app')
   .controller('IndexController', IndexController);

  function IndexController() {
   
  }
})();