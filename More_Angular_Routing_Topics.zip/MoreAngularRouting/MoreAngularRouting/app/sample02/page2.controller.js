﻿(function () {
  'use strict';
  
  angular.module('app')
   .controller('Page2Controller', Page2Controller);

  function Page2Controller() {
    // NOTE: You don't need to use the same variable name 
    // you used in the 'controllerAs'
    var vm = this;

    vm.message = 'Page 2 says \'Hello\'';
  }
})();