﻿(function () {
  'use strict';
  
  angular.module('app')
   .controller('Page2Controller', Page2Controller);

  function Page2Controller($routeParams) {
    var vm = this;

    if ($routeParams.id) {
      vm.message = 'The id passed in was: ' + $routeParams.id;
    }
    else {
      vm.message = 'Page 2 says \'Hello\'';
    }
  }
})();