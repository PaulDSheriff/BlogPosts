﻿(function () {
  'use strict';
  
  angular.module('app')
   .controller('IndexController', IndexController);

  function IndexController($location) {
    var vm = this;

    vm.page1 = page1;
    vm.page2 = page2;
    
    function page1() {
      $location.path("/page1");
    }

    function page2() {
      $location.path("/page2");
    }
  }
})();