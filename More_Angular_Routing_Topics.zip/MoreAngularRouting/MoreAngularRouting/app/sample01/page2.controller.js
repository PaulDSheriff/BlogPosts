﻿(function () {
  'use strict';
  
  angular.module('app')
   .controller('Page2Controller', Page2Controller);

  // NOTE: Using $scope here because we did not use 
  // the 'controllerAs' property in the route object
  function Page2Controller($scope) {
    $scope.message = 'Page 2 says \'Hello\'';
  }
})();