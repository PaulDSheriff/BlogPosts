﻿(function () {
  'use strict';

  angular.module('ptcApp')
    .controller('PTCController', PTCController);

  function PTCController($scope) {
    var vm = $scope;
    
    // Expose a 'product' object
    vm.product = {
      ProductName: 'Pluralsight Subscription'
    };

    // Create a list of categories
    vm.categories = [
      { CategoryName: 'Videos' },
      { CategoryName: 'Books' },
      { CategoryName: 'Articles' }
    ];

    vm.products = [
      { ProductName: 'Video 1', Price: 10 },
      { ProductName: 'Video 2', Price: 10 },
      { ProductName: 'Book 1', Price: 20 },
      { ProductName: 'Article 1', Price: 5 },
      { ProductName: 'Article 2', Price: 6 },
    ];
  }
})();
