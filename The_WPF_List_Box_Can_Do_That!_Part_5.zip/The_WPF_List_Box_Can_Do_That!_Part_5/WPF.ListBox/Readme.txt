﻿This sample shows how to use grouping in a WPF ListBox.


\Samples-Grouping
-------------------------------------------------------
Sample01 - Grouping using XAML
Sample02 - Group using Code

Converters
-------------------------------------------------------
ProfitMarginAsStringConverter - Pass cost and price; returns the profit margin as a percentage in a string format
ProfitMarginGreaterThanConverter - Pass in cost, price and minimum profit margin; returns true if the profit margin calculated is greater than the minimum margin
