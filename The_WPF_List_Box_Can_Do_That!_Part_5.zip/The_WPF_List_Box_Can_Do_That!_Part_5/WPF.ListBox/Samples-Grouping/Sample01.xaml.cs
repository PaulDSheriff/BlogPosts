﻿using System.Windows.Controls;

namespace WPF.ListBox.Grouping
{
  public partial class Sample01 : UserControl
  {
    public Sample01()
    {
      InitializeComponent();
    }
  }
}
