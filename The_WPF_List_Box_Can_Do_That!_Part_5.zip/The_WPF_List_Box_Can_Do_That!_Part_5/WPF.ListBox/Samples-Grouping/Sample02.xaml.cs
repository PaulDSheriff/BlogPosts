﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace WPF.ListBox.Grouping
{
  public partial class Sample02 : UserControl
  {
    public Sample02()
    {
      InitializeComponent();
    }

    private void GroupTheData(object sender, RoutedEventArgs e)
    {
      if (ProductList != null) {
        ICollectionView dataView = CollectionViewSource.GetDefaultView(ProductList.ItemsSource);

        // Change sort order
        dataView.SortDescriptions.Clear();
        dataView.SortDescriptions.Add(new SortDescription((sender as RadioButton).Tag.ToString(),
          ListSortDirection.Descending));
        dataView.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));

        // Change group order
        dataView.GroupDescriptions.Clear();
        dataView.GroupDescriptions.Add(new PropertyGroupDescription((sender as RadioButton).Tag.ToString()));

        ProductList.ItemsSource = dataView;
      }
    }
  }
}
