﻿'use strict';

$(document).ready(function () {
  var content = $("[data-page-start]")[0].nodeName;
  var start = $(content).data('page-start');
  // Trigger home page
  window.location.replace(window.location.href + start);

  // Respond to changes in hash
  window.onhashchange = function () {
    spaController.changePage(content, window.location.hash);
  }
});

var spaController = (function () {
  // ************************************
  // Private Functions
  // ************************************
  function loadPage(contentArea, pageName) {
    // Use Ajax to retrieve partial page
    $.ajax({
      url: pageName + ".html",
      dataType: "html",
      success: function (html) {
        $(contentArea).html(html);
      },
      error: function (error) {
        console.log(error);
      }
    });
  }

  function changePage(contentArea, hashValue) {
    // Get path for partial page
    var path = $("a[href='" + hashValue + "']")
      .data("page-path") || "";
    // Remove # to create the page file name
    var pageName = hashValue.substr(1);
    // Remove any trailing data after the slash
    if (pageName.lastIndexOf("/") >= 0) {
      pageName = pageName.substring(0, pageName.lastIndexOf("/"));
    }
    // Load the partial HTML page
    loadPage(contentArea, path + pageName);
    // Set document title
    window.document.title = $("a[href='" + hashValue + "']").attr("title");
    // Reset menu focus
    resetMenu(hashValue);
  }

  function resetMenu(hashValue) {
    // Set focus to menu that matches current page
    $("a[href='" + hashValue + "']").focus();
    // Remove outline around anchor when setting focus
    $("a[href='" + hashValue + "']").css("outline", "0");
  }
  // ************************************
  // Public Functions
  // ************************************
  return {
    changePage: function (contentArea, hashValue) {
      changePage(contentArea, hashValue);
    }
  };
})();
