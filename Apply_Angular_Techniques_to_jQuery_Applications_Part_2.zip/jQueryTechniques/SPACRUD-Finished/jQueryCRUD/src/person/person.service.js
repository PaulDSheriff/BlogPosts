﻿// ************************************
// Person Service
// ************************************
var PersonService = (function () {
  const API_URL = "/api/Person/";

  function getAll(success, failure) {
    // Get list of data
    $.ajax({
      url: API_URL,
      type: 'GET',
      dataType: 'json'
    })
      .done(function (data) {
        success(data);
      })
      .fail(function (error) {
        if (failure) {
          failure(error);
        }
        else {
          console.log("Error Occurred: " + error);
        }
      });
  }

  function get(id, success, failure) {
    // Get a single row of data
    $.ajax({
      url: API_URL + id,
      type: 'GET',
      dataType: 'json'
    })
      .done(function (data) {
        success(data);
      })
      .fail(function (error) {
        if (failure) {
          failure(error);
        }
        else {
          console.log("Error Occurred: " + error);
        }
      });
  }

  function updateData(person, success, failure) {
    // Update single row of data
    $.ajax({
      url: API_URL + person.personId,
      type: 'PUT',
      data: person,
      dataType: 'json'
    })
      .done(function (data) {
        success(data);
      })
      .fail(function (error) {
        if (failure) {
          failure(error);
        }
        else {
          console.log("Error Occurred: " + error);
        }
      });
  }

  function addData(person, success, failure) {
    // Add a single row of data
    $.ajax({
      url: API_URL,
      type: 'POST',
      data: person,
      dataType: 'json'
    })
      .done(function (data) {
        success(data);
      })
      .fail(function (error) {
        if (failure) {
          failure(error);
        }
        else {
          console.log("Error Occurred: " + error);
        }
      });
  }

  function deleteData(id, success, failure) {
    // Delete a single row of data
    $.ajax({
      url: API_URL + id,
      type: 'DELETE',
      dataType: 'json'
    })
      .done(function (data) {
        success(data);
      })
      .fail(function (error) {
        if (failure) {
          failure(error);
        }
        else {
          console.log("Error Occurred: " + error);
        }
      });
  }

  // ************************************
  // Public Functions
  // ************************************
  return {
    getAll: function (success, failure) {
      getAll(success, failure);
    },
    get: function (id, success, failure) {
      get(id, success, failure);
    },
    updateData: function (person, success, failure) {
      updateData(person, success, failure);
    },
    addData: function (person, success, failure) {
      addData(person, success, failure);
    },
    deleteData: function (id, success, failure) {
      deleteData(id, success, failure);
    }
  };
})();