﻿Create the Person table into your SQL Server using the \SqlScripts\Person.sql script.
Modify the connection string in Web.config to point to your SQL server and the database into which you created the Person table.
