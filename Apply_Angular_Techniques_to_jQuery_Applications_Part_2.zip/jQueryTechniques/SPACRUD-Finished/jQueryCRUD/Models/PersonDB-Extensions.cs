﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;

namespace jQueryCRUD.Models
{
  public partial class PersonDB
  {
    protected override DbEntityValidationResult ValidateEntity(DbEntityEntry entityEntry, IDictionary<object, object> items)
    {
      List<DbValidationError> list = new List<DbValidationError>();

      if (entityEntry.Entity is Person) {
        Person entity = entityEntry.Entity as Person;

        // Check FirstName field
        if (string.IsNullOrEmpty(entity.FirstName)) {
          list.Add(new DbValidationError("FirstName",
              "First Name must be filled in."));
        }
        else {
          if (entity.FirstName.ToLower() ==
              entity.FirstName) {
            list.Add(new DbValidationError("FirstName",
              "First Name must not be all lower case."));
          }
          if (entity.FirstName.Length < 2 ||
              entity.FirstName.Length > 50) {
            list.Add(new DbValidationError("FirstName",
              "First Name must have between 2 and 50 characters."));
          }
        }

        // Check LastName field
        if (string.IsNullOrEmpty(entity.LastName)) {
          list.Add(new DbValidationError("LastName",
              "Last Name must be filled in."));
        }
        else {
          if (entity.LastName.ToLower() ==
              entity.LastName) {
            list.Add(new DbValidationError("LastName",
              "Last Name must not be all lower case."));
          }
          if (entity.LastName.Length < 2 ||
              entity.LastName.Length > 50) {
            list.Add(new DbValidationError("LastName",
              "Last Name must have between 2 and 50 characters."));
          }
        }

        // Check StartDate field
        if (entity.StartDate.HasValue) {
          if (entity.StartDate < DateTime.Now.AddYears(-40)) {
            list.Add(new DbValidationError("StartDate",
              "Start Date must be within the last forty years."));
          }
          if (entity.StartDate > DateTime.Now) {
            list.Add(new DbValidationError("StartDate",
              "Start Date must be less than or equal to today's date."));
          }
        }
        else {
          list.Add(new DbValidationError("StartDate",
              "Start Date must be filled in."));
        }

        // Check EmailAddress field
        if (string.IsNullOrEmpty(entity.EmailAddress)) {
          list.Add(new DbValidationError("EmailAddress",
              "Email Address must be filled in."));
        }
        else {
          if (entity.EmailAddress.Length < 6 ||
              entity.EmailAddress.Length > 150) {
            list.Add(new DbValidationError("EmailAddress",
              "Email Address must have between 6 and 150 characters."));
          }
        }

        // Check Salary
        if (entity.Salary.HasValue) {
          if (entity.Salary < 1 || entity.Salary > 1000001) {
            list.Add(new DbValidationError("Salary",
              "Salary must be over $1 and less than $1,000,000."));
          }
        }
        else {
          list.Add(new DbValidationError("Salary",
              "Salary must be filled in."));
        }

        if (list.Count > 0) {
          return new DbEntityValidationResult(entityEntry, list);
        }
      }

      return base.ValidateEntity(entityEntry, items);
    }
  }
}