﻿using System;
using System.Data.Entity.Validation;
using System.Diagnostics;
using System.Web.Http;
using System.Web.Http.ModelBinding;

namespace jQueryCRUD.Components
{
  public class BaseApiController : ApiController
  {
    protected IHttpActionResult HandleException(Exception ex, string msg)
    {
      IHttpActionResult ret;

      // Do exception publishing here
      Debug.WriteLine(ex.ToString());

      // Create new exception with generic message        
      ret = InternalServerError(
        new Exception(msg, ex));

      return ret;
    }

    protected ModelStateDictionary ConvertToModelState(DbEntityValidationException ex)
    {
      ModelStateDictionary ret = new ModelStateDictionary();

      foreach (var list in ex.EntityValidationErrors) {
        foreach (var item in list.ValidationErrors) {
          ret.AddModelError(item.PropertyName, item.ErrorMessage);
        }
      }

      return ret;
    }
  }
}