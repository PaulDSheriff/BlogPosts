﻿using System;
using System.Data.Entity.Validation;
using System.Linq;
using System.Web.Http;
using jQueryCRUD.Components;
using jQueryCRUD.Models;

namespace jQueryCRUD.Controllers
{
  [RoutePrefix("api/Person")]
  public class PersonController : BaseApiController
  {
    /// <summary>
    /// Get a list of all people
    /// </summary>
    /// <example>
    /// GET api/<controller>
    /// </example>
    /// <returns>A List of People</returns>
    [HttpGet()]
    public IHttpActionResult Get()
    {
      PersonDB db = null;
      IHttpActionResult ret = null;

      try {
        db = new PersonDB();

        if (db.People.Count() > 0) {
          ret = Ok(db.People);
        }
        else {
          ret = NotFound();
        }
      }
      catch (Exception ex) {
        ret = HandleException(ex, "Error attempting to retrieve a list of persons");
      }

      return ret;
    }

    // GET api/<controller>/1
    /// <summary>
    /// Get a single person
    /// </summary>
    /// <example>
    /// GET api/<controller>/1
    /// </example>
    /// <param name="id">The unique id for the person</param>
    /// <returns>A Person object</returns>
    [HttpGet()]
    public IHttpActionResult Get(int id)
    {
      PersonDB db = null;
      IHttpActionResult ret = null;
      Person person = null;

      try {
        db = new PersonDB();

        person = db.People.Find(id);
        if (person != null) {
          ret = Ok(person);
        }
        else {
          ret = NotFound();
        }
      }
      catch (Exception ex) {
        ret = HandleException(ex, "Error attempting to retrieve a single person");
      }

      return ret;
    }

    /// <summary>
    /// Add a person
    /// </summary>
    /// <example>
    /// POST api/<controller>
    /// </example>
    /// <param name="person">A person object</param>
    [HttpPost()]
    public IHttpActionResult Post([FromBody]Person person)
    {
      PersonDB db = null;
      IHttpActionResult ret = null;

      try {
        db = new PersonDB();

        if (person != null) {
          db.People.Add(person);
          db.SaveChanges();
          ret = Created<Person>(Request.RequestUri +
                                person.PersonId.ToString(),
                                person);
        }
        else {
          ret = BadRequest("Invalid person object passed to POST method");
        }
      }
      catch (DbEntityValidationException ex) {
        ret = BadRequest(ConvertToModelState(ex));
      }
      catch (Exception ex) {
        ret = HandleException(ex, "Error attempting to insert person data");
      }

      return ret;
    }

    /// <summary>
    /// Update a person
    /// </summary>
    /// <example>
    /// PUT api/<controller>
    /// </example>
    /// <param name="person">The person object to update</param>
    [HttpPut()]
    public IHttpActionResult Put([FromBody]Person person)
    {
      PersonDB db = null;
      IHttpActionResult ret = null;

      try {
        db = new PersonDB();

        if (person != null) {
          db.Entry(person).State = System.Data.Entity.EntityState.Modified;
          db.SaveChanges();
          ret = Ok(person);
        }
        else {
          ret = BadRequest("Invalid person object passed to PUT method");
        }
      }
      catch (DbEntityValidationException ex) {
        ret = BadRequest(ConvertToModelState(ex));
      }
      catch (Exception ex) {
        ret = HandleException(ex, "Error attempting to update person data");
      }

      return ret;
    }

    /// <summary>
    /// Delete a person
    /// </summary>
    /// <example>
    /// DELETE api/<controller>/1
    /// </example>
    /// <param name="id">The unique id for the person</param>
    [HttpDelete()]
    public IHttpActionResult Delete(int id)
    {
      PersonDB db = null;
      IHttpActionResult ret = null;
      Person person = null;

      try {
        db = new PersonDB();

        person = db.People.Find(id);
        if (person != null) {
          db.People.Remove(person);
          db.SaveChanges();
        }
        ret = Ok(true);
      }
      catch (Exception ex) {
        ret = HandleException(ex, "Error attempting to delete person data");
      }

      return ret;
    }
  }
}