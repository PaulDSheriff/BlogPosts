﻿$(document).ready(function () {
  PersonDetailComponent.get();
});

// ************************************
// Closure for page
// ************************************
var PersonDetailComponent = (function () {
  // ************************************
  // Private Variables
  // ************************************
  var vm = {
    person: {}
  };

  // ************************************
  // Private Functions
  // ************************************
  function getSuccess(data) {
    // Assign data to object
    vm.person = data;
    // Display fields in HTML inputs
    displayData(vm.person);
  }

  function get() {
    // Assuming the following url: #productdetail/n
    var id = window.location.hash;
    if (id.lastIndexOf("/") >= 0) {
      // Extract the ID portion from the hash
      id = id.substring(id.lastIndexOf("/") + 1);
    }
    else {
      id = null;
    }

    if (id) {
      // Call service to get data
      PersonService.get(id, getSuccess);
    }
    else {
      vm.person = {
        personId: null,
        firstName: "",
        lastName: "",
        emailAddress: "",
        startDate: new Date().toLocaleString(),
        salary: 0
      };
      // Display fields in HTML inputs
      displayData(vm.person);
    }
  }

  function save() {
    // Gather data from HTML inputs
    vm.person = getDataFromInput();

    // Update data
    if (vm.person.personId) {
      updateData();
    }
    else {
      addData();
    }
  }

  function updateDataSuccess(data) {
    // Return to list page
    window.history.back(-1);
  }

  function updateData() {
    // Get data from HTML
    vm.person = getDataFromInput();
    // Call PersonService to update person
    PersonService.updateData(vm.person, updateDataSuccess);
  }

  function addDataSuccess(data) {
    // Return to list page
    window.history.back(-1);
  }

  function addData() {
    // Get data from HTML
    vm.person = getDataFromInput();
    // Call PersonService to update person
    PersonService.addData(vm.person, updateDataSuccess);
  }

  function getDataFromInput() {
    return {
      personId: $("#personId").val(),
      firstName: $("#firstName").val(),
      lastName: $("#lastName").val(),
      emailAddress: $("#emailAddress").val(),
      startDate: $("#startDate").val().replace(/[^ -z]/g, ''),  // HANDLE IE DATE PROBLEM
      salary: $("#salary").val()
    }
  }

  function displayData(person) {
    $("#personId").val(person.personId);
    $("#firstName").val(person.firstName);
    $("#lastName").val(person.lastName);
    $("#emailAddress").val(person.emailAddress);
    $("#startDate").val(person.startDate);
    $("#salary").val(person.salary);
  }

  // ************************************
  // Public Functions
  // ************************************
  return {
    get: function () {
      get();
    },
    save: function () {
      save();
    },
    cancel: function () {
      window.history.back(-1);
    }
  };
})();
