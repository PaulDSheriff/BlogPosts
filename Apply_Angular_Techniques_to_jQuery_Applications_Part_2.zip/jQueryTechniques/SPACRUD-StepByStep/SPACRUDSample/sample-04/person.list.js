﻿$(document).ready(function () {
  PersonListComponent.getAll();
});

// ************************************
// Closure for page
// ************************************
var PersonListComponent = (function () {
  // ************************************
  // Private Variables
  // ************************************
  var vm = {
    people: []
  };

  // ************************************
  // Private Functions
  // ************************************
  function renderData(templateId, insertInto) {
    // Get template from script element
    var template = $(templateId).html();
    // Call Mustache passing in the template and the
    // object with collection of data to display
    var html = Mustache.to_html(template, PersonListComponent);
    // Insert the rendered HTML into the DOM
    $(insertInto).html(html);
  }

  // Callback function from service
  function getAllSuccess(data) {
    // Assign data to array
    vm.people = data;
    // Create HTML table
    renderData("#dataTmpl", "#people tbody");
    // Enable Add button
    $("#btnAdd").removeAttr('disabled');
  }

  function getAll() {
    // Call Service to get list of data
    PersonService.getAll(getAllSuccess);
  }

  // ************************************
  // Public Functions
  // ************************************
  return {
    getAll: function () {
      getAll();
    },
    salaryAsCurrency: function () {
      return new Number(this.salary)
        .toLocaleString('en-US', { style: 'currency', currency: 'USD' });
    },
    dataCollection: function () {
      return vm.people;
    }
  };
})();
