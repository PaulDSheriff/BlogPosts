﻿// ************************************
// Person Service
// ************************************
var PersonService = (function () {
  const API_URL = "/api/Person/";

  // Get a list of data
  function getAll(success, failure) {
    $.ajax({
      url: API_URL,
      type: 'GET',
      dataType: 'json'
    })
      .done(function (data) {
        success(data);
      })
      .fail(function (error) {
        if (failure) {
          failure(error);
        }
        else {
          console.log("Error Occurred: " + error);
        }
      });
  }

  // Public Functions
  return {
    getAll: function (success, failure) {
      getAll(success, failure);
    }
  };
})();