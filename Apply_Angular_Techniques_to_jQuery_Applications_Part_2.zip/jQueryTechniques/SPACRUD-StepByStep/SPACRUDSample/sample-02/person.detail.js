﻿$(document).ready(function () {
  PersonDetailComponent.get();
});

// ************************************
// Closure for page
// ************************************
var PersonDetailComponent = (function () {
  // ************************************
  // Private Variables
  // ************************************
  var vm = {
    person: {}
  };

  // ************************************
  // Private Functions
  // ************************************
  function getSuccess(data) {
    // Assign data to object
    vm.person = data;
    // Display fields in HTML inputs
    displayData(vm.person);
  }

  function get() {
    // Assuming the following url: #product.detail/n
    var id = window.location.hash;
    if (id.lastIndexOf("/") >= 0) {
      // Extract the ID portion from the hash
      id = id.substring(id.lastIndexOf("/") + 1);
    }
    else {
      id = null;
    }

    if (id) {
      // Call service to get data
      PersonService.get(id, getSuccess);
    }
  }

  function displayData(person) {
    $("#personId").val(person.personId);
    $("#firstName").val(person.firstName);
    $("#lastName").val(person.lastName);
    $("#emailAddress").val(person.emailAddress);
    $("#startDate").val(person.startDate);
    $("#salary").val(person.salary);
  }

  // ************************************
  // Public Functions
  // ************************************
  return {
    get: function () {
      get();
    }
  };
})();
