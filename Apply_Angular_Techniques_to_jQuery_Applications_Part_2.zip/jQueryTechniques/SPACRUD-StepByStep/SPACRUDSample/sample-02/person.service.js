﻿// ************************************
// Person Service
// ************************************
var PersonService = (function () {
  const API_URL = "/api/Person/";

  function getAll(success, failure) {
    // Get a list of data
    $.ajax({
      url: API_URL,
      type: 'GET',
      dataType: 'json'
    })
      .done(function (data) {
        success(data);
      })
      .fail(function (error) {
        if (failure) {
          failure(error);
        }
        else {
          console.log("Error Occurred: " + error);
        }
      });
  }

  function get(id, success, failure) {
    // Get a single record
    $.ajax({
      url: API_URL + id,
      type: 'GET',
      dataType: 'json'
    })
      .done(function (data) {
        success(data);
      })
      .fail(function (error) {
        if (failure) {
          failure(error);
        }
        else {
          console.log("Error Occurred: " + error);
        }
      });
  }

  // ************************************
  // Public Functions
  // ************************************
  return {
    getAll: function (success, failure) {
      getAll(success, failure);
    },
    get: function (id, success, failure) {
      get(id, success, failure);
    }
  };
})();