﻿$(document).ready(function () {
  PersonDetailComponent.get();
});

// ************************************
// Closure for page
// ************************************
var PersonDetailComponent = (function () {
  // ************************************
  // Private Variables
  // ************************************
  var vm = {
    person: {}
  };

  // ************************************
  // Private Functions
  // ************************************
  function getSuccess(data) {
    // Assign data to object
    vm.person = data;
    // Display fields in HTML inputs
    displayData(vm.person);
  }

  function get() {
    // Assuming the following url: #productdetail/n
    var id = window.location.hash;
    if (id.lastIndexOf("/") >= 0) {
      // Extract the ID portion from the hash
      id = id.substring(id.lastIndexOf("/") + 1);
    }
    else {
      id = null;
    }

    if (id) {
      // Call service to get data
      PersonService.get(id, getSuccess);
    }
  }

  function save() {
    // Gather data from HTML inputs
    vm.person = getDataFromInput();

    // Update data
    if (vm.person) {
      updateData();
    }
  }

  function updateDataSuccess(data) {
    // Return to list page
    window.history.back(-1);
  }

  function updateData() {
    // Get data from HTML
    vm.person = getDataFromInput();
    // Call service to update data
    PersonService.updateData(vm.person, updateDataSuccess);
  }

  function getDataFromInput() {
    return {
      personId: $("#personId").val(),
      firstName: $("#firstName").val(),
      lastName: $("#lastName").val(),
      emailAddress: $("#emailAddress").val(),
      startDate: $("#startDate").val().replace(/[^ -z]/g, ''),
      salary: $("#salary").val()
    }
  }

  function displayData(person) {
    $("#personId").val(person.personId);
    $("#firstName").val(person.firstName);
    $("#lastName").val(person.lastName);
    $("#emailAddress").val(person.emailAddress);
    $("#startDate").val(person.startDate);
    $("#salary").val(person.salary);
  }

  // ************************************
  // Public Functions
  // ************************************
  return {
    get: function () {
      get();
    },
    save: function () {
      save();
    },
    cancel: function () {
      window.history.back(-1);
    }
  };
})();
