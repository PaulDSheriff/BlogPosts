﻿Samples
-------------------------------------------------------------------------------
Sample 1 - Simple example of loading data into partial page
Sample 2 - Redirect to detail page, display a person
Sample 3 - Update a person
         - Handle IE date problem
Sample 4 - Add a person
Sample 5 - Delete a person