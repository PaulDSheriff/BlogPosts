﻿using System.Windows;

namespace FilterDataSample
{
  public partial class App : Application
  {
  }
}
