﻿This sample assumes you have AdventureWorksLT database installed in a SQL Server

CustomerSearchControl.xaml
  Uses a DataGrid to display data
  A search area is defined above the DataGrid to filter the DataGrid

CustomerFilterControl.xaml
  Places the search combo boxes within the header of each column to filter on

CustomerFilterControl2.xaml
  Defines a Header template so all headers line up.