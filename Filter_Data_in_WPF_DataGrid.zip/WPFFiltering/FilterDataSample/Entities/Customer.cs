﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CommonLibrary;

namespace FilterDataSample.Entities
{
  [Table("Customer", Schema = "SalesLT")]
  public class Customer : CommonBase
  {
    #region Private Variables
    private int? _CustomerID = null;
    private bool _NameStyle = false;
    private string _Title = null;
    private string _FirstName = null;
    private string _MiddleName = null;
    private string _LastName = null;
    private string _Suffix = null;
    private string _CompanyName = null;
    private string _SalesPerson = null;
    private string _EmailAddress = null;
    private string _Phone = null;
    private string _PasswordHash = null;
    private string _PasswordSalt = null;
    private Guid? _rowguid = null;
    private DateTime? _ModifiedDate = null;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the CustomerID value
    /// </summary>
    [Required]
    [Key]
    [Display(Description = "Customer ID")]

    public int? CustomerID
    {
      get { return _CustomerID; }
      set {
        _CustomerID = value;
        RaisePropertyChanged("CustomerID");
      }
    }

    /// <summary>
    /// Get/Set the NameStyle value
    /// </summary>

    [Display(Description = "Name Style")]

    public bool NameStyle
    {
      get { return _NameStyle; }
      set {
        _NameStyle = value;

        RaisePropertyChanged("NameStyle");
      }
    }

    /// <summary>
    /// Get/Set the Title value
    /// </summary>

    [Display(Description = "Title")]

    public string Title
    {
      get { return _Title; }
      set {
        _Title = value;

        RaisePropertyChanged("Title");
      }
    }

    /// <summary>
    /// Get/Set the FirstName value
    /// </summary>

    [Display(Description = "First Name")]
    [Required(ErrorMessage = "First Name must be filled in.")]

    public string FirstName
    {
      get { return _FirstName; }
      set {
        _FirstName = value;

        RaisePropertyChanged("FirstName");
      }
    }

    /// <summary>
    /// Get/Set the MiddleName value
    /// </summary>

    [Display(Description = "Middle Name")]

    public string MiddleName
    {
      get { return _MiddleName; }
      set {
        _MiddleName = value;

        RaisePropertyChanged("MiddleName");
      }
    }

    /// <summary>
    /// Get/Set the LastName value
    /// </summary>

    [Display(Description = "Last Name")]
    [Required(ErrorMessage = "Last Name must be filled in.")]

    public string LastName
    {
      get { return _LastName; }
      set {
        _LastName = value;

        RaisePropertyChanged("LastName");
      }
    }

    [NotMapped]
    public string FullName
    {
      get { return FirstName + " " + LastName; }
      set { var tmp = value; }
    }

    /// <summary>
    /// Get/Set the Suffix value
    /// </summary>

    [Display(Description = "Suffix")]

    public string Suffix
    {
      get { return _Suffix; }
      set {
        _Suffix = value;

        RaisePropertyChanged("Suffix");
      }
    }

    /// <summary>
    /// Get/Set the CompanyName value
    /// </summary>

    [Display(Description = "Company Name")]

    public string CompanyName
    {
      get { return _CompanyName; }
      set {
        _CompanyName = value;

        RaisePropertyChanged("CompanyName");
      }
    }

    /// <summary>
    /// Get/Set the SalesPerson value
    /// </summary>

    [Display(Description = "Sales Person")]

    public string SalesPerson
    {
      get { return _SalesPerson; }
      set {
        _SalesPerson = value;

        RaisePropertyChanged("SalesPerson");
      }
    }

    /// <summary>
    /// Get/Set the EmailAddress value
    /// </summary>

    [Display(Description = "Email Address")]

    public string EmailAddress
    {
      get { return _EmailAddress; }
      set {
        _EmailAddress = value;

        RaisePropertyChanged("EmailAddress");
      }
    }

    /// <summary>
    /// Get/Set the Phone value
    /// </summary>

    [Display(Description = "Phone")]

    public string Phone
    {
      get { return _Phone; }
      set {
        _Phone = value;

        RaisePropertyChanged("Phone");
      }
    }

    /// <summary>
    /// Get/Set the PasswordHash value
    /// </summary>

    [Display(Description = "Password Hash")]
    [Required(ErrorMessage = "Password Hash must be filled in.")]

    public string PasswordHash
    {
      get { return _PasswordHash; }
      set {
        _PasswordHash = value;

        RaisePropertyChanged("PasswordHash");
      }
    }

    /// <summary>
    /// Get/Set the PasswordSalt value
    /// </summary>

    [Display(Description = "Password Salt")]
    [Required(ErrorMessage = "Password Salt must be filled in.")]

    public string PasswordSalt
    {
      get { return _PasswordSalt; }
      set {
        _PasswordSalt = value;

        RaisePropertyChanged("PasswordSalt");
      }
    }

    /// <summary>
    /// Get/Set the rowguid value
    /// </summary>

    [Display(Description = "rowguid")]

    public Guid? rowguid
    {
      get { return _rowguid; }
      set {
        _rowguid = value;

        RaisePropertyChanged("rowguid");
      }
    }

    /// <summary>
    /// Get/Set the ModifiedDate value
    /// </summary>

    [Display(Description = "Modified Date")]
    [Range(typeof(DateTime), "1753-01-01 00:00:00", "9999-12-31 23:59:59", ErrorMessage = "Modified Date must be between {1} and {2}")]

    public DateTime? ModifiedDate
    {
      get { return _ModifiedDate; }
      set {
        _ModifiedDate = value;

        RaisePropertyChanged("ModifiedDate");
      }
    }

    #endregion
  }
}
