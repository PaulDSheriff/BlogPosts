﻿using System.Windows;
using System.Windows.Controls;
using FilterDataSample.ViewModels;

namespace FilterDataSample
{
  public partial class CustomerFilterControl : UserControl
  {
    CustomerViewModel _ViewModel = null;

    public CustomerFilterControl() {
      InitializeComponent();

      _ViewModel = (CustomerViewModel)this.FindResource("viewModel");
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e) {
      _ViewModel.Load();
    }
  }
}
