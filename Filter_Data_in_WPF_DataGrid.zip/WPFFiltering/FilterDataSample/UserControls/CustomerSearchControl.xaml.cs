﻿using System.Windows;
using System.Windows.Controls;
using FilterDataSample.ViewModels;

namespace FilterDataSample
{
  public partial class CustomerSearchControl : UserControl
  {
    CustomerViewModel _viewModel = null;

    public CustomerSearchControl()
    {
      InitializeComponent();

      _viewModel = (CustomerViewModel)this.FindResource("viewModel");
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      _viewModel.Load();
    }
  }
}
