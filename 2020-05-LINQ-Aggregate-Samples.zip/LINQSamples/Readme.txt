﻿Aggregates
-----------------------------------------------
Count
Count (Filtered)
Sum
Min
Max
Average
Aggregate


Resources
----------------------------------------------------
https://docs.microsoft.com/en-us/dotnet/csharp/linq/