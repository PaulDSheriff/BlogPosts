﻿using System.Web.Mvc;

namespace FileUploadSamples.Controllers
{
  public class ErrorsController : Controller
  {
    public ActionResult FileTooBig()
    {
      return View();
    }
  }
}