using System.Data.Entity;

namespace FileUploadSamples.Models
{
  public partial class FileUploadDB : DbContext
  {
    public FileUploadDB() : base("name=FileUploadDB") { }

    public virtual DbSet<FileUpload> FileUploads { get; set; }
  }
}
