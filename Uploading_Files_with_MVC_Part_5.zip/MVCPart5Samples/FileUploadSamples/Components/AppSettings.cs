﻿using System;
using System.Configuration;

namespace FileUploadSamples.Components
{
  public class AppSettings
  {
    #region Public Properties
    /// <summary>
    /// Get/Set the name of the upload folder name
    /// </summary>
    public static string UploadFolderName { get; set; }
    /// <summary>
    /// Get/Set the name of the file to use when no preview image is available
    /// </summary>
    public static string NoPreviewFileName { get; set; }

    /// <summary>
    /// Get/Set the list of valid image types for which we can create a thumbnail
    /// Example: bmp,gif,img,jpeg,jpg,png
    /// </summary>
    public static string ImageTypes { get; set; }

    /// <summary>
    /// Get/Set the thumbnail default width
    /// </summary>
    public static int ThumbWidth { get; set; }

    /// <summary>
    /// Get/Set the thumbnail default height
    /// </summary>
    public static int ThumbHeight { get; set; }
    #endregion

    #region LoadDefaults Method
    public static void LoadDefaults()
    {
      UploadFolderName = GetValue<string>("uploadFolderName", "/UploadedFiles/");
      NoPreviewFileName = GetValue<string>("noPreviewFileName", "~/Images/NoPreview.png");
      ImageTypes = GetValue<string>("imageTypes", "bmp,gif,img,jpeg,jpg,png");
      ThumbWidth = GetValue<int>("thumbWidth", 100);
      ThumbHeight = GetValue<int>("thumbHeight", 100);
    }
    #endregion

    #region GetValue Method    
    public static T GetValue<T>(string keyName, T defaultValue)
    {
      string value;
      T ret;

      value = ConfigurationManager.AppSettings[keyName];
      if (string.IsNullOrEmpty(value)) {
        ret = defaultValue;
      }
      else {
        ret = (T)Convert.ChangeType(value, typeof(T));
      }

      return ret;
    }
    #endregion
  }
}