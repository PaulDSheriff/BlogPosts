﻿WPF.Sample.AppLayer
------------------------------------------
Add any classes or other resources that are unique to this application in this project.
