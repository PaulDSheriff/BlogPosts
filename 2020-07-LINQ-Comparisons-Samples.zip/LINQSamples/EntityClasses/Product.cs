﻿namespace LINQSamples.EntityClasses
{
  public partial class Product
  {
    public int ProductID { get; set; }
    public string Name { get; set; }
    public string ProductNumber { get; set; }
    public string Color { get; set; }
    public decimal? StandardCost { get; set; }
    public decimal? ListPrice { get; set; }
    public string Size { get; set; }

    // Calculated Properties
    public int NameLength { get; set; }
    public decimal TotalSales { get; set; }

    public override string ToString()
    {
      return Name;
    }
  }
}
