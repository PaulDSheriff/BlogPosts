﻿Comparisons
-----------------------------------------------
SequenceEqual
Except
Intersect
Union (No dupes)
Concat (dupes)


Resources
----------------------------------------------------
https://docs.microsoft.com/en-us/dotnet/csharp/linq/