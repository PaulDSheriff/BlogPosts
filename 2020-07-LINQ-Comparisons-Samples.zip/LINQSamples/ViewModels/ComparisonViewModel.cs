﻿using System;
using System.Collections.Generic;
using System.Linq;
using Common.Library;
using LINQSamples.EntityClasses;
using LINQSamples.RepositoryClasses;

namespace LINQSamples.ViewModels
{
  public class ComparisonViewModel : ViewModelBase
  {
    #region SequenceEqualIntegers
    /// <summary>
    /// SequenceEqual() compares two different collections to see if they are equal
    /// When using simple data types such as int, string, a direct comparison between values is performed
    /// </summary>
    public void SequenceEqualIntegers()
    {
      System.Diagnostics.Debugger.Break();

      bool value;
      // Create a list of numbers
      List<int> list1 = new List<int> { 1, 2, 3, 4, 5 };
      // Create a list of numbers
      List<int> list2 = new List<int> { 1, 2, 3, 4, 5 };

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in list1
                 select prod).SequenceEqual(list2);
      }
      else {
        // Method Syntax
        value = list1.SequenceEqual(list2);
      }

      if (value) {
        ResultText = "Lists are Equal";
      }
      else {
        ResultText = "Lists are NOT Equal";
      }
    }
    #endregion

    #region SequenceEqualProducts
    /// <summary>
    /// SequenceEqual() compares two different collections to see if they are equal
    /// When using an object, a comparison to see if the two object references point to the same object
    /// </summary>
    public void SequenceEqualProducts()
    {
      System.Diagnostics.Debugger.Break();

      bool value;
      // Create a list of products
      List<Product> list1 = new List<Product> {
        new Product {ProductID= 1, Name = "Product 1"},
        new Product {ProductID= 2, Name = "Product 2"},
      };
      // Create a list of products
      List<Product> list2 = new List<Product> {
        new Product {ProductID= 1, Name = "Product 1"},
        new Product {ProductID= 2, Name = "Product 2"},
      };

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in list1
                 select prod).SequenceEqual(list2);
      }
      else {
        // Method Syntax
        value = list1.SequenceEqual(list2);
      }

      if (value) {
        ResultText = "Lists are Equal";
      }
      else {
        ResultText = "Lists are NOT Equal";
      }
    }
    #endregion

    #region SequenceEqual
    /// <summary>
    /// SequenceEqual() compares two different collections to see if they are equal
    /// Use an EqualityComparer class to perform determine if the objects are the same based on the values in the properties
    /// </summary>
    public void SequenceEqual()
    {
      System.Diagnostics.Debugger.Break();

      bool value;
      ProductComparer pc = new ProductComparer();
      // Load all Product Data
      List<Product> list1 = new ProductRepository().GetAll();
      // Load all Product Data
      List<Product> list2 = new ProductRepository().GetAll();

      // Uncomment the following to produce a 'False' value
      // list1.RemoveAt(0);

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in list1
                 select prod).SequenceEqual(list2, pc);
      }
      else {
        // Method Syntax
        value = list1.SequenceEqual(list2, pc);
      }

      if (value) {
        ResultText = "Lists are Equal";
      }
      else {
        ResultText = "Lists are NOT Equal";
      }
    }
    #endregion

    #region ExceptIntegers
    /// <summary>
    /// Except() finds all values in one list that are not in the other list
    /// </summary>
    public void ExceptIntegers()
    {
      System.Diagnostics.Debugger.Break();

      List<int> ret;
      // Create a list of numbers
      List<int> list1 = new List<int> { 1, 2, 3, 4 };
      // Create a list of numbers
      List<int> list2 = new List<int> { 3, 4, 5 };

      if (UseQuerySyntax) {
        // Query Syntax
        ret = (from prod in list1
               select prod).Except(list2).ToList();
      }
      else {
        // Method Syntax
        ret = list1.Except(list2).ToList();
      }

      ResultText = string.Empty;
      foreach (var item in ret) {
        ResultText += "Number: " + item + Environment.NewLine;
      }
    }
    #endregion

    #region Except
    /// <summary>
    /// Except() finds all products in one list that are not in the other list
    /// </summary>
    public void Except()
    {
      System.Diagnostics.Debugger.Break();

      ProductComparer pc = new ProductComparer();
      // Load all Product Data
      List<Product> list1 = new ProductRepository().GetAll();
      // Load all Product Data
      List<Product> list2 = new ProductRepository().GetAll();

      // Remove all products with color = "Black" from list2 to give us a difference in the two lists
      list2.RemoveAll(prod => prod.Color == "Black");

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in list1
                    select prod).Except(list2, pc).ToList();
      }
      else {
        // Method Syntax
        Products = list1.Except(list2, pc).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Intersect
    /// <summary>
    /// Intersect() finds all products that are in common between two collections
    /// </summary>
    public void Intersect()
    {
      System.Diagnostics.Debugger.Break();

      ProductComparer pc = new ProductComparer();
      // Load all Product Data
      List<Product> list1 = new ProductRepository().GetAll();
      // Load all Product Data
      List<Product> list2 = new ProductRepository().GetAll();

      list1.RemoveAll(prod => prod.Color == "Black");
      list2.RemoveAll(prod => prod.Color == "Red");

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in list1
                    select prod).Intersect(list2, pc).ToList();
      }
      else {
        // Method Syntax
        Products = list1.Intersect(list2, pc).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Union
    /// <summary>
    /// Union() combines two lists together, but skips duplicates
    /// </summary>
    public void Union()
    {
      System.Diagnostics.Debugger.Break();

      ProductComparer pc = new ProductComparer();
      // Load all Product Data
      List<Product> list1 = new ProductRepository().GetAll();
      // Load all Product Data
      List<Product> list2 = new ProductRepository().GetAll();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in list1
                    select prod).Union(list2, pc).OrderBy(prod => prod.Color).ToList();
      }
      else {
        // Method Syntax
        Products = list1.Union(list2, pc).OrderBy(prod => prod.Color).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Concat
    /// <summary>
    /// Concat() combines two lists together and does NOT check for duplicates
    /// </summary>
    public void Concat()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      List<Product> list1 = new ProductRepository().GetAll();
      // Load all Product Data
      List<Product> list2 = new ProductRepository().GetAll();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in list1
                    select prod).Concat(list2).OrderBy(prod => prod.Color).ToList();
      }
      else {
        // Method Syntax
        Products = list1.Concat(list2).OrderBy(prod => prod.Color).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion
  }
}
