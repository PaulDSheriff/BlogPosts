﻿
using Vendor.Interfaces;

namespace Vendor
{
  public class Google : IVendor
  {
    public int VendorId { get;set;}
    public string VendorName { get;set;}

    public string GetVendorInfo()
    {
      return "Google";
    }
  }
}
