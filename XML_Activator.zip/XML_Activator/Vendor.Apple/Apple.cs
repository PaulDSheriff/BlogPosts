﻿using Vendor.Interfaces;

namespace Vendor
{
  public class Apple : IVendor
  {
    public int VendorId { get; set; }
    public string VendorName { get; set; }

    public string GetVendorInfo()
    {
      return "Apple Corporation";
    }
  }
}
