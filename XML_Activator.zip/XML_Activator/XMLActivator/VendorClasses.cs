﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Xml.Linq;

namespace XMLActivator
{
  /// <summary>
  /// This class is used to load a list of Vendors from an XML file
  /// </summary>
  public class VendorClasses : List<VendorClass>
  {
    public VendorClasses LoadVendors()
    {
      // Load XML file into memory
      var xElem = XElement.Load(
        GetCurrentDirectory() +
        ConfigurationManager.AppSettings["VendorFile"]);

      // Read Vendors using LINQ to XML
      var vendors = from vend in xElem.Descendants("Vendor")
                    select new VendorClass
                    {
                      VendorId = Convert.ToInt32(vend.Element("VendorId").Value),
                      VendorName = vend.Element("VendorName").Value,
                      AssemblyName = vend.Element("AssemblyName").Value,
                      ClassName = vend.Element("ClassName").Value
                    };

      // Add vendors read in to the List of Vendor classes
      this.AddRange(vendors.ToList());

      return this;
    }

    #region GetCurrentDirectory Method
    /// <summary>
    /// This method returns the current directory and removes the \bin\Debug or \bin\Release folder from the path 
    /// This allows this method to be used when debugging under Visual Studio, and at runtime.
    /// </summary>
    /// <returns>The current directory</returns>
    private string GetCurrentDirectory()
    {
      string path = null;

      path = AppDomain.CurrentDomain.BaseDirectory;
      if (path.IndexOf("\\bin") > 0)
      {
        path = path.Substring(0, path.LastIndexOf("\\bin"));
      }

      if (!path.EndsWith(@"\"))
        path += @"\";

      return path;
    }
    #endregion
  }
}
