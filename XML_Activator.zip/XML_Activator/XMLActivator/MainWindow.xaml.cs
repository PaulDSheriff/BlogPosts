﻿using System.Windows;
using System.Windows.Controls;

using Vendor.Interfaces;

namespace XMLActivator
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      VendorClasses classes = new VendorClasses();

      // Load all vendors in the XML file
      classes.LoadVendors();
      lstVendors.DataContext = classes;
    }

    private void lstVendors_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      VendorClass vendor;
      IVendor vend;

      // Get the currently selected vendor
      vendor = (VendorClass)lstVendors.SelectedItem;
      // Create an instance of a Vendor class
      vend = vendor.Create();

      tbVendorName.Text = vend.GetVendorInfo();
    }
  }
}
