﻿using System.Windows;

namespace XMLActivator
{
  public partial class App : Application
  {
  }
}
