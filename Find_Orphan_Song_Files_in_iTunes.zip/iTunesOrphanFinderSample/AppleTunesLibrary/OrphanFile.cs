﻿using System;

namespace AppleTunesLibrary
{
  public class OrphanFile
  {
    public bool IsAudioVideoFile { get; set; }
    public string Location { get; set; }
  }
}
