﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Dynamic;
using System.Xml.Linq;

namespace AppleTunesLibrary
{
  public class AppleOrphanFinder : AppleSongReader
  {
    public List<OrphanFile> OrphanFiles { get; set; }
    public string MusicLocation { get; set; }
    public string AudioVideoFileExtensions { get; set; }
    public List<string> ValidExtensions { get; set; }

    public virtual void SetMusicLocation(string libraryFile)
    {
      // Load iTunes XML library
      XElement doc = XElement.Load(libraryFile);

      // Get music folder key
      IEnumerable<XElement> node =
              from dict in doc.Elements("dict")
                              .Elements("key")
              select dict;

      // Set song elements so you can use the GetValue() method
      _songElements = node.ToList();

      // Set the music location property
      MusicLocation = GetValue<string>("Music Folder", "Unknown");
    }

    public List<OrphanFile> FindOrphanFiles()
    {
      OrphanFile orphan;
      string[] files;
      string fileLower;

      // Get all files within music folder
      files = Directory.GetFiles(MusicLocation, "*.*", SearchOption.AllDirectories);

      // Clear OrphanFiles collection
      OrphanFiles = new List<OrphanFile>();
      // Create array of valid audio/video extensions
      ValidExtensions = AudioVideoFileExtensions.Split(',').ToList();

      // Loop through all files
      foreach (string file in files) {
        // Convert file to lower case
        fileLower = file.ToLower();
        // Locate file within Songs collection
        var tmp = Songs.Find(s => s.Location.ToLower() == fileLower);
        // Did we find the song?
        if (tmp == null) {
          // Create a new OrphanFile object
          orphan = new OrphanFile();
          orphan.IsAudioVideoFile = IsAudioVideoFile(file);
          orphan.Location = file;
          // Add orphan file to collection
          OrphanFiles.Add(orphan);
        }
      }

      // Sort songs by artist
      OrphanFiles = OrphanFiles.OrderByDescending(s => s.IsAudioVideoFile).ToList();

      return OrphanFiles;
    }

    protected virtual bool IsAudioVideoFile(string file)
    {
      bool ret = true;

      // Originally I was looking for folders and file extensions to exclude
      //string[] folders = new string[] { @"\css\", @"\images\", @"\controllers\", @"\src\", @"\views\", @"\audio\", @"\itunesartwork", @"\artwork", @"\tunekit\", @"\sounds\", @"\lib\", @".itlp\videos\" };
      //string[] extensions = new string[] { ".plist", ".itlp", ".xml", ".pdf", ".html", ".js" };

      ret = ValidExtensions.Contains(Path.GetExtension(file));

      return ret;
    }
  }
}
