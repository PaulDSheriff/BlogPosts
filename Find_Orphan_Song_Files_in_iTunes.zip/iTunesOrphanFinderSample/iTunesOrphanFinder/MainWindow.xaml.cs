﻿using System.Configuration;
using System.IO;
using System.Windows;
using System.Windows.Input;
using AppleTunesLibrary;

namespace iTunesOrphanFinder
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();

      // Get default library path/file name
      txtFileName.Text = ConfigurationManager.AppSettings["libraryFile"];
      txtFileExtensions.Text = ConfigurationManager.AppSettings["musicAudioExtensions"];
    }

    AppleOrphanFinder _Reader = new AppleOrphanFinder();

private void btnGetSongs_Click(object sender, RoutedEventArgs e)
{
  Mouse.OverrideCursor = Cursors.Wait;
  // Read all iTunes songs
  _Reader.GetAllSongs(txtFileName.Text);
  // Set music folder location
  _Reader.SetMusicLocation(txtFileName.Text);
  Mouse.OverrideCursor = null;

  // Display music location
  lblMusicLocation.Content = _Reader.MusicLocation;
  btnFindOrphans.IsEnabled = true;

  // Place song list into ListView control
  lstSongs.DataContext = _Reader.Songs;

  // Report total songs read
  lblCount.Content = _Reader.Songs.Count.ToString("###,###");
}

private void btnFindOrphans_Click(object sender, RoutedEventArgs e)
{
  if (Directory.Exists(lblMusicLocation.Content.ToString())) {
    btnFindOrphans.IsEnabled = false;
    btnGetSongs.IsEnabled = false;

    Mouse.OverrideCursor = Cursors.Wait;
    // Set valid audio/video file extensions
    _Reader.AudioVideoFileExtensions = txtFileExtensions.Text;

    // Locate orphan songs
    _Reader.FindOrphanFiles();
    Mouse.OverrideCursor = null;

    // Place orphan songs into ListView control
    lstOrphanFiles.DataContext = _Reader.OrphanFiles;
    lstOrphanFiles.Visibility = Visibility.Visible;
    lstSongs.Visibility = Visibility.Hidden;

    // Report orphan songs read
    lblSongCount.Content = "Total Orphan Songs";
    lblCount.Content = _Reader.OrphanFiles.Count.ToString("###,###");

    btnGetSongs.IsEnabled = true;
  }
  else {
    MessageBox.Show("Directory: " + lblMusicLocation.Content + " does not exist.");
  }
}
  }
}
