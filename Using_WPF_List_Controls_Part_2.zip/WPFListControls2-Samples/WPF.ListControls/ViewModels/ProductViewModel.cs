﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using WPF.ListControls.EntityClasses;
using WPF.ListControls.Models;

namespace WPF.ListControls.ViewModels
{
  public class ProductViewModel
  {
    public ProductViewModel()
    {
      LoadProducts();
    }

    public ObservableCollection<Product> Products { get; set; }
    public ObservableCollection<Product> ProductColors { get; set; }

    public virtual ObservableCollection<Product> LoadProducts()
    {
      try {
        using (AdventureWorksLTDbContext db =
                  new AdventureWorksLTDbContext()) {
          Products = new ObservableCollection<Product>(db.Products);

          // Load distinct colors
          ProductColors = new ObservableCollection<Product>(
            (from prod in Products select prod)
              .GroupBy(p => new { p.Color })
              .Select(g => g.FirstOrDefault())
              .ToList());

        }
      }
      catch (Exception ex) {
        System.Diagnostics.Debug.WriteLine(ex.ToString());
      }

      return Products;
    }
  }
}
