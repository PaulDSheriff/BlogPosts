﻿using System.Windows.Controls;

namespace WPF.ListControls.ListControlsTemplate
{
  public partial class DataGridTemplate : UserControl
  {
    public DataGridTemplate()
    {
      InitializeComponent();
    }
  }
}
