﻿using System.Windows.Controls;

namespace WPF.ListControls.ListControlsTemplate
{
  public partial class ComboBoxTemplate : UserControl
  {
    public ComboBoxTemplate()
    {
      InitializeComponent();
    }
  }
}
