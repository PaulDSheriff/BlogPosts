﻿using System.Windows.Controls;

namespace WPF.ListControls.ListControlsTemplate
{
  public partial class ListViewTemplate : UserControl
  {
    public ListViewTemplate()
    {
      InitializeComponent();
    }
  }
}
