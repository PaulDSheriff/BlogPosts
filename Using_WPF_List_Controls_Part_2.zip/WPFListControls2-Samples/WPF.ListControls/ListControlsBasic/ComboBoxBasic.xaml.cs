﻿using System.Windows.Controls;

namespace WPF.ListControls.ListControlsBasic
{
  public partial class ComboBoxBasic : UserControl
  {
    public ComboBoxBasic()
    {
      InitializeComponent();
    }
  }
}
