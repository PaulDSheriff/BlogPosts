﻿using System.Windows.Controls;

namespace WPFTreeView
{
  public partial class ucTreeViewSimple : UserControl
  {
    public ucTreeViewSimple()
    {
      InitializeComponent();
    }
  }
}
