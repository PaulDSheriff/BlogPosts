﻿using System.Windows;

namespace WPFTreeView
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnSimple_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucTreeViewSimple());
    }

    private void btnTemplate_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucTreeViewTemplate());
    }
     
    private void btnEvents_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucTreeViewEvents());
    }

    private void btnThreeLevels_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucThreeLevel());
    }
  }
}
