﻿using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace WPFTreeView
{
  public partial class ucTreeViewEvents : UserControl
  {
    public ucTreeViewEvents()
    {
      InitializeComponent();
    }

    // Routed Event Handler for when a Tree View Item is Expanded
    private void TreeViewItemExpanded(object sender, RoutedEventArgs e)
    {
      TreeViewItem item = (TreeViewItem)e.OriginalSource;
      // item.Header is actually an EmployeeType
      EmployeeType type = (EmployeeType)item.Header;

      Debug.WriteLine(type.EmpType);

      // Stop the routed event from going further
      e.Handled = true;
    }

    private void tvEmployees_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
    {
      object current;

      current = tvEmployees.SelectedItem;
      switch (current.GetType().Name.ToLower())
      {
        case "employee":
          break;
        case "employeetype":
          break;
        default:
          break;
      }
    }
  }
}
