﻿using System.Collections.Generic;

namespace BootstrapCheckBoxes3
{
  public class MusicGenreViewModel
  {
    #region Constructor
    public MusicGenreViewModel()
    {
      LoadGenresMock();
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the collection of Music Genres
    /// </summary>
    public List<MusicGenre> Genres { get; set; }
    #endregion

    #region LoadGenres Method
    public void LoadGenresMock()
    {
      // Create mock list of data
      // Normally you would load this data from a database
      Genres = new List<MusicGenre>();

      Genres.Add(new MusicGenre(1, "Jazz"));
      Genres.Add(new MusicGenre(2, "Country"));
      Genres.Add(new MusicGenre(3, "Rock"));
      Genres.Add(new MusicGenre(4, "Blues"));
      Genres.Add(new MusicGenre(5, "Alternative Rock"));
    }
    #endregion
  }
}
