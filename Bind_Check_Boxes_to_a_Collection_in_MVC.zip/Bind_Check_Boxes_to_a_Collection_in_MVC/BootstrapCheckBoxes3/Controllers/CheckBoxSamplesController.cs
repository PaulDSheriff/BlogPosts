﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Linq;

namespace BootstrapCheckBoxes3.Controllers
{
  public class CheckBoxSamplesController : Controller
  {   
    public ActionResult Check07()
    {
      MusicGenreViewModel vm = new MusicGenreViewModel();

      vm.Genres.Find(g => g.Genre == "Jazz").IsSelected = true;
      vm.Genres.Find(g => g.Genre == "Rock").IsSelected = true;

      return View(vm);
    }

    [HttpPost]
    public ActionResult Check07(MusicGenreViewModel vm)
    {
      // Retrieve selection list using Request.Form["BooleanFieldName"]
      // Returns something that looks like: "1,false,2,false,3,false,false,false"
      // Convert that to a List<string>
      List<int> selected = WebCommon.RequestSelectionToList(Request.Form["IsSelected"]);

      // Loop through selected items looking for integer values
      foreach (int item in selected)
      {
        // Set the IsSelected property on the appropriate GenreId
        vm.Genres.Find(g => g.GenreId == item).IsSelected = true;
      }

      System.Diagnostics.Debugger.Break();

      return View(vm);
    }
  }
}