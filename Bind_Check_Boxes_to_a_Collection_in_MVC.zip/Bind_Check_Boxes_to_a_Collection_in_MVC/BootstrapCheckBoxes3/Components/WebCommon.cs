﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BootstrapCheckBoxes3
{
  public class WebCommon
  {
    /// <summary>
    /// Retrieve selection list using Request.Form["BooleanFieldName"]
    /// Returns something that looks like: "1,false,2,false,3,false,false,false"
    /// Convert that to a List<string>
    /// </summary>
    /// <param name="values">A comma-delimited list of numerics and other values</param>
    /// <returns>A list of integers</returns>
public static List<int> RequestSelectionToList(string values)
{
  List<int> ret = new List<int>();
  List<string> selected = values.Split(',').ToList();
  int value = 0;

  // Loop through selected items looking for integer values
  foreach (string item in selected)
  {
    if (int.TryParse(item, out value))
    {
      ret.Add(value);
    }
  }

  return ret;
}
  }
}