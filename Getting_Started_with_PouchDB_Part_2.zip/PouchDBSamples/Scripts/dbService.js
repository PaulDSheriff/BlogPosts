﻿'use strict';

let dbService = new function DatabaseService() {
  this.db = null;

  this.openDatabase = function() {
    this.db = new PouchDB('handyman');
  }
}