﻿Samples-Flat
-----------------------------------------
DatabaseOperations.html
  Open/Create a database
  Add data
  Update data
  Delete data
  Compact database
  Destroy database

BulkOperations.html
  Create multiple documents
  Get all documents (id/revision only)
  Get all documents (include full document)
  Count all documents


Resources
-----------------------------------------
https://pouchdb.com/guides
https://pouchdb.com/2014/06/17/12-pro-tips-for-better-code-with-pouchdb.html

pouchdb-find plugin
https://github.com/pouchdb/pouchdb/releases/download/6.4.3/pouchdb.find.js

find() method
https://pouchdb.com/guides/mango-queries.html
http://docs.couchdb.org/en/2.0.0/api/database/find.html
https://stackoverflow.com/questions/33262573/cloudant-selector-query/33835521#33835521
https://www.bennadel.com/blog/3255-experimenting-with-the-mango-find-api-in-pouchdb-6-2-0.htm
https://www.redcometlabs.com/blog/2015/12/1/a-look-under-the-covers-of-pouchdb-find


Mango Queries
https://dotnetcodr.com/data-storage/  - Look at the series on CouchDB
https://dotnetcodr.com/2017/06/21/introduction-to-couchdb-with-net-part-17-starting-with-mango-queries/

query() method
https://pouchdb.com/2014/05/01/secondary-indexes-have-landed-in-pouchdb.html

Offline Apps
https://medium.com/ibm-watson-data-lab/making-your-app-awesome-when-the-network-isnt-part-1-3ed530c2523
