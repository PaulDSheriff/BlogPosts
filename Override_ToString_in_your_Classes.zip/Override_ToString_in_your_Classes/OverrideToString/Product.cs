﻿using System;

namespace OverrideToString
{
public class Product
{
  public string ProductName { get; set; }
  public int ProductId { get; set; }

  #region ToString Override
  public override string ToString()
  {
    return ProductName;
  }
  #endregion
}
}
