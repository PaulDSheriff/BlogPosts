﻿(function () {
  'use strict';

  angular.module('ptcApp')
    .controller('PTCController', PTCController);

  function PTCController($scope) {
    var vm = $scope;

    // Expose a 'product' object
    vm.product = {
      ProductName: 'Pluralsight Subscription'
    };
  }
})();
