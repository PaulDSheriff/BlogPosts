﻿namespace Common.EF.Library
{
  public class EFValidationMessage
  {
    #region Public Properties
    public string PropertyName { get; set; }
    public string Message { get; set; }
    #endregion
  }
}
