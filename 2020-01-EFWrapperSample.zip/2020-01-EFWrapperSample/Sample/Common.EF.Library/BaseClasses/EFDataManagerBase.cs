﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using Common.EF.Library;

namespace Common.EF.Library
{
  public class EFDataManagerBase : EFCommonBase
  {
    #region Constructor
    public EFDataManagerBase()
    {
      Init();
    }
    #endregion

    #region Properties
    public string SQL { get; set; }
    public object IdentityGenerated { get; set; }
    public List<SqlParameter> Parameters { get; set; }
    public List<EFValidationMessage> ValidationMessages { get; set; }
    #endregion

    #region Init Method
    protected virtual void Init()
    {
      Parameters = new List<SqlParameter>();
      ValidationMessages = new List<EFValidationMessage>();
    }
    #endregion

    #region Clear Method
    public virtual void Clear()
    {
      SQL = string.Empty;
      Parameters.Clear();
      LastExceptionMessage = string.Empty;
      LastException = null;
      RowsAffected = 0;
      ValidationMessages.Clear();
    }
    #endregion

    #region AddParameter Methods
    public virtual void AddParameter(string name, object value, bool isNullable)
    {
      if (!name.Contains("@")) {
        name = "@" + name;
      }
      Parameters.Add(new SqlParameter { ParameterName = name, Value = value, IsNullable = isNullable });
    }

    public virtual void AddParameter(string name, object value, bool isNullable, System.Data.DbType type, System.Data.ParameterDirection direction = System.Data.ParameterDirection.Input)
    {
      if (!name.Contains("@")) {
        name = "@" + name;
      }
      Parameters.Add(new SqlParameter { ParameterName = name, Value = value, IsNullable = isNullable, DbType = type, Direction = direction });
    }
    #endregion

    #region GetParameter Method
    public SqlParameter GetParameter(string name)
    {
      if (!name.Contains("@")) {
        name = "@" + name;
      }

      name = name.ToLower();
      return Parameters.Find(p => p.ParameterName.ToLower() == name);
    }
    #endregion

    #region ExecuteSqlCommand Method
    public virtual int ExecuteSqlCommand(DbContext db, string exceptionMsg = "")
    {
      try {
        // Execute the dynamic SQL
        RowsAffected = db.Database.ExecuteSqlCommand(SQL, Parameters.ToArray<object>());
      }
      catch (Exception ex) {
        ThrowDbException(ex, db, exceptionMsg);
      }

      return RowsAffected;
    }
    #endregion

    #region GetIdentityGenerated Method
    public virtual object GetIdentityGenerated(DbContext db, string exceptionMsg = "")
    {
      try {
        // Get the last identity generated
        IdentityGenerated = db.Database.ExecuteSqlCommand("SELECT SCOPE_IDENTITY() AS IdentityGenerated");
      }
      catch (Exception ex) {
        ThrowDbException(ex, db, exceptionMsg);
      }

      return IdentityGenerated;
    }
    #endregion

    #region ExecuteSqlQuery Method
    public virtual List<T> ExecuteSqlQuery<T>(DbContext db, string exceptionMsg = "")
    {
      List<T> ret = new List<T>();

      try {
        ret = db.Database.SqlQuery<T>(SQL, Parameters.ToArray<object>()).ToList<T>();
      }
      catch (Exception ex) {
        ThrowDbException(ex, db, exceptionMsg);
      }

      return ret;
    }
    #endregion

    #region ExecuteScalar Method
    public virtual T ExecuteScalar<T>(DbContext db, string exceptionMsg = "")
    {
      T ret = default(T);

      try {
        ret = db.Database.SqlQuery<T>(SQL, Parameters.ToArray<object>()).SingleOrDefault<T>();
      }
      catch (Exception ex) {
        ThrowDbException(ex, db, exceptionMsg);
      }

      return ret;
    }
    #endregion

    #region AddValidationMessage Method
    public EFValidationMessage AddValidationMessage(string propertyName, string message)
    {
      EFValidationMessage ret = new EFValidationMessage { PropertyName = propertyName, Message = message };

      ValidationMessages.Add(ret);

      return ret;
    }
    #endregion

    #region Validate Method       
    /// <summary>
    /// Override this method to validate your entity object
    /// </summary>
    /// <param name="entityToValidate">The entity to validate</param>
    /// <returns>True if entity is valid</returns>
    public virtual bool Validate<T>(T entityToValidate)
    {
      string propName = string.Empty;
      ValidationMessages.Clear();

      if (entityToValidate != null) {
        ValidationContext context = new ValidationContext(entityToValidate, serviceProvider: null, items: null);
        List<ValidationResult> results = new List<ValidationResult>();

        if (!Validator.TryValidateObject(entityToValidate, context, results, true)) {
          foreach (ValidationResult item in results) {
            if (((string[])item.MemberNames).Length > 0) {
              propName = ((string[])item.MemberNames)[0];
            }
            ValidationMessages.Add(new EFValidationMessage { Message = item.ErrorMessage, PropertyName = propName });
          }
        }
      }

      return (ValidationMessages.Count > 0);
    }
    #endregion

    #region ThrowDbException Method
    public virtual void ThrowDbException(Exception ex, DbContext db, string exceptionMsg)
    {
      exceptionMsg = string.IsNullOrEmpty(exceptionMsg) ? string.Empty : exceptionMsg + " - ";

      EFDbException exc = new EFDbException(exceptionMsg + ex.Message, ex) {
        ConnectionString = db.Database.Connection.ConnectionString,
        Database = db.Database.Connection.Database,
        DataSource = db.Database.Connection.DataSource,
        SQL = SQL,
        SqlParameters = Parameters,
        WorkstationId = Environment.MachineName
      };

      // Set the last exception
      LastException = exc;

      throw exc;
    }
    #endregion
  }
}
