﻿using System;
using System.ComponentModel;
using System.Reflection;

namespace Common.EF.Library
{
  /// <summary>
  /// This class implements the INotifyPropertyChanged Event Procedure
  /// </summary>
  public class EFCommonBase : INotifyPropertyChanged
  {
    #region INotifyPropertyChanged
    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// </summary>
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// The event is only invoked if data binding is used
    /// </summary>
    /// <param name="propertyName">The property name that is changing</param>
    protected void RaisePropertyChanged(string propertyName)
    {
      // Grab a handler
      PropertyChangedEventHandler handler = this.PropertyChanged;
      // Only raise event if handler is connected
      if (handler != null) {
        PropertyChangedEventArgs args = new PropertyChangedEventArgs(propertyName);

        // Raise the PropertyChanged event.
        handler(this, args);
      }
    }
    #endregion

    #region Private Variables
    private Exception _LastException = null;
    private int _RowsAffected = 0;
    private string _LastExceptionMessage;
    #endregion

    #region Public Properties  
    /// <summary>
    /// Get/Set LastException
    /// </summary>
    public Exception LastException
    {
      get { return _LastException; }
      set {
        _LastException = value;
        LastExceptionMessage = (value == null ? string.Empty : value.Message);
        RaisePropertyChanged("LastException");
      }
    }

    /// <summary>
    /// Get/Set LastExceptionMessage
    /// </summary>
    public string LastExceptionMessage
    {
      get { return _LastExceptionMessage; }
      set {
        _LastExceptionMessage = value;
        RaisePropertyChanged("LastExceptionMessage");
      }
    }

    /// <summary>
    /// Get/Set Rows Affected
    /// </summary>
    public int RowsAffected
    {
      get { return _RowsAffected; }
      set {
        _RowsAffected = value;
        RaisePropertyChanged("RowsAffected");
      }
    }
    #endregion

    #region Clone Method
    public void Clone<T>(T original, T cloneTo)
    {
      if (original != null && cloneTo != null) {
        // Use reflection so the RaisePropertyChanged event is fired for each property
        foreach (var prop in typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance)) {
          var value = prop.GetValue(original, null);
          prop.SetValue(cloneTo, value, null);
        }
      }
    }
    #endregion
  }
}
