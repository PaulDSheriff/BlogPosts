﻿using System;
using System.Collections.ObjectModel;

namespace Common.EF.Library
{
  public class EFViewModelBase : EFCommonBase
  {
    #region Private Variables
    private ObservableCollection<EFValidationMessage> _ValidationMessages = new ObservableCollection<EFValidationMessage>();
    private bool _IsValidationVisible = false;
    #endregion

    #region Public Properties
    public ObservableCollection<EFValidationMessage> ValidationMessages
    {
      get { return _ValidationMessages; }
      set {
        _ValidationMessages = value;
        RaisePropertyChanged("ValidationMessages");
      }
    }

    public bool IsValidationVisible
    {
      get { return _IsValidationVisible; }
      set {
        _IsValidationVisible = value;
        RaisePropertyChanged("IsValidationVisible");
      }
    }
    #endregion

    #region Clear Method
    public virtual void Clear()
    {
      ValidationMessages.Clear();
      IsValidationVisible = false;
      LastExceptionMessage = string.Empty;
      LastException = null;
      RowsAffected = 0;
    }
    #endregion

    #region DisplayStatusMessage Method
    public virtual void DisplayStatusMessage(string msg = "")
    {      
    }
    #endregion

    #region Validate Method
    public virtual bool Validate()
    {
      return true;
    }
    #endregion

    #region ValidationFailed Method
    public virtual void ValidationFailed(EFValidationException ex)
    {
      ValidationMessages = new ObservableCollection<EFValidationMessage>(ex.ValidationMessages);
      IsValidationVisible = true;
    }
    #endregion

    #region PublishException Method
    public void PublishException(Exception ex)
    {
      LastException = ex;
      LastExceptionMessage = ex.ToString();

      // Publish Exception
      EFExceptionManager.Instance.Publish(ex);
    }
    #endregion

    #region Close Method
    public virtual void Close(bool wasCancelled = true)
    {      
    }
    #endregion

    #region Dispose Method
    public virtual void Dispose()
    {
    }
    #endregion
  }
}
