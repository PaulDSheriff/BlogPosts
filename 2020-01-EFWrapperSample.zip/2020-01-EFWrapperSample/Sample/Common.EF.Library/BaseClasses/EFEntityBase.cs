﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Common.EF.Library
{
  public class EFEntityBase
  {
    [NotMapped]
    public int RETURN_VALUE { get; set; }
  }
}
