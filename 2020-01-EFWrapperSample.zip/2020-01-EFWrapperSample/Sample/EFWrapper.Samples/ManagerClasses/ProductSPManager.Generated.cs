﻿using System;
using System.Collections.Generic;
using EFWrapper.Samples.AppLayer;

namespace EFWrapper.Samples.DataLayer
{
  public partial class ProductSPManager : AppManager
  {
    #region GetAll Method
    public List<Product> GetAll()
    {
      List<Product> ret = new List<Product>();

      // Clear all properties
      Clear();

      // Create SQL to call stored procedure
      SQL = "SalesLT.Product_GetAll";

      // Execute Query
      ret = ExecuteQuery<Product>("Exception in ProductSPManager.GetAll()");

      return ret;
    }
    #endregion

    #region Get Method
    public Product Get(int productId)
    {
      Product ret = new Product();

      // Clear all properties
      Clear();

      // Create SQL to call stored procedure
      SQL = "SalesLT.Product_Get @ProductID";

      // Create parameters
      AddParameter("ProductID", (object)productId, false);

      // Execute Query
      var list = ExecuteQuery<Product>("Exception in ProductSPManager.Get()");
      if (list != null && list.Count > 0) {
        ret = list[0];
      }

      return ret;
    }
    #endregion

    #region Count Method
    public int Count()
    {
      int ret = 0;

      // Clear all properties
      Clear();

      // Create SQL to count records
      SQL = "SalesLT.Product_Count @Name, @ProductNumber, @BeginningCost, @EndingCost";

      // Add parameters to CommandObject
      AddParameter("Name", DBNull.Value, true);
      AddParameter("ProductNumber", DBNull.Value, true);
      AddParameter("BeginningCost", DBNull.Value, true);
      AddParameter("EndingCost", DBNull.Value, true);

      // Execute Query
      ret = ExecuteScalar<int>("Exception in ProductManager.Count()");

      return ret;
    }
    #endregion

    #region Insert Method
    public int Insert(Product entity)
    {
      // Clear all properties
      Clear();

      // Attempt to validate the data, a ValidationException is thrown if validation rules fail
      Validate<Product>(entity);

      // Create SQL to call stored procedure
      SQL = "SalesLT.Product_Insert @Name, @ProductNumber, @Color, @StandardCost, @ListPrice, @Size, @Weight, @ProductCategoryID, @ProductModelID, @SellStartDate, @SellEndDate, @DiscontinuedDate, @ModifiedDate, @ProductID OUTPUT";

      // Create standard insert parameters
      BuildInsertUpdateParameters(entity);

      // Create parameter to get IDENTITY value generated
      AddParameter("@ProductID", -1, true, System.Data.DbType.Int32, System.Data.ParameterDirection.Output);

      // Execute Query
      RowsAffected = ExecuteNonQuery("Exception in ProductSPManager.InsertUsingStoredProcedure()", true, "@ProductID");
      // Get the ProductID generated from the IDENTITY 
      entity.ProductID = (int)IdentityGenerated;

      return RowsAffected;
    }
    #endregion

    #region Update Method
    public int Update(Product entity)
    {
      // Clear all properties
      Clear();

      // Attempt to validate the data, a ValidationException is thrown if validation rules fail
      Validate<Product>(entity);

      // Create SQL to call stored procedure
      SQL = "SalesLT.Product_Update @Name, @ProductNumber, @Color, @StandardCost, @ListPrice, @Size, @Weight, @ProductCategoryID, @ProductModelID, @SellStartDate, @SellEndDate, @DiscontinuedDate, @ModifiedDate, @ProductID";

      // Create standard update parameters
      BuildInsertUpdateParameters(entity);
      // Primary Key parameter
      AddParameter("@ProductId", (object)entity.ProductID, false);

      // Execute Query
      RowsAffected = ExecuteNonQuery("Exception in ProductSPManager.Update()");

      return RowsAffected;
    }
    #endregion

    #region Delete Method
    public int Delete(Product entity)
    {
      // Clear all properties
      Clear();

      // Create SQL to call stored procedure
      SQL = "SalesLT.Product_Delete @ProductID";

      // Create parameters
      AddParameter("@ProductId", (object)entity.ProductID, false);

      // Execute Query
      RowsAffected = ExecuteNonQuery("Exception in ProductSPManager.Delete()");

      return RowsAffected;
    }
    #endregion

    #region BuildInsertUpdateParameters Method
    protected virtual void BuildInsertUpdateParameters(Product entity)
    {
      // Add parameters to CommandObject
      AddParameter("Name", (object)entity.Name, false);
      AddParameter("ProductNumber", (object)entity.ProductNumber, false);
      AddParameter("Color", (object)entity.Color, false);
      AddParameter("StandardCost", (object)entity.StandardCost, false);
      AddParameter("ListPrice", (object)entity.ListPrice, false);
      AddParameter("Size", (object)entity.Size ?? DBNull.Value, true);
      AddParameter("Weight", (object)entity.Weight ?? DBNull.Value, true);
      AddParameter("ProductCategoryID", (object)entity.ProductCategoryID, false);
      AddParameter("ProductModelID", (object)entity.ProductModelID, false);
      AddParameter("SellStartDate", (object)entity.SellStartDate, false);
      AddParameter("SellEndDate", (object)entity.SellEndDate ?? DBNull.Value, true);
      AddParameter("DiscontinuedDate", (object)entity.DiscontinuedDate ?? DBNull.Value, true);
      AddParameter("ModifiedDate", (object)entity.ModifiedDate, false);
    }
    #endregion
  }
}
