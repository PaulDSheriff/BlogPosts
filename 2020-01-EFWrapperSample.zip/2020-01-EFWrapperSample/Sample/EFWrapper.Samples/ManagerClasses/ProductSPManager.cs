﻿using System;
using System.Collections.Generic;
using Common.EF.Library;
using EFWrapper.Samples.AppLayer;

namespace EFWrapper.Samples.DataLayer
{
  public partial class ProductSPManager : AppManager
  {
    #region Search Method
    public List<Product> Search(ProductSearch search)
    {
      List<Product> ret = new List<Product>();

      // Clear all properties
      Clear();

      // Create SQL to call stored procedure
      SQL = "SalesLT.Product_Search @Name, @ProductNumber, @BeginningCost, @EndingCost";

      // Create parameters
      AddParameter("Name", (object)search.Name ?? DBNull.Value, true);
      AddParameter("ProductNumber", (object)search.ProductNumber ?? DBNull.Value, true);
      AddParameter("BeginningCost", (object)search.BeginningCost ?? DBNull.Value, true);
      AddParameter("EndingCost", (object)search.EndingCost ?? DBNull.Value, true);

      // Execute Query
      ret = ExecuteQuery<Product>("Exception in ProductSPManager.Search()");

      return ret;
    }
    #endregion

    #region Count Method
    public int Count(ProductSearch search)
    {
      int ret = 0;

      // Clear all properties
      Clear();

      // Create SQL to count records
      SQL = "SalesLT.Product_Count @Name, @ProductNumber, @BeginningCost, @EndingCost";

      // Create parameters
      AddParameter("Name", (object)search.Name ?? DBNull.Value, true);
      AddParameter("ProductNumber", (object)search.ProductNumber ?? DBNull.Value, true);
      AddParameter("BeginningCost", (object)search.BeginningCost ?? DBNull.Value, true);
      AddParameter("EndingCost", (object)search.EndingCost ?? DBNull.Value, true);

      // Execute Query
      ret = ExecuteScalar<int>("Exception in ProductManager.Count(search)");

      return ret;
    }
    #endregion

    #region Validate Method
    public override bool Validate<T>(T entityToValidate)
    {
      // Check all Data Annotations first
      bool ret = base.Validate(entityToValidate);

      // Cast to a Product class
      Product entity = entityToValidate as Product;

      // Add other business rules here
      if (entity.Name.Length < 2) {
        AddValidationMessage("Name", "Name must be greater than 2 characters in length.");
      }

      if (ValidationMessages.Count > 0) {
        throw new EFValidationException(ValidationMessages);
      }

      return ret;
    }
    #endregion
  }
}
