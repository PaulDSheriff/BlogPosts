﻿using System;
using System.Collections.Generic;
using System.Linq;
using Common.EF.Library;
using EFWrapper.Samples.AppLayer;

namespace EFWrapper.Samples.DataLayer
{
  public partial class ProductManager : AppManager
  {
    #region Search Method
    public List<Product> Search(ProductSearch search)
    {
      List<Product> ret = new List<Product>();

      // Clear all properties
      Clear();

      // Create SQL to SELECT FROM SalesLT.Product
      SQL = "SELECT [ProductID],[Name],[ProductNumber],[Color],[StandardCost],[ListPrice],[Size],[Weight],[ProductCategoryID],[ProductModelID],[SellStartDate],[SellEndDate],[DiscontinuedDate],[ModifiedDate] FROM SalesLT.Product";
      SQL += " WHERE (Name LIKE COALESCE(@Name, '') + '%')";
      SQL += " AND   (ProductNumber LIKE COALESCE(@ProductNumber, '') + '%')";
      SQL += " AND   (ISNULL(@BeginningCost, -1) = -1 OR StandardCost >= @BeginningCost)";
      SQL += " AND   (ISNULL(@EndingCost, -1) = -1 OR StandardCost <= @EndingCost)";

      // Create parameters
      AddParameter("Name", (object)search.Name ?? DBNull.Value, true);
      AddParameter("ProductNumber", (object)search.ProductNumber ?? DBNull.Value, true);
      AddParameter("BeginningCost", (object)search.BeginningCost ?? DBNull.Value, true);
      AddParameter("EndingCost", (object)search.EndingCost ?? DBNull.Value, true);

      // Execute Query
      ret = ExecuteQuery<Product>("Exception in ProductManager.Search()");

      return ret;
    }
    #endregion

    #region Count Method
    public int Count(ProductSearch search)
    {
      int ret = 0;

      // Clear all properties
      Clear();

      // Create SQL to count records
      SQL = "SELECT Count(*) FROM SalesLT.Product";
      SQL += " WHERE (Name LIKE COALESCE(@Name, '') + '%')";
      SQL += " AND   (ProductNumber LIKE COALESCE(@ProductNumber, '') + '%')";
      SQL += " AND   (ISNULL(@BeginningCost, -1) = -1 OR StandardCost >= @BeginningCost)";
      SQL += " AND   (ISNULL(@EndingCost, -1) = -1 OR StandardCost <= @EndingCost)";

      // Create parameters
      AddParameter("Name", (object)search.Name ?? DBNull.Value, true);
      AddParameter("ProductNumber", (object)search.ProductNumber ?? DBNull.Value, true);
      AddParameter("BeginningCost", (object)search.BeginningCost ?? DBNull.Value, true);
      AddParameter("EndingCost", (object)search.EndingCost ?? DBNull.Value, true);

      // Execute Query
      ret = ExecuteScalar<int>("Exception in ProductManager.Count(search)");

      return ret;
    }
    #endregion

    #region Validate Method
    public override bool Validate<T>(T entityToValidate)
    {
      // Check all Data Annotations first
      bool ret = base.Validate(entityToValidate);

      // Cast to a Product class
      Product entity = entityToValidate as Product;

      // Add other business rules here
      if (entity.Name.Length < 2) {
        AddValidationMessage("Name", "Name must be greater than 2 characters in length.");
      }

      if (ValidationMessages.Count > 0) {
        throw new EFValidationException(ValidationMessages);
      }

      return ret;
    }
    #endregion

    #region Methods that use EF Properties and LINQ

    #region GetUsingProperties Method
    public Product GetUsingProperties(int productId)
    {
      Product ret = new Product();

      // Clear all properties
      Clear();
      // Create instance of DbContext
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          // Execute the dynamic SQL
          ret = db.Products.Where(p => p.ProductID == productId).SingleOrDefault();
        }
        catch (Exception ex) {
          // Throw a custom exception
          ThrowDbException(ex, db, "Exception in ProductManager.Get()");
        }
      }

      return ret;
    }
    #endregion

    #region GetAllUsingProperties Method
    public List<Product> GetAllUsingProperties()
    {
      List<Product> ret = new List<Product>();

      // Clear all properties
      Clear();
      // Create instance of DbContext
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          // Execute the dynamic SQL
          ret = db.Products.ToList();
        }
        catch (Exception ex) {
          // Throw a custom exception
          ThrowDbException(ex, db, "Exception in ProductManager.GetAll()");
        }
      }

      return ret;
    }
    #endregion

    #region SearchUsingProperties Method
    public List<Product> SearchUsingProperties(ProductSearch search)
    {
      List<Product> ret = new List<Product>();

      // Clear all properties
      Clear();
      // Create instance of DbContext
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          // Get query object from Products DbSet property
          IQueryable<Product> query = db.Products;

          // Create appropriate WHERE clauses
          if (search.ProductId.HasValue) {
            query = query.Where(p => p.ProductID == search.ProductId);
          }
          if (!string.IsNullOrEmpty(search.Name)) {
            query = query.Where(p => p.Name.StartsWith(search.Name));
          }
          if (!string.IsNullOrEmpty(search.ProductNumber)) {
            query = query.Where(p => p.ProductNumber.StartsWith(search.ProductNumber));
          }
          if (search.BeginningCost.HasValue) {
            query = query.Where(p => p.StandardCost >= search.BeginningCost.Value);
          }
          if (search.EndingCost.HasValue) {
            query = query.Where(p => p.StandardCost <= search.EndingCost.Value);
          }

          // Execute the dynamic SQL
          ret = query.ToList();
        }
        catch (Exception ex) {
          // Throw a custom exception
          ThrowDbException(ex, db, "Exception in ProductManager.Search()");
        }
      }

      return ret;
    }
    #endregion
    #endregion
  }
}
