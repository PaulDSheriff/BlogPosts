﻿using System;
using System.Collections.Generic;
using EFWrapper.Samples.AppLayer;

namespace EFWrapper.Samples.DataLayer
{
  public partial class ProductManager : AppManager
  {
    #region GetAll Method
    public List<Product> GetAll()
    {
      List<Product> ret = new List<Product>();

      // Clear all properties
      Clear();

      // Create SQL to SELECT FROM SalesLT.Product
      SQL = "SELECT * FROM SalesLT.Product";

      // Execute Query
      ret = ExecuteQuery<Product>("Exception in ProductManager.GetAll()");

      return ret;
    }
    #endregion

    #region Get Method
    public Product Get(int productId)
    {
      Product ret = new Product();

      // Clear all properties
      Clear();

      // Create SQL to SELECT FROM SalesLT.Product
      SQL = "SELECT * FROM SalesLT.Product WHERE ProductID = @ProductID";

      // Create parameters
      AddParameter("ProductID", (object)productId, false);

      // Execute Query
      var list = ExecuteQuery<Product>("Exception in ProductManager.Get()");
      if (list != null && list.Count > 0) {
        ret = list[0];
      }

      return ret;
    }
    #endregion

    #region Count Method
    public int Count()
    {
      int ret = 0;

      // Clear all properties
      Clear();

      // Create SQL to count records
      SQL = "SELECT COUNT(*) FROM SalesLT.Product";

      // Execute Query
      ret = ExecuteScalar<int>("Exception in ProductManager.Count()");

      return ret;
    }
    #endregion

    #region Insert Method
    public int Insert(Product entity)
    {
      // Clear all properties
      Clear();

      // Attempt to validate the data, a ValidationException is thrown if validation rules fail
      Validate<Product>(entity);

      // Create SQL to INSERT INTO SalesLT.Product using dynamic SQL
      SQL = "INSERT INTO SalesLT.Product(Name, ProductNumber, Color, StandardCost, ListPrice, Size, Weight, ProductCategoryID, ProductModelID, SellStartDate, SellEndDate, DiscontinuedDate, ModifiedDate) VALUES(@Name, @ProductNumber, @Color, @StandardCost, @ListPrice, @Size, @Weight, @ProductCategoryID, @ProductModelID, @SellStartDate, @SellEndDate, @DiscontinuedDate, @ModifiedDate); SELECT @ProductID = SCOPE_IDENTITY();";

      // Create standard insert parameters
      BuildInsertUpdateParameters(entity);

      // Create parameter to get IDENTITY value generated
      AddParameter("@ProductID", -1, true, System.Data.DbType.Int32, System.Data.ParameterDirection.Output);

      // Execute Query
      RowsAffected = ExecuteNonQuery("Exception in ProductManager.Insert()", true, "@ProductID");

      // Get the ProductID generated from the IDENTITY 
      entity.ProductID = (int)IdentityGenerated;

      return RowsAffected;
    }
    #endregion

    #region Update Method
    public int Update(Product entity)
    {
      // Clear all properties
      Clear();

      // Attempt to validate the data, a ValidationException is thrown if validation rules fail
      Validate<Product>(entity);

      // Create SQL to UPDATE SalesLT.Product using dynamic SQL
      SQL = "UPDATE SalesLT.Product SET Name=@Name, ProductNumber=@ProductNumber, Color=@Color, StandardCost=@StandardCost, ListPrice=@ListPrice, Size=@Size, Weight=@Weight, ProductCategoryID=@ProductCategoryID, ProductModelID=@ProductModelID, SellStartDate=@SellStartDate, SellEndDate=@SellEndDate, DiscontinuedDate=@DiscontinuedDate, ModifiedDate=@ModifiedDate WHERE ProductID = @ProductID";

      // Create standard update parameters
      BuildInsertUpdateParameters(entity);

      // Add primary parameter to CommandObject
      AddParameter("@ProductId", (object)entity.ProductID, false);

      // Execute Query
      RowsAffected = ExecuteNonQuery("Exception in ProductManager.Update()");

      return RowsAffected;
    }
    #endregion

    #region Delete Method
    public int Delete(Product entity)
    {
      // Clear all properties
      Clear();

      // Create SQL to DELETE FROM SalesLT.Product using dynamic SQL
      SQL = "DELETE FROM SalesLT.Product WHERE ProductID = @ProductID";

      // Create parameters
      AddParameter("@ProductId", (object)entity.ProductID, false);

      // Execute Query
      RowsAffected = ExecuteNonQuery("Exception in ProductManager.Delete()");

      return RowsAffected;
    }
    #endregion

    #region BuildInsertUpdateParameters Method
    protected virtual void BuildInsertUpdateParameters(Product entity)
    {
      // Add parameters to CommandObject
      AddParameter("Name", (object)entity.Name, false);
      AddParameter("ProductNumber", (object)entity.ProductNumber, false);
      AddParameter("Color", (object)entity.Color, false);
      AddParameter("StandardCost", (object)entity.StandardCost, false);
      AddParameter("ListPrice", (object)entity.ListPrice, false);
      AddParameter("Size", (object)entity.Size ?? DBNull.Value, true);
      AddParameter("Weight", (object)entity.Weight ?? DBNull.Value, true);
      AddParameter("ProductCategoryID", (object)entity.ProductCategoryID, false);
      AddParameter("ProductModelID", (object)entity.ProductModelID, false);
      AddParameter("SellStartDate", (object)entity.SellStartDate, false);
      AddParameter("SellEndDate", (object)entity.SellEndDate ?? DBNull.Value, true);
      AddParameter("DiscontinuedDate", (object)entity.DiscontinuedDate ?? DBNull.Value, true);
      AddParameter("ModifiedDate", (object)entity.ModifiedDate, false);
    }
    #endregion
  }
}
