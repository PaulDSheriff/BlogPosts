﻿using Common.EF.Library;

namespace EFWrapper.Samples.DataLayer
{
  public partial class Product : EFEntityBase
  {
    public override string ToString()
    {
      return ProductNumber + " (" + ProductID.ToString() + ")";
    }
  }
}
