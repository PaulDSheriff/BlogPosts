﻿using System.Windows;
using EFWrapper.Samples.AppLayer;

namespace EFWrapper.Samples
{
  public partial class App : Application
  {
    protected override void OnStartup(StartupEventArgs e)
    {
      base.OnStartup(e);
    }
  }
}
