﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using Common.EF.Library;

namespace EFWrapper.Samples.DataLayer
{
  public partial class AdventureWorksLTDbContext : DbContext
  {
    public AdventureWorksLTDbContext() : base("name=AdventureWorksLT")
    {
    }

    public virtual DbSet<Product> Products { get; set; }

    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    {
      // Don't let EF create migrations or check database for model consistency
      Database.SetInitializer<AdventureWorksLTDbContext>(null);

      base.OnModelCreating(modelBuilder);
    }

    public List<EFValidationMessage> CreateValidationMessages(
    DbEntityValidationException ex)
    {
      List<EFValidationMessage> ret = new List<EFValidationMessage>();

      // Retrieve the error messages from EF
      foreach (DbValidationError error in ex.EntityValidationErrors
                     .SelectMany(x => x.ValidationErrors)) {
        ret.Add(new EFValidationMessage {
          Message = error.ErrorMessage,
          PropertyName = error.PropertyName
        });
      }

      return ret;
    }
  }
}
