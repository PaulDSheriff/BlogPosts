﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using EFWrapper.Samples.AppLayer;
using EFWrapper.Samples.DataLayer;

namespace EFWrapper.Samples.ViewModelLayer
{
  public class EFRawSPViewModel : AppViewModelBase
  {
    #region Properties
    private Product _Entity = new Product();
    private ObservableCollection<Product> _DataCollection = new ObservableCollection<Product>();

    public Product Entity
    {
      get { return _Entity; }
      set {
        _Entity = value;
        RaisePropertyChanged("Entity");
      }
    }

    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region Clear Method Override
    public override void Clear()
    {
      DataCollection = new ObservableCollection<Product>();
      Entity = new Product();

      base.Clear();
    }
    #endregion

    #region GetAll Method
    public void GetAll()
    {
      // Create SQL to call stored procedure
      string SQL = "SalesLT.Product_GetAll";
      
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          // Call Stored Proc with no parameters
          DataCollection = new ObservableCollection<Product>(
            db.Database.SqlQuery<Product>(SQL));
        }
        catch (Exception ex) {
          PublishException(ex);
        }
      }
    }
    #endregion

    #region Get Method
    public Product Get(int productId)
    {
      // Create SQL to call stored procedure
      string SQL = "SalesLT.Product_Get @ProductID";
      List<SqlParameter> parameters = new List<SqlParameter>
      {
        // Create parameters
        new SqlParameter { ParameterName = "@ProductID", Value = (object)productId, IsNullable = false }
      };

      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          // Call Stored Proc with no parameters
          DataCollection = new ObservableCollection<Product>(
            db.Database.SqlQuery<Product>(SQL, parameters.ToArray()));
        }
        catch (Exception ex) {
          PublishException(ex);
        }
      }

      return Entity;
    }
    #endregion

    #region Count Method
    public int Count(ProductSearch search)
    {
      // Create SQL to call stored procedure
      string SQL = "SalesLT.Product_Count @Name, @ProductNumber, @BeginningCost, @EndingCost";
      List<SqlParameter> parameters = new List<SqlParameter>
      {
        // Create parameters
        new SqlParameter { ParameterName = "@Name", Value = (object)search.Name ?? DBNull.Value, IsNullable = true },
        new SqlParameter { ParameterName = "@ProductNumber", Value = (object)search.ProductNumber ?? DBNull.Value, IsNullable = true },
        new SqlParameter { ParameterName = "@BeginningCost", Value = (object)search.BeginningCost ?? DBNull.Value, IsNullable = true },
        new SqlParameter { ParameterName = "@EndingCost", Value = (object)search.EndingCost ?? DBNull.Value, IsNullable = true }
      };

      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          // Call Stored Proc with parameters
          RowsAffected = db.Database.SqlQuery<int>(SQL, parameters.ToArray()).SingleOrDefault<int>();
        }
        catch (Exception ex) {
          PublishException(ex);
        }
      }

      return RowsAffected;
    }
    #endregion

    #region Search Method
    public void Search(ProductSearch search)
    {
      // Create SQL to call stored procedure
      string SQL = "SalesLT.Product_Search @Name, @ProductNumber, @BeginningCost, @EndingCost";
      List<SqlParameter> parameters = new List<SqlParameter>
      {
        // Create parameters
        new SqlParameter { ParameterName = "@Name", Value = (object)search.Name ?? DBNull.Value, IsNullable = true },
        new SqlParameter { ParameterName = "@ProductNumber", Value = (object)search.ProductNumber ?? DBNull.Value, IsNullable = true },
        new SqlParameter { ParameterName = "@BeginningCost", Value = (object)search.BeginningCost ?? DBNull.Value, IsNullable = true },
        new SqlParameter { ParameterName = "@EndingCost", Value = (object)search.EndingCost ?? DBNull.Value, IsNullable = true }
      };

      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          // Call Stored Proc with parameters
          DataCollection = new ObservableCollection<Product>(
            db.Database.SqlQuery<Product>(SQL, parameters.ToArray()));
        }
        catch (Exception ex) {
          PublishException(ex);
        }
      }
    }
    #endregion
  }
}
