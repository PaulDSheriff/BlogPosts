﻿using System;
using System.Collections.ObjectModel;
using Common.EF.Library;
using EFWrapper.Samples.AppLayer;
using EFWrapper.Samples.DataLayer;

namespace EFWrapper.Samples.ViewModelLayer
{
  public class ProductViewModel : AppViewModelBase
  {
    #region Properties
    private Product _Entity = new Product();
    private ObservableCollection<Product> _DataCollection = new ObservableCollection<Product>();
    
    public Product Entity
    {
      get { return _Entity; }
      set {
        _Entity = value;
        RaisePropertyChanged("Entity");
      }
    }

    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region Clear Method Override
    public override void Clear()
    {
      DataCollection = new ObservableCollection<Product>();
      Entity = new Product();

      base.Clear();
    }
    #endregion

    #region GetAll Method
    public void GetAll()
    {
      System.Diagnostics.Stopwatch stopWatch = new System.Diagnostics.Stopwatch();
      stopWatch.Start();

      ProductManager mgr = new ProductManager();
            
      try {
        DataCollection = new ObservableCollection<Product>(mgr.GetAll());
      }
      catch (Exception ex) {
        PublishException(ex);
      }

      stopWatch.Stop();
      // Get the elapsed time as a TimeSpan value.
      TimeSpan ts = stopWatch.Elapsed;
      // Format and display the TimeSpan value.
      Console.WriteLine("RunTime " + String.Format("{0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10));
    }
    #endregion

    #region Get Method
    public Product Get(int productId)
    {
      ProductManager mgr = new ProductManager();

      DataCollection = new ObservableCollection<Product>();
      try {
        Entity = mgr.Get(productId);
        DataCollection.Add(Entity);
        RaisePropertyChanged("DataCollection");
      }
      catch (Exception ex) {
        PublishException(ex);
      }

      return Entity;
    }
    #endregion

    #region Search Method
    public void Search(ProductSearch search)
    {
      ProductManager mgr = new ProductManager();
            
      try {
        DataCollection = new ObservableCollection<Product>(mgr.Search(search));
      }
      catch (Exception ex) {
        PublishException(ex);
      }
    }
    #endregion

    #region Count Method
    public int Count(ProductSearch search)
    {
      ProductManager mgr = new ProductManager();

      try {
        RowsAffected = mgr.Count(search);

        ResultText = "Count Successful" + Environment.NewLine + "Total Rows: " + RowsAffected.ToString();
      }
      catch (Exception ex) {
        PublishException(ex);
      }

      return RowsAffected;
    }
    #endregion

    #region Insert Method
    public void Insert()
    {
      ProductManager mgr = new ProductManager();

      try {
        RowsAffected = mgr.Insert(Entity);

        if (RowsAffected > 0) {
          ResultText = "Insert Successful" + Environment.NewLine + "Rows Affected: " + RowsAffected.ToString() + Environment.NewLine + "ProductID: " + Entity.ProductID.ToString();
          RaisePropertyChanged("Entity");
        }
      }
      catch (EFValidationException ex) {
        ValidationFailed(ex);
      }
      catch (Exception ex) {
        PublishException(ex);
      }
    }
    #endregion

    #region Update Method
    public void Update()
    {
      ProductManager mgr = new ProductManager();

      try {
        RowsAffected = mgr.Update(Entity);

        if (RowsAffected > 0) {
          ResultText = "Update Successful" + Environment.NewLine + "Rows Affected: " + RowsAffected.ToString() + Environment.NewLine + "ProductID: " + Entity.ProductID.ToString();
          RaisePropertyChanged("Entity");
        }
      }
      catch (EFValidationException ex) {
        ValidationFailed(ex);
      }
      catch (Exception ex) {
        PublishException(ex);
      }
    }
    #endregion

    #region Delete Method
    public void Delete()
    {
      ProductManager mgr = new ProductManager();

      try {
        RowsAffected = mgr.Delete(Entity);

        if (RowsAffected > 0) {
          ResultText = "Delete Successful" + Environment.NewLine + "Rows Affected: " + RowsAffected.ToString() + Environment.NewLine + "ProductID: " + Entity.ProductID.ToString();
          RaisePropertyChanged("Entity");
        }
      }
      catch (Exception ex) {
        PublishException(ex);
      }
    }
    #endregion
  }
}
