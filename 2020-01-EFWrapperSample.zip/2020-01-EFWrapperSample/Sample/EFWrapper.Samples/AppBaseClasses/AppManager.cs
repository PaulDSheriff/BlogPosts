﻿using System;
using System.Collections.Generic;
using Common.EF.Library;
using EFWrapper.Samples.DataLayer;

namespace EFWrapper.Samples.AppLayer
{
  public class AppManager : EFDataManagerBase
  {
    #region ExecuteQuery Method
    protected List<T> ExecuteQuery<T>(string exceptionMsg = "")
    {
      List<T> ret = new List<T>();

      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          ret = base.ExecuteSqlQuery<T>(db);
        }
        catch (Exception ex) {
          // Throw a custom exception
          ThrowDbException(ex, db, exceptionMsg);
        }
      }

      return ret;
    }
    #endregion

    #region ExecuteScalar Method
    protected T ExecuteScalar<T>(string exceptionMsg = "")
    {
      T ret = default(T);

      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          ret = base.ExecuteScalar<T>(db);
        }
        catch (Exception ex) {
          // Throw a custom exception
          ThrowDbException(ex, db, exceptionMsg);
        }
      }

      return ret;
    }
    #endregion

    #region ExecuteNonQuery Method
    protected int ExecuteNonQuery(string exceptionMsg, bool getIdentity = false, string identityParamName = "")
    {
      // Create instance of DbContext
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          // Execute the action query
          RowsAffected = ExecuteSqlCommand(db);
          if (getIdentity) {
            IdentityGenerated = GetParameter(identityParamName).Value;
          }
        }
        catch (Exception ex) {
          // Throw a custom exception
          ThrowDbException(ex, db, exceptionMsg);
        }
      }

      return RowsAffected;
    }
    #endregion
  }
}
