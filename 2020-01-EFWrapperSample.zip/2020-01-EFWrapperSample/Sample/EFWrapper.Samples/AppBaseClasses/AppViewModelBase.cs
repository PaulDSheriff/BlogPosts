﻿using Common.EF.Library;

namespace EFWrapper.Samples.AppLayer
{
  /// <summary>
  /// This class is the base class for all view models for this specific application
  /// </summary>
  public class AppViewModelBase : EFViewModelBase
  {
    private string _ResultText;

    public string ResultText
    {
      get { return _ResultText; }
      set {
        _ResultText = value;
        RaisePropertyChanged("ResultText");
      }
    }

    #region Clear Method Override
    public override void Clear()
    {
      ResultText = string.Empty;

      base.Clear();
    }
    #endregion
  }
}
