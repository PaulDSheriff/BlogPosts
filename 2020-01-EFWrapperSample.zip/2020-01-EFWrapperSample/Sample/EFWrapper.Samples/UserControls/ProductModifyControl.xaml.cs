﻿using System;
using System.Windows;
using System.Windows.Controls;
using EFWrapper.Samples.DataLayer;
using EFWrapper.Samples.ViewModelLayer;

namespace EFWrapper.Samples.UserControls
{
  public partial class ProductModifyControl : UserControl
  {
    public ProductModifyControl()
    {
      InitializeComponent();

      _viewModel = (ProductViewModel)this.Resources["viewModel"];

      _viewModel.Entity = new Product {
        Name = "TEST",
        ProductNumber = "TEST-01",
        Color = "Red",
        StandardCost = 1.50M,
        ListPrice = 5.00M,
        Size = "99",
        Weight = 100M,
        ProductCategoryID = 6,
        ProductModelID = 30,
        SellStartDate = DateTime.Now,
        ModifiedDate = DateTime.Now
      };
    }

    private ProductViewModel _viewModel;    

    private void InsertButton_Click(object sender, RoutedEventArgs e)
    {      
      _viewModel.Insert();
    }

    private void UpdateButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Update();
    }

    private void DeleteButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Delete();
    }
  }
}
