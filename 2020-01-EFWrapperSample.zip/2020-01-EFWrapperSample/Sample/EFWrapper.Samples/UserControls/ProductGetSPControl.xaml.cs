﻿using System.Windows;
using System.Windows.Controls;
using EFWrapper.Samples.DataLayer;
using EFWrapper.Samples.ViewModelLayer;

namespace EFWrapper.Samples.UserControls
{
  public partial class ProductGetSPControl : UserControl
  {
    public ProductGetSPControl()
    {
      InitializeComponent();

      _viewModel = (ProductSPViewModel)this.Resources["viewModel"];
    }

    private ProductSPViewModel _viewModel;

    private void GetAllButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetAll();
    }

    private void GetButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Get(680);
    }

    private void SearchButton_Click(object sender, RoutedEventArgs e)
    {
      // The following is used for searching product data
      ProductSearch search = new ProductSearch {
        //Name = "Cl",
        //ProductNumber = "VE-C304-L",

        BeginningCost = 1,
        EndingCost = 4
      };

      _viewModel.Search(search);
    }

    private void CountButton_Click(object sender, RoutedEventArgs e)
    {
      // The following is used for searching product data
      ProductSearch search = new ProductSearch {
        //Name = "Cl",
        //ProductNumber = "VE-C304-L",

        BeginningCost = 1,
        EndingCost = 4
      };

      _viewModel.Count(search);
    }
  }
}