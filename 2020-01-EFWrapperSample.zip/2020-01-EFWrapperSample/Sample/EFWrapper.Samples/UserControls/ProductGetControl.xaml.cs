﻿using System.Windows;
using System.Windows.Controls;
using EFWrapper.Samples.DataLayer;
using EFWrapper.Samples.ViewModelLayer;

namespace EFWrapper.Samples.UserControls
{
  public partial class ProductGetControl : UserControl
  {
    public ProductGetControl()
    {
      InitializeComponent();

      _viewModel = (ProductViewModel)this.Resources["viewModel"];
    }

    private ProductViewModel _viewModel;
       
    private void GetAllButton_Click(object sender, RoutedEventArgs e)
    {
      // Get all products
      _viewModel.GetAll();
    }

    private void GetButton_Click(object sender, RoutedEventArgs e)
    {
      // Get a single product
      _viewModel.Get(680);
    }

    private void SearchButton_Click(object sender, RoutedEventArgs e)
    {
      // The following is used for searching product data
      ProductSearch search = new ProductSearch {
        //Name = "Cl",
        //ProductNumber = "VE-C304-L",

        BeginningCost = 1,
        EndingCost = 4
      };

      // Search for Products
      _viewModel.Search(search);
    }

    private void CountButton_Click(object sender, RoutedEventArgs e)
    {
      // The following is used for searching product data
      ProductSearch search = new ProductSearch {
        //Name = "Cl",
        //ProductNumber = "VE-C304-L",

        BeginningCost = 1,
        EndingCost = 4
      };

      _viewModel.Count(search);
    }
  }
}