﻿using EFWrapper.Samples.AppLayer;
using EFWrapper.Samples.BusinessDataLayer.EntityClasses;
using System;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Linq;

namespace EFWrapper.Samples.BusinessDataLayer
{
  public partial class MiscManager : AppDataManager
  {
    public string Message { get; set; }

    #region MultipleResultSets Method
    public MultipleResults MultipleResultSets()
    {
      DbDataReader rdr;
      MultipleResults ret = new MultipleResults();

      // Initialize all properties
      Init();

      // Create SQL to call stored procedure
      SQL = "SalesLT.MultipleResults";

      // Execute Query and return DataReader
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext())
      {
        rdr = base.ExecuteReader(db, "Exception in MiscManager.MultipleResultSets()");

        // Get Products from first result set
        // NOTE: The "Products" parameter to the Translate() method must match a DbSet<T> property in the DbContext class
        ret.Products = ((IObjectContextAdapter)db).ObjectContext
          .Translate<Product>(rdr, "Products", MergeOption.AppendOnly).ToList();

        // Move to next result set
        rdr.NextResult();

        // Get Sales Order Details from second result set
        // NOTE: The "SalesOrderDetails" parameter to the Translate() method must match a DbSet<T> property in the DbContext class
        ret.SalesOrderDetails = ((IObjectContextAdapter)db).ObjectContext
          .Translate<SalesOrderDetail>(rdr, "SalesOrderDetails", MergeOption.AppendOnly).ToList();

        rdr.Close();
      }

      return ret;
    }
    #endregion

    #region PerformTransaction Method
    public void PerformTransaction()
    {
      ProductManager mgr = new ProductManager();

      Product prod1 = new Product
      {
        Name = "Transaction 1",
        ProductNumber = "TRN-01",
        Color = "Red",
        StandardCost = 5,
        ListPrice = 10,
        Size = "Small",
        ProductCategoryID = 1,
        ProductModelID = 1,
        SellStartDate = DateTime.Now,
        ModifiedDate = DateTime.Now
      };

      Product prod2 = new Product
      {
        Name = "Transaction 2",
        ProductNumber = "TRN-02",
        Color = "Blue",
        StandardCost = 10,
        ListPrice = 20,
        Size = "Med",
        ProductCategoryID = 1,  // Comment out this line to test rollback
        ProductModelID = 1,
        SellStartDate = DateTime.Now,
        ModifiedDate = DateTime.Now
      };

      // Execute Query and return DataReader
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext())
      {
        using (DbContextTransaction trans = db.Database.BeginTransaction())
        {
          try
          {
            // Submit the two action statements
            mgr.Insert(prod1, db);
            mgr.Insert(prod2, db);

            // Commit the transaction
            trans.Commit();

            Message = "Transaction Committed";
          }
          catch (Exception ex)
          {
            // Rollback the transaction
            trans.Rollback();
            Message = "Transaction Rolled Back";
            // Publish the exception
            System.Diagnostics.Debug.WriteLine(ex);
          }
        }
      }
    }
    #endregion
  }
}
