﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using Common.EF.Library;
using EFWrapper.Samples.AppLayer;
using EFWrapper.Samples.BusinessDataLayer.EntityClasses;

namespace EFWrapper.Samples.BusinessDataLayer
{
  public partial class ProductManager : AppDataManager
  {
    #region GetAll Method
    public List<Product> GetAll()
    {
      List<Product> ret;

      // Initialize all properties
      Init();

      // Create SQL to call stored procedure
      SQL = "SalesLT.Product_GetAll";

      // Execute Query
      ret = ExecuteSqlQuery<Product>("Exception in ProductManager.GetAll()");

      return ret;
    }
    #endregion

    #region Get Method
    public Product Get(int productId)
    {
      Product ret = null;

      // Initialize all properties
      Init();

      // Create SQL to call stored procedure
      SQL = "SalesLT.Product_Get @ProductID";

      // Create parameters
      AddParameter("ProductID", (object)productId, false);

      // Execute Query
      var list = ExecuteSqlQuery<Product>("Exception in ProductManager.Get()");
      if (list != null && list.Count > 0)
      {
        ret = list[0];
      }

      return ret;
    }
    #endregion

    #region Search Method
    public List<Product> Search(ProductSearch search)
    {
      List<Product> ret;

      // Initialize all properties
      Init();

      // Create SQL to call stored procedure
      SQL = "SalesLT.Product_Search @Name, @ProductNumber, @BeginningCost, @EndingCost";

      // Create parameters
      AddParameter("Name", (object)search.Name ?? DBNull.Value, true);
      AddParameter("ProductNumber", (object)search.ProductNumber ?? DBNull.Value, true);
      AddParameter("BeginningCost", (object)search.BeginningCost ?? DBNull.Value, true);
      AddParameter("EndingCost", (object)search.EndingCost ?? DBNull.Value, true);

      // Execute Query
      ret = ExecuteSqlQuery<Product>("Exception in ProductManager.Search()");

      return ret;
    }
    #endregion

    #region Count Method
    public int Count(ProductSearch search)
    {
      int ret;

      // Initialize all properties
      Init();

      // Create SQL to count records
      SQL = "SalesLT.Product_Count @Name, @ProductNumber, @BeginningCost, @EndingCost";

      // Create parameters
      AddParameter("Name", (object)search.Name ?? DBNull.Value, true);
      AddParameter("ProductNumber", (object)search.ProductNumber ?? DBNull.Value, true);
      AddParameter("BeginningCost", (object)search.BeginningCost ?? DBNull.Value, true);
      AddParameter("EndingCost", (object)search.EndingCost ?? DBNull.Value, true);

      // Execute Query
      ret = ExecuteScalar<int>("Exception in ProductManager.Count(search)");

      return ret;
    }
    #endregion

    #region Count Method
    public int Count()
    {
      return Count(new ProductSearch());
    }
    #endregion

    #region Insert Methods
    public int Insert(Product entity)
    {
      return Insert(entity, null);
    }

    public int Insert(Product entity, DbContext db)
    {
      // Initialize all properties
      Init();

      // Attempt to validate the data, a ValidationException is thrown if validation rules fail
      Validate<Product>(entity);

      // Create SQL to call stored procedure
      SQL = "SalesLT.Product_Insert @Name, @ProductNumber, @Color, @StandardCost, @ListPrice, @Size, @Weight, @ProductCategoryID, @ProductModelID, @SellStartDate, @SellEndDate, @DiscontinuedDate, @ModifiedDate, @ProductID OUTPUT";

      // Create standard insert parameters
      BuildInsertUpdateParameters(entity);

      // Create parameter to get IDENTITY value generated
      AddParameter("@ProductID", -1, true, DbType.Int32, System.Data.ParameterDirection.Output);

      if (db == null)
      {
        // Execute Query
        RowsAffected = ExecuteSqlCommand("Exception in ProductManager.Insert()", true, "@ProductID");
        // Get the ProductID generated from the IDENTITY 
        entity.ProductID = (int)IdentityGenerated;
      }
      else
      {
        // Execute the action query using an existing DbContext
        // This is used if you want this to be part of a transaction
        RowsAffected = base.ExecuteSqlCommand(db, "Exception in ProductManager.Insert()");
        // Get the ProductID generated from the IDENTITY 
        entity.ProductID = (int)GetParameter("@ProductID").Value;
      }

      return RowsAffected;
    }
    #endregion

    #region Update Method
    public int Update(Product entity)
    {
      return Update(entity, null);
    }

    public int Update(Product entity, DbContext db)
    {
      // Initialize all properties
      Init();

      // Attempt to validate the data, a ValidationException is thrown if validation rules fail
      Validate<Product>(entity);

      // Create SQL to call stored procedure
      SQL = "SalesLT.Product_Update @Name, @ProductNumber, @Color, @StandardCost, @ListPrice, @Size, @Weight, @ProductCategoryID, @ProductModelID, @SellStartDate, @SellEndDate, @DiscontinuedDate, @ModifiedDate, @ProductID";

      // Create standard update parameters
      BuildInsertUpdateParameters(entity);
      // Primary Key parameter
      AddParameter("@ProductId", (object)entity.ProductID, false);

      if (db == null)
      {
        // Execute Query
        RowsAffected = ExecuteSqlCommand("Exception in ProductManager.Update()");
      }
      else
      {
        // Execute the action query using an existing DbContext
        // This is used if you want this to be part of a transaction
        RowsAffected = base.ExecuteSqlCommand(db, "Exception in ProductManager.Update()");
      }

      return RowsAffected;
    }
    #endregion

    #region Delete Method
    public int Delete(int productId)
    {
      return Delete(productId, null);
    }

    public int Delete(int productId, DbContext db)
    {
      return Delete(new Product() { ProductID = productId }, db);
    }
    public int Delete(Product entity)
    {
      return Delete(entity, null);
    }

    public int Delete(Product entity, DbContext db)
    {
      // Initialize all properties
      Init();

      // Create SQL to call stored procedure
      SQL = "SalesLT.Product_Delete @ProductID";

      // Create parameters
      AddParameter("@ProductId", (object)entity.ProductID, false);

      if (db == null)
      {
        // Execute Query
        RowsAffected = ExecuteSqlCommand("Exception in ProductManager.Delete()");
      }
      else
      {
        // Execute the action query using an existing DbContext
        // This is used if you want this to be part of a transaction
        RowsAffected = base.ExecuteSqlCommand(db, "Exception in ProductManager.Update()");
      }

      return RowsAffected;
    }
    #endregion

    #region BuildInsertUpdateParameters Method
    protected virtual void BuildInsertUpdateParameters(Product entity)
    {
      // Add parameters to CommandObject
      AddParameter("Name", (object)entity.Name, false);
      AddParameter("ProductNumber", (object)entity.ProductNumber, false);
      AddParameter("Color", (object)entity.Color, false);
      AddParameter("StandardCost", (object)entity.StandardCost, false);
      AddParameter("ListPrice", (object)entity.ListPrice, false);
      AddParameter("Size", (object)entity.Size ?? DBNull.Value, true);
      AddParameter("Weight", (object)entity.Weight ?? DBNull.Value, true);
      AddParameter("ProductCategoryID", (object)entity.ProductCategoryID, false);
      AddParameter("ProductModelID", (object)entity.ProductModelID, false);
      AddParameter("SellStartDate", (object)entity.SellStartDate, false);
      AddParameter("SellEndDate", (object)entity.SellEndDate ?? DBNull.Value, true);
      AddParameter("DiscontinuedDate", (object)entity.DiscontinuedDate ?? DBNull.Value, true);
      AddParameter("ModifiedDate", (object)entity.ModifiedDate, false);
    }
    #endregion

    #region Validate Method
    public override bool Validate<T>(T entityToValidate)
    {
      // Check all Data Annotations first
      bool ret = base.Validate(entityToValidate);

      // Cast to a Product class
      Product entity = entityToValidate as Product;

      // Add other business rules here
      if (entity.Name.Length < 2)
      {
        AddValidationMessage("Name", "Name must be greater than 2 characters in length.");
      }

      if (ValidationMessages.Count > 0)
      {
        throw new EFValidationException(ValidationMessages);
      }

      return ret;
    }
    #endregion
  }
}
