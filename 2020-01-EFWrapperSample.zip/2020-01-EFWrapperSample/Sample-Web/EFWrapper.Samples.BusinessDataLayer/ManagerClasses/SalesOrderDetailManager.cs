﻿using System;
using System.Collections.Generic;
using Common.EF.Library;
using EFWrapper.Samples.AppLayer;
using EFWrapper.Samples.BusinessDataLayer.EntityClasses;

namespace EFWrapper.Samples.BusinessDataLayer
{
  public partial class SalesOrderDetailManager : AppDataManager
  {
    #region GetAll Method
    public List<SalesOrderDetail> GetAll()
    {
      List<SalesOrderDetail> ret = new List<SalesOrderDetail>();

      // Initialize all properties
      Init();

      // Create SQL to call stored procedure
      SQL = "SalesLT.SalesOrderDetail_GetAll";

      // Execute Query
      ret = ExecuteSqlQuery<SalesOrderDetail>("Exception in SalesOrderDetailManager.GetAll()");

      return ret;
    }
    #endregion

    #region GetBySalesOrderID Method
    public List<SalesOrderDetail> GetBySalesOrderID(int salesOrderId)
    {
      List<SalesOrderDetail> ret = null;

      // Initialize all properties
      Init();

      // Create SQL to call stored procedure
      SQL = "SalesLT.SalesOrderDetail_GetBySalesOrderID @SalesOrderId";

      // Create parameters
      AddParameter("SalesOrderId", (object)salesOrderId, false);

      // Execute Query
      ret = ExecuteSqlQuery<SalesOrderDetail>("Exception in SalesOrderDetailManager.GetBySalesOrderID()");

      return ret;
    }
    #endregion
  }
}
