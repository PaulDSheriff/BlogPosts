﻿using System;
using System.Collections.Generic;
using Common.EF.Library;
using EFWrapper.Samples.AppLayer;
using EFWrapper.Samples.BusinessDataLayer.EntityClasses;

namespace EFWrapper.Samples.BusinessDataLayer.DynamicSQL
{
  public partial class ProductManager : AppDataManager
  {
    #region GetAll Method
    public List<Product> GetAll()
    {
      List<Product> ret = new List<Product>();

      // Initialize all properties
      Init();

      // Create SQL to SELECT FROM SalesLT.Product
      SQL = "SELECT * FROM SalesLT.Product";

      // Execute Query
      ret = ExecuteSqlQuery<Product>("Exception in ProductManager.GetAll()");

      return ret;
    }
    #endregion

    #region Get Method
    public Product Get(int productId)
    {
      Product ret = null;

      // Initialize all properties
      Init();

      // Create SQL to SELECT FROM SalesLT.Product
      SQL = "SELECT * FROM SalesLT.Product WHERE ProductID = @ProductID";

      // Create parameters
      AddParameter("ProductID", (object)productId, false);

      // Execute Query
      var list = ExecuteSqlQuery<Product>("Exception in ProductManager.Get()");
      if (list != null && list.Count > 0) {
        ret = list[0];
      }

      return ret;
    }
    #endregion

    #region Search Method
    public List<Product> Search(ProductSearch search)
    {
      List<Product> ret = new List<Product>();

      // Initialize all properties
      Init();

      // Create SQL to SELECT FROM SalesLT.Product
      SQL = "SELECT [ProductID],[Name],[ProductNumber],[Color],[StandardCost],[ListPrice],[Size],[Weight],[ProductCategoryID],[ProductModelID],[SellStartDate],[SellEndDate],[DiscontinuedDate],[ModifiedDate],[ThumbNailPhoto],[ThumbnailPhotoFileName],[rowguid] FROM SalesLT.Product";
      SQL += " WHERE (Name LIKE COALESCE(@Name, '') + '%')";
      SQL += " AND   (ProductNumber LIKE COALESCE(@ProductNumber, '') + '%')";
      SQL += " AND   (ISNULL(@BeginningCost, -1) = -1 OR StandardCost >= @BeginningCost)";
      SQL += " AND   (ISNULL(@EndingCost, -1) = -1 OR StandardCost <= @EndingCost)";

      // Create parameters
      AddParameter("Name", (object)search.Name ?? DBNull.Value, true);
      AddParameter("ProductNumber", (object)search.ProductNumber ?? DBNull.Value, true);
      AddParameter("BeginningCost", (object)search.BeginningCost ?? DBNull.Value, true);
      AddParameter("EndingCost", (object)search.EndingCost ?? DBNull.Value, true);

      // Execute Query
      ret = ExecuteSqlQuery<Product>("Exception in ProductManager.Search()");

      return ret;
    }
    #endregion

    #region Count Method
    public int Count(ProductSearch search)
    {
      int ret = 0;

      // Initialize all properties
      Init();

      // Create SQL to count records
      SQL = "SELECT Count(*) FROM SalesLT.Product";
      SQL += " WHERE (Name LIKE COALESCE(@Name, '') + '%')";
      SQL += " AND   (ProductNumber LIKE COALESCE(@ProductNumber, '') + '%')";
      SQL += " AND   (ISNULL(@BeginningCost, -1) = -1 OR StandardCost >= @BeginningCost)";
      SQL += " AND   (ISNULL(@EndingCost, -1) = -1 OR StandardCost <= @EndingCost)";

      // Create parameters
      AddParameter("Name", (object)search.Name ?? DBNull.Value, true);
      AddParameter("ProductNumber", (object)search.ProductNumber ?? DBNull.Value, true);
      AddParameter("BeginningCost", (object)search.BeginningCost ?? DBNull.Value, true);
      AddParameter("EndingCost", (object)search.EndingCost ?? DBNull.Value, true);

      // Execute Query
      ret = ExecuteScalar<int>("Exception in ProductManager.Count(search)");

      return ret;
    }
    #endregion

    #region Count Method
    public int Count()
    {
      int ret = 0;

      // Initialize all properties
      Init();

      // Create SQL to count records
      SQL = "SELECT COUNT(*) FROM SalesLT.Product";

      // Execute Query
      ret = ExecuteScalar<int>("Exception in ProductManager.Count()");

      return ret;
    }
    #endregion

    #region Insert Method
    public int Insert(Product entity)
    {
      // Initialize all properties
      Init();

      // Attempt to validate the data, a ValidationException is thrown if validation rules fail
      Validate<Product>(entity);

      // Create SQL to INSERT INTO SalesLT.Product using dynamic SQL
      SQL = "INSERT INTO SalesLT.Product(Name, ProductNumber, Color, StandardCost, ListPrice, Size, Weight, ProductCategoryID, ProductModelID, SellStartDate, SellEndDate, DiscontinuedDate, ModifiedDate) VALUES(@Name, @ProductNumber, @Color, @StandardCost, @ListPrice, @Size, @Weight, @ProductCategoryID, @ProductModelID, @SellStartDate, @SellEndDate, @DiscontinuedDate, @ModifiedDate); ";
      SQL += "SELECT @ProductID = SCOPE_IDENTITY();";

      // Create standard insert parameters
      BuildInsertUpdateParameters(entity);

      // Create parameter to get IDENTITY value generated
      AddParameter("@ProductID", -1, true, System.Data.DbType.Int32, System.Data.ParameterDirection.Output);

      // Execute Query
      RowsAffected = ExecuteSqlCommand("Exception in ProductManager.Insert()", true, "@ProductID");

      // Get the ProductID generated from the IDENTITY 
      entity.ProductID = (int)IdentityGenerated;

      return RowsAffected;
    }
    #endregion

    #region Update Method
    public int Update(Product entity)
    {
      // Initialize all properties
      Init();

      // Attempt to validate the data, a ValidationException is thrown if validation rules fail
      Validate<Product>(entity);

      // Create SQL to UPDATE SalesLT.Product using dynamic SQL
      SQL = "UPDATE SalesLT.Product SET Name=@Name, ProductNumber=@ProductNumber, Color=@Color, StandardCost=@StandardCost, ListPrice=@ListPrice, Size=@Size, Weight=@Weight, ProductCategoryID=@ProductCategoryID, ProductModelID=@ProductModelID, SellStartDate=@SellStartDate, SellEndDate=@SellEndDate, DiscontinuedDate=@DiscontinuedDate, ModifiedDate=@ModifiedDate WHERE ProductID = @ProductID";

      // Create standard update parameters
      BuildInsertUpdateParameters(entity);

      // Add primary parameter to CommandObject
      AddParameter("@ProductId", (object)entity.ProductID, false);

      // Execute Query
      RowsAffected = ExecuteSqlCommand("Exception in ProductManager.Update()");

      return RowsAffected;
    }
    #endregion

    #region Delete Method
    public int Delete(Product entity)
    {
      // Initialize all properties
      Init();

      // Create SQL to DELETE FROM SalesLT.Product using dynamic SQL
      SQL = "DELETE FROM SalesLT.Product WHERE ProductID = @ProductID";

      // Create parameters
      AddParameter("@ProductId", (object)entity.ProductID, false);

      // Execute Query
      RowsAffected = ExecuteSqlCommand("Exception in ProductManager.Delete()");

      return RowsAffected;
    }
    #endregion

    #region BuildInsertUpdateParameters Method
    protected virtual void BuildInsertUpdateParameters(Product entity)
    {
      // Add parameters to CommandObject
      AddParameter("Name", (object)entity.Name, false);
      AddParameter("ProductNumber", (object)entity.ProductNumber, false);
      AddParameter("Color", (object)entity.Color, false);
      AddParameter("StandardCost", (object)entity.StandardCost, false);
      AddParameter("ListPrice", (object)entity.ListPrice, false);
      AddParameter("Size", (object)entity.Size ?? DBNull.Value, true);
      AddParameter("Weight", (object)entity.Weight ?? DBNull.Value, true);
      AddParameter("ProductCategoryID", (object)entity.ProductCategoryID, false);
      AddParameter("ProductModelID", (object)entity.ProductModelID, false);
      AddParameter("SellStartDate", (object)entity.SellStartDate, false);
      AddParameter("SellEndDate", (object)entity.SellEndDate ?? DBNull.Value, true);
      AddParameter("DiscontinuedDate", (object)entity.DiscontinuedDate ?? DBNull.Value, true);
      AddParameter("ModifiedDate", (object)entity.ModifiedDate, false);
    }
    #endregion

    #region Validate Method
    public override bool Validate<T>(T entityToValidate)
    {
      // Check all Data Annotations first
      bool ret = base.Validate(entityToValidate);

      // Cast to a Product class
      Product entity = entityToValidate as Product;

      // Add other business rules here
      if (entity.Name.Length < 2) {
        AddValidationMessage("Name", "Name must be greater than 2 characters in length.");
      }

      if (ValidationMessages.Count > 0) {
        throw new EFValidationException(ValidationMessages);
      }

      return ret;
    }
    #endregion
  }
}
