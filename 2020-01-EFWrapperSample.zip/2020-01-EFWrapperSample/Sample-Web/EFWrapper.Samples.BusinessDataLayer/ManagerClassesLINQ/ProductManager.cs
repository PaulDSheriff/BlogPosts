﻿using System;
using System.Collections.Generic;
using System.Linq;
using EFWrapper.Samples.AppLayer;
using EFWrapper.Samples.BusinessDataLayer.EntityClasses;

namespace EFWrapper.Samples.BusinessDataLayer.LINQ
{
  /// <summary>
  /// The methods in this class show how to use LINQ
  /// </summary>
  public partial class ProductManager : AppDataManager
  {
    #region Get Method
    public Product Get(int productId)
    {
      Product ret = new Product();

      // Initialize all properties
      Init();

      // Create instance of DbContext
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          // Execute the dynamic SQL
          ret = db.Products.Where(p => p.ProductID == productId).SingleOrDefault();
        }
        catch (Exception ex) {
          // Throw a custom exception
          ThrowDbException(ex, db, "Exception in ProductManager.Get()");
        }
      }

      return ret;
    }
    #endregion

    #region GetAll Method
    public List<Product> GetAll()
    {
      List<Product> ret = new List<Product>();

      // Initialize all properties
      Init();

      // Create instance of DbContext
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          // Execute the dynamic SQL
          ret = db.Products.ToList();
        }
        catch (Exception ex) {
          // Throw a custom exception
          ThrowDbException(ex, db, "Exception in ProductManager.GetAll()");
        }
      }

      return ret;
    }
    #endregion

    #region Search Method
    public List<Product> Search(ProductSearch search)
    {
      List<Product> ret = new List<Product>();

      // Initialize all properties
      Init();

      // Create instance of DbContext
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          // Get query object from Products DbSet property
          IQueryable<Product> query = db.Products;

          // Create appropriate WHERE clauses         
          if (!string.IsNullOrEmpty(search.Name)) {
            query = query.Where(p => p.Name.StartsWith(search.Name));
          }
          if (!string.IsNullOrEmpty(search.ProductNumber)) {
            query = query.Where(p => p.ProductNumber.StartsWith(search.ProductNumber));
          }
          if (search.BeginningCost.HasValue) {
            query = query.Where(p => p.StandardCost >= search.BeginningCost.Value);
          }
          if (search.EndingCost.HasValue) {
            query = query.Where(p => p.StandardCost <= search.EndingCost.Value);
          }

          // Execute the dynamic SQL
          ret = query.ToList();
        }
        catch (Exception ex) {
          // Throw a custom exception
          ThrowDbException(ex, db, "Exception in ProductManager.Search()");
        }
      }

      return ret;
    }
    #endregion
  }
}
