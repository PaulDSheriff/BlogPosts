﻿using Common.EF.Library;

namespace EFWrapper.Samples.AppLayer
{
  /// <summary>
  /// This class is the base class for all view models for this specific application
  /// </summary>
  public class AppViewModelBase : EFViewModelBase
  {
    public string EventAction { get; set; }
    public string EventValue { get; set; }

  }
}
