﻿using Common.EF.Library;
using EFWrapper.Samples.BusinessDataLayer;
using System.Collections.Generic;

namespace EFWrapper.Samples.AppLayer
{
  public class AppDataManager : EFDataManagerBase
  {
    #region ExecuteSqlCommand Method
    protected int ExecuteSqlCommand(string exceptionMsg, bool getIdentity = false, string identityParamName = "")
    {
      // Create instance of DbContext
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext())
      {
        // Execute the action query
        RowsAffected = base.ExecuteSqlCommand(db, exceptionMsg);
        // Get Identity from parameter
        if (getIdentity && !string.IsNullOrEmpty(identityParamName))
        {
          IdentityGenerated = GetParameter(identityParamName).Value;
        }
      }

      return RowsAffected;
    }
    #endregion

    #region ExecuteSqlQuery Method
    protected List<T> ExecuteSqlQuery<T>(string exceptionMsg = "")
    {
      List<T> ret = new List<T>();

      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext())
      {
        ret = base.ExecuteSqlQuery<T>(db, exceptionMsg);
      }

      return ret;
    }
    #endregion

    #region ExecuteScalar Method
    protected T ExecuteScalar<T>(string exceptionMsg = "")
    {
      T ret = default;

      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext())
      {
        ret = base.ExecuteScalar<T>(db, exceptionMsg);
      }

      return ret;
    }
    #endregion
  }
}
