﻿using System.Collections.Generic;

namespace EFWrapper.Samples.BusinessDataLayer.EntityClasses
{
  public class MultipleResults
  {
    public List<Product> Products { get; set; }
    public List<SalesOrderDetail> SalesOrderDetails { get; set; }
  }
}
