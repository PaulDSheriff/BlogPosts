﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EFWrapper.Samples.BusinessDataLayer.EntityClasses
{
  [Table("SalesOrderDetail", Schema = "SalesLT")]
  public class SalesOrderDetail
  {
    [Key]
    public int SalesOrderID { get; set; }
    public int SalesOrderDetailID { get; set; }
    public short OrderQty { get; set; }
    public int ProductID { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal UnitPriceDiscount { get; set; }
    public decimal LineTotal { get; set; }

    // For product info
    public string Name { get; set; }
    public string ProductNumber { get; set; }
    public string Size { get; set; }
    public decimal? Weight { get; set; }
  }
}
