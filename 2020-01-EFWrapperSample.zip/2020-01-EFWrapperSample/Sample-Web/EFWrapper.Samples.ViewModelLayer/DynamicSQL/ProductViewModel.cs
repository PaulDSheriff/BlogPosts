﻿using Common.EF.Library;
using EFWrapper.Samples.AppLayer;
using EFWrapper.Samples.BusinessDataLayer.DynamicSQL;
using EFWrapper.Samples.BusinessDataLayer.EntityClasses;
using System;
using System.Collections.Generic;

namespace EFWrapper.Samples.ViewModelLayer.DynamicSQL
{
  public class ProductViewModel : AppViewModelBase
  {
    #region Constructor
    public ProductViewModel() : base()
    {
      Entity = new Product();
      SearchEntity = new ProductSearch();
      Products = new List<Product>();
    }
    #endregion

    #region Properties
    public Product Entity { get; set; }
    public ProductSearch SearchEntity { get; set; }
    public List<Product> Products { get; set; }
    #endregion

    #region HandleRequest Method
    public void HandleRequest()
    {
      switch (EventAction.ToLower()) {
        case "add":
          break;

        case "edit":
          break;

        case "delete":
          Entity.ProductID = Convert.ToInt32(EventValue);
          Delete();
          GetAll();
          break;

        case "search":
          Search();
          break;

        case "resetsearch":
          ResetSearch();
          GetAll();
          break;

        case "count":
          Count();
          break;

        case "save":
          Entity.ModifiedDate = DateTime.Now;
          if (EventValue == "Insert") {
            Entity.ProductCategoryID = 18;
            Entity.ProductModelID = 6;
            Insert();
          }
          else {
            Update();
          }         
          break;

        case "cancel":
          break;
      }
    }
    #endregion

    #region Clear Method Override
    public override void Clear()
    {
      Products = new List<Product>();
      Entity = new Product();

      base.Clear();
    }
    #endregion

    #region GetAll Method
    public void GetAll()
    {
      ProductManager mgr = new ProductManager();

      try {
        Products = mgr.GetAll();

        RowsAffected = Products.Count;
      }
      catch (Exception ex) {
        PublishException(ex);
      }
    }
    #endregion

    #region Get Method
    public Product Get(int productId)
    {
      ProductManager mgr = new ProductManager();

      Products = new List<Product>();
      try {
        Entity = mgr.Get(productId);

        if (Entity != null) {
          RowsAffected = 1;
        }
      }
      catch (Exception ex) {
        PublishException(ex);
      }

      return Entity;
    }
    #endregion

    #region Search Method
    public void Search()
    {
      ProductManager mgr = new ProductManager();

      try {
        Products = mgr.Search(SearchEntity);

        RowsAffected = Products.Count;
      }
      catch (Exception ex) {
        PublishException(ex);
      }
    }
    #endregion

    #region ResetSearch Method
    public void ResetSearch()
    {
      SearchEntity = new ProductSearch();
      RowsAffected = 0;
    }
    #endregion

    #region Count Method
    public int Count()
    {
      ProductManager mgr = new ProductManager();

      try {
        RowsAffected = mgr.Count(SearchEntity);
      }
      catch (Exception ex) {
        PublishException(ex);
      }

      return RowsAffected;
    }
    #endregion

    #region CreateEntityForAdd Method
    public void CreateEntityForAdd()
    {
      // TODO: Remove these initializations
      Entity = new Product {
        Name = "A New Product",
        ProductNumber = "AAA-111",
        Color = "Red",
        SellStartDate = DateTime.Now,
        StandardCost = 5,
        ListPrice = 10
      };
    }
    #endregion

    #region Insert Method
    public void Insert()
    {
      ProductManager mgr = new ProductManager();

      try {
        RowsAffected = mgr.Insert(Entity);
      }
      catch (EFValidationException ex) {
        ValidationFailed(ex);
      }
      catch (Exception ex) {
        PublishException(ex);
      }
    }
    #endregion

    #region Update Method
    public void Update()
    {
      ProductManager mgr = new ProductManager();

      try {
        RowsAffected = mgr.Update(Entity);
      }
      catch (EFValidationException ex) {
        ValidationFailed(ex);
      }
      catch (Exception ex) {
        PublishException(ex);
      }
    }
    #endregion

    #region Delete Method
    public void Delete()
    {
      ProductManager mgr = new ProductManager();

      try {
        RowsAffected = mgr.Delete(Entity);
      }
      catch (Exception ex) {
        PublishException(ex);
      }
    }
    #endregion
  }
}
