﻿using EFWrapper.Samples.AppLayer;
using EFWrapper.Samples.BusinessDataLayer;
using EFWrapper.Samples.BusinessDataLayer.EntityClasses;
using System;
using System.Collections.Generic;

namespace EFWrapper.Samples.ViewModelLayer
{
  public class MiscViewModel : AppViewModelBase
  {
    #region Constructor
    public MiscViewModel() : base()
    {
      SalesOrderDetails = new List<SalesOrderDetail>();
      Products = new List<Product>();
    }
    #endregion

    #region Public Properties
    public string Message { get; set; }
    public List<SalesOrderDetail> SalesOrderDetails { get; set; }
    public List<Product> Products { get; set; }
    #endregion

    #region HandleRequest Method
    public void HandleRequest()
    {
      switch (EventAction.ToLower())
      {
        case "multiple":
          MultipleResultSets();
          break;

        case "transaction":
          ProcessTransaction();
          break;
      }
    }
    #endregion

    #region MultipleResultSets Method
    public void MultipleResultSets()
    {
      MiscManager mgr = new MiscManager();
      MultipleResults results;

      try
      {
        results = mgr.MultipleResultSets();

        Products = results.Products;
        SalesOrderDetails = results.SalesOrderDetails;
      }
      catch (Exception ex)
      {
        PublishException(ex);
      }
    }
    #endregion

    #region ProcessTransaction Method
    public void ProcessTransaction()
    {
      MiscManager mgr = new MiscManager();

      try
      {
        mgr.PerformTransaction();
        Message = mgr.Message;
      }
      catch (Exception ex)
      {
        PublishException(ex);
      }
    }
    #endregion
  }
}
