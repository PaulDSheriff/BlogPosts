﻿using EFWrapper.Samples.AppLayer;
using EFWrapper.Samples.BusinessDataLayer;
using EFWrapper.Samples.BusinessDataLayer.EntityClasses;
using System;
using System.Collections.Generic;

namespace EFWrapper.Samples.ViewModelLayer
{
  public class SalesOrderDetailViewModel : AppViewModelBase
  {
    #region Constructor
    public SalesOrderDetailViewModel() : base()
    {
      SalesOrderDetails = new List<SalesOrderDetail>();
    }
    #endregion

    #region Public Properties
    public int? SalesOrderID { get; set; }
    public List<SalesOrderDetail> SalesOrderDetails { get; set; }
    #endregion

    #region HandleRequest Method
    public void HandleRequest()
    {
      switch (EventAction.ToLower())
      {
        case "getall":
          GetAll();
          break;

        case "getbysalesorderid":
          if (SalesOrderID.HasValue)
          {
            GetBySalesOrderID(SalesOrderID.Value);
          }
          break;
      }
    }
    #endregion

    #region GetAll Method
    public void GetAll()
    {
      SalesOrderDetailManager mgr = new SalesOrderDetailManager();

      try
      {
        SalesOrderDetails = mgr.GetAll();

        RowsAffected = SalesOrderDetails.Count;
      }
      catch (Exception ex)
      {
        PublishException(ex);
      }
    }
    #endregion

    #region GetBySalesOrderID Method
    public List<SalesOrderDetail> GetBySalesOrderID(int salesOrderID)
    {
      SalesOrderDetailManager mgr = new SalesOrderDetailManager();

      try
      {
        SalesOrderDetails = mgr.GetBySalesOrderID(salesOrderID);

        RowsAffected = SalesOrderDetails.Count;
      }
      catch (Exception ex)
      {
        PublishException(ex);
      }

      return SalesOrderDetails;
    }
    #endregion
  }
}
