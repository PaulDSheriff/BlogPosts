﻿using System.Web.Mvc;
using EFWrapper.Samples.ViewModelLayer;

namespace EFWrapper.Samples.Controllers
{
  public class ProductController : Controller
  {
    public ActionResult ProductList()
    {
      ProductViewModel vm = new ProductViewModel();

      vm.GetAll();

      return View(vm);
    }

    [HttpPost]
    public ActionResult ProductList(ProductViewModel vm)
    {
      ActionResult ret = View(vm);

      // Handle the request
      vm.HandleRequest();

      // Handle any MVC actions to take
      switch (vm.EventAction.ToLower()) {
        case "add":
          ret = RedirectToAction("ProductDetail", new { id = -1 });
          break;

        case "edit":
          ret = RedirectToAction("ProductDetail", new { id = vm.EventValue });
          break;

        case "resetsearch":
          ModelState.Clear();
          break;
      }

      return ret;
    }

    public ActionResult ProductDetail(int id)
    {
      ProductViewModel vm = new ProductViewModel();

      if (id >= 0) {
        vm.EventValue = "Update";
        vm.Get(id);
      }
      else {
        vm.EventValue = "Insert";
        vm.CreateEntityForAdd();
      }

      return View(vm);
    }

    [HttpPost]
    public ActionResult ProductDetail(ProductViewModel vm)
    {
      ActionResult ret = View(vm);

      // Handle the request
      vm.HandleRequest();

      // Handle any MVC actions to take
      switch (vm.EventAction.ToLower()) {
        case "save":
          if (vm.RowsAffected >= 1) {
            ret = RedirectToAction("ProductList");
          }
          break;

        case "cancel":
          ret = RedirectToAction("ProductList");
          break;
      }

      return ret;
    }
  }
}