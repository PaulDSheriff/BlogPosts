﻿using System.Web.Mvc;

namespace EFWrapper.Samples.Controllers
{
  public class HomeController : Controller
  {
    public ActionResult Index()
    {
      return View();
    }
  }
}