﻿using System.Web.Mvc;
using EFWrapper.Samples.ViewModelLayer;

namespace EFWrapper.Samples.Controllers
{
  public class SalesOrderDetailController : Controller
  {
    public ActionResult SalesOrderDetailList()
    {
      SalesOrderDetailViewModel vm = new SalesOrderDetailViewModel();

      vm.GetAll();

      return View(vm);
    }

    [HttpPost]
    public ActionResult SalesOrderDetailList(SalesOrderDetailViewModel vm)
    {
      ActionResult ret = View(vm);

      // Handle the request
      vm.HandleRequest();

      return ret;
    }
  }
}