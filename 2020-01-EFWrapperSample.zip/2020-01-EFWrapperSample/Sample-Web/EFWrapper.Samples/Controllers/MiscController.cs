﻿using System.Web.Mvc;
using EFWrapper.Samples.ViewModelLayer;

namespace EFWrapper.Samples.Controllers
{
  public class MiscController : Controller
  {
    public ActionResult Misc()
    {
      MiscViewModel vm = new MiscViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Misc(MiscViewModel vm)
    {
      ActionResult ret = View(vm);

      // Handle the request
      vm.HandleRequest();

      return ret;
    }
  }
}