﻿namespace Common.EF.Library
{
  public class EFValidationMessage
  {
    public string PropertyName { get; set; }
    public string Message { get; set; }
  }
}
