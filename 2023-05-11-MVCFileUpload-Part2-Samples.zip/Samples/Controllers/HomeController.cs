﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using UploadVMSample.Models;
using UploadVMSample.ViewModelClasses;

namespace UploadVMSample.Controllers
{
  public class HomeController : Controller
  {
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
      _logger = logger;
    }

    public IActionResult Index()
    {
      return View();
    }

    public IActionResult Sample1()
    {
      Sample1ViewModel vm = new();

      return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> Sample1(Sample1ViewModel vm)
    {
      bool ret = await vm.Save();

      if (ret) {
        return View("Sample1Complete", vm);
      }
      else {
        return View(vm);
      }
    }

    public IActionResult Sample2()
    {
      FileSystemViewModel vm = new();

      return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> Sample2(FileSystemViewModel vm)
    {
      if (ModelState.IsValid) {
        if (await vm.Save()) {
          return View("FileUploadComplete", vm);
        }
      }

      return View(vm);
    }

    public IActionResult Privacy()
    {
      return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
      return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
  }
}