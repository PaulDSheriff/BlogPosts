﻿namespace UploadVMSample.ViewModelClasses;

public class FileSystemViewModel : FileUploadViewModelBase
{
  /// <summary>
  /// Save to Server File System 
  /// </summary>
  /// <returns>A Task with true=successful, false=unsuccessful</returns>
  protected override async Task<bool> SaveToDataStoreAsync()
  {
    bool ret = false;

    if (FileToUpload != null) {
      // Get a temporary path
      FileInfo.ServerLocation = Path.GetTempPath();
      // Set Server Location to Store File
      FileInfo.ServerLocation = Path.GetTempPath();

      // Create a stream to write the file to
      using var stream = File.Create(FileInfo.ServerLocation + FileInfo.FileName);
      // Upload file and copy to the stream
      await FileToUpload.CopyToAsync(stream);

      ret = true;
    }

    return ret;
  }
}
