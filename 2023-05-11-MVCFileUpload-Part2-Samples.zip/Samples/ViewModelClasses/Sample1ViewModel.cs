﻿using System.ComponentModel.DataAnnotations;
using UploadVMSample.EntityClasses;

namespace UploadVMSample.ViewModelClasses;

public class Sample1ViewModel
{
  public FileInformation FileInfo { get; set; } = new();
  [Display(Name = "Select File to Upload")]
  public IFormFile? FileToUpload { get; set; }

  public async Task<bool> Save()
  {
    bool ret = false;

    // Ensure user selected a file for upload
    if (FileToUpload != null && FileToUpload.Length > 0) {
      // Get all File Properties
      GetFileProperties();

      // Save File to Data Store
      ret = await SaveToDataStore();
    }
   
    return ret;
  }

  protected void GetFileProperties()
  {
    if (FileToUpload != null) {
      // Get the file name
      FileInfo.FileName = FileToUpload.FileName;
      // Get the file's length
      FileInfo.Length = FileToUpload.Length;
      // Get the file's type
      FileInfo.Type = FileToUpload.ContentType;
    }
  }

  // Override to save to a data store
  protected async Task<bool> SaveToDataStore()
  {
    bool ret = false;

    if (FileToUpload != null) {
      // Get a temporary path
      FileInfo.ServerLocation = Path.GetTempPath();
      // Add the file name to the path
      FileInfo.ServerLocation += FileInfo.FileName;

      // Create a stream to write the file to
      using var stream = System.IO.File.Create(FileInfo.ServerLocation);
      // Upload file and copy to the stream
      await FileToUpload.CopyToAsync(stream);

      ret = true;
    }

    return ret;
  }
}