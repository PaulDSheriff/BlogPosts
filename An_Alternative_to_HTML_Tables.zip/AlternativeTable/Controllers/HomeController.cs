﻿using System.Web.Mvc;

namespace AlternativeTable.Controllers
{
  public class HomeController : Controller
  {
    public ActionResult Index() {
      return View();
    }

    public ActionResult TableSample() {
      TrainingProductViewModel vm = new TrainingProductViewModel();

      vm.LoadProducts();

      return View(vm);
    }

    public ActionResult AlternateTableSample() {
      TrainingProductViewModel vm = new TrainingProductViewModel();

      vm.LoadProducts();

      return View(vm);
    }
  }
}