﻿using System.Collections.Generic;

namespace AlternativeTable
{
  public class TrainingProductViewModel
  {
    public List<TrainingProduct> Products { get; set; } = new List<TrainingProduct>();

    public void LoadProducts() {
      TrainingProductManager mgr = new TrainingProductManager();

      Products = mgr.LoadProducts();
    }
  }
}
