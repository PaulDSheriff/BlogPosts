﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Linq

Public Class ProductManager
#Region "GetProducts Method"
  ''' <summary>
  ''' This method uses DataRow.Field&lt;T&gt;() method to retrieve data.
  ''' The Field method works will nullable types.
  ''' </summary>
  ''' <returns>A List of Product objects</returns>
  Public Function GetProducts() As List(Of Product)
    Dim dt As New DataTable()
    Dim da As SqlDataAdapter = Nothing

    da = New SqlDataAdapter("SELECT * FROM Product", AppSettings.Instance.ConnectString)

    da.Fill(dt)

    Dim query = (From dr In dt.AsEnumerable() _
                 Select New Product() With { _
      .ProductId = Convert.ToInt32(dr("ProductId")), _
      .ProductName = dr("ProductName").ToString(), _
      .IntroductionDate = DataConvert.ConvertTo(Of DateTime)(dr("IntroductionDate"), DateTime.MinValue), _
      .Cost = DataConvert.ConvertTo(Of Decimal)(dr("Cost"), 0D), _
      .Price = DataConvert.ConvertTo(Of Decimal)(dr("Price"), 0D), _
      .IsDiscontinued = DataConvert.ConvertTo(Of Boolean)(dr("IsDiscontinued"), False) _
    })

    Return query.ToList()
  End Function

#End Region
End Class
