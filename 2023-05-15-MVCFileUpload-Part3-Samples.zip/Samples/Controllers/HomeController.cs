﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using UploadVMSample.EntityClasses;
using UploadVMSample.Models;
using UploadVMSample.ViewModelClasses;

namespace UploadVMSample.Controllers
{
  public class HomeController : Controller
  {
    private readonly ILogger<HomeController> _logger;
    private readonly FileUploadSettings _settings;

    public HomeController(ILogger<HomeController> logger, FileUploadSettings settings)
    {
      _logger = logger;
      _settings = settings;
    }

    public IActionResult Index()
    {
      return View();
    }

    public IActionResult UploadAFile()
    {
      FileSystemViewModel vm = new()
      {
        // Set the upload settings
        UploadSettings = _settings
      };

      return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> UploadAFile(FileSystemViewModel vm)
    {  
      // Set the upload settings
      vm.UploadSettings = _settings;

      if (ModelState.IsValid) {
        if (await vm.Save()) {
          return View("FileUploadComplete", vm);
        }
      }

      return View(vm);
    }

    public IActionResult Sample1()
    {
      Sample1ViewModel vm = new();

      return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> Sample1(Sample1ViewModel vm)
    {
      bool ret = await vm.Save();

      if (ret) {
        return View("Sample1Complete", vm);
      }
      else {
        return View(vm);
      }
    }

    public IActionResult Sample2()
    {
      FileSystemViewModel vm = new();

      return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> Sample2(FileSystemViewModel vm)
    {
      if (ModelState.IsValid) {
        if (await vm.Save()) {
          return View("FileUploadComplete", vm);
        }
      }

      return View(vm);
    }

    public IActionResult Privacy()
    {
      return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
      return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
  }
}