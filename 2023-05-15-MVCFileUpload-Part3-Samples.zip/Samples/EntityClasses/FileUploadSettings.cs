﻿namespace UploadVMSample.EntityClasses;

public class FileUploadSettings
{
  public FileUploadSettings()
  {
    AcceptTypes = "image/*,.pdf,.txt,.doc,.docx,.xls,.xlsx,.ppt,.pptx";
    ValidFileTypes = "application/vnd.openxmlformats-officedocument,image/,application/pdf,text/plain";
    InvalidFileExtensions = ".cs,.js,.vb";
  }

  public string AcceptTypes { get; set; }
  public string ValidFileTypes { get; set; }
  public string InvalidFileExtensions { get; set; }
}
