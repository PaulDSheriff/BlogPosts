﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace PTC.Controllers
{
  public class HomeController : Controller
  {
    public ActionResult Index()
    {
      return View();
    }    
  }
}