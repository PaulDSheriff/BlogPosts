﻿import { Component, OnInit } from "@angular/core";
import { Router } from '@angular/router';

import { Product } from "./product";
import { ProductService } from "./product.service";

@Component({
  moduleId: module.id,
  templateUrl: "./product-list.component.html"
})
export class ProductListComponent implements OnInit {
  constructor(private productService: ProductService,
    private router: Router) {
  }

  ngOnInit() {
    this.getProducts();
  }

  // Public properties
  products: Product[] = [];
  messages: string[] = [];

  private getProducts() {
    this.productService.getProducts()
      .subscribe(products => this.products = products,
        errors => this.handleErrors(errors));
  }

  selectProduct(id: number) {
    this.router.navigate(['/productDetail', id]);
  }

  deleteProduct(id: number) {
    if (confirm("Delete this product?")) {
      this.productService.deleteProduct(id)
        .subscribe(() => this.getProducts(),
        errors => this.handleErrors(errors));
    }
  }

  add() {
    this.router.navigate(['/productDetail', -1]);
  }

  private handleErrors(errors: any) {
    for (let msg of errors) {
      this.messages.push(msg);
    }
  }
}