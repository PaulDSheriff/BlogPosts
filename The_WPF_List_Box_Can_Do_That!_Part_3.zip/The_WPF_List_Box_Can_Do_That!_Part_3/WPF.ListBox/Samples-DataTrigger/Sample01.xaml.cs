﻿using System.Windows.Controls;

namespace WPF.ListBox.DataTrigger
{
  public partial class Sample01 : UserControl
  {
    public Sample01()
    {
      InitializeComponent();
    }
  }
}
