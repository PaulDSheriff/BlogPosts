﻿using System.Windows.Controls;

namespace WPF.ListBox.DataTrigger
{
  public partial class Sample02 : UserControl
  {
    public Sample02()
    {
      InitializeComponent();
    }
  }
}
