﻿This sample shows how to change templates and use data triggers in a WPF ListBox.


\Samples-ChangeTemplate
-------------------------------------------------------
Sample01 - Horizontal ListBox
Sample02 - Change templates at runtime
Sample03 - Data trigger using multi-binding


\Samples-DataTrigger
-------------------------------------------------------
Sample01 - Simple data trigger
Sample02 - Two data triggers
