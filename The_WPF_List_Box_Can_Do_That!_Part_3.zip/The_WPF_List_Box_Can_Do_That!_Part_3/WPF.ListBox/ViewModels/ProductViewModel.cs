﻿using Common.Library;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using WPF.ListBox.EntityClasses;
using WPF.ListBox.Models;

namespace WPF.ListBox.ViewModelLayer
{
  public class ProductViewModel : CommonBase
  {
    #region Constructor
    public ProductViewModel()
    {
      Products = new ObservableCollection<Product>();
      SearchEntity = new ProductSearch();
      FilteredProducts = new ObservableCollection<Product>();
      LoadProducts();
    }
    #endregion

    #region Private Variables
    private ProductSearch _SearchEntity;
    private ObservableCollection<Product> _Products;
    private ObservableCollection<Product> _FilteredProducts;
    private int _TotalFilteredRecords;
    #endregion

    #region Public Properties
    public ProductSearch SearchEntity
    {
      get { return _SearchEntity; }
      set {
        _SearchEntity = value;
        RaisePropertyChanged("ProductSearch");
      }
    }

    public ObservableCollection<Product> Products
    {
      get { return _Products; }
      set {
        _Products = value;
        RaisePropertyChanged("Products");
      }
    }

    public ObservableCollection<Product> FilteredProducts
    {
      get { return _FilteredProducts; }
      set {
        _FilteredProducts = value;
        RaisePropertyChanged("FilteredProducts");
      }
    }

    public int TotalFilteredRecords
    {
      get { return _TotalFilteredRecords; }
      set {
        _TotalFilteredRecords = value;
        RaisePropertyChanged("TotalFilteredRecords");
      }
    }
    #endregion

    #region LoadProducts Method
    public virtual ObservableCollection<Product> LoadProducts()
    {
      SearchEntity.Clear();

      try {
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = new ObservableCollection<Product>(db.Products);
          FilteredProducts = new ObservableCollection<Product>(Products);
          TotalFilteredRecords = FilteredProducts.Count;
        }
      }
      catch (Exception ex) {
        System.Diagnostics.Debug.WriteLine(ex.ToString());
      }

      return Products;
    }
    #endregion

    #region SearchProducts Method
    public virtual ObservableCollection<Product> SearchProducts()
    {
      FilteredProducts.Clear();

      // Filter the products already loaded into memory
      FilteredProducts = new ObservableCollection<Product>(
          Products.Where(p => StartsWith(SearchEntity.Name, p.Name)
                           && StartsWith(SearchEntity.Color, p.Color)
                           && StartsWith(SearchEntity.Size, p.Size)));

      TotalFilteredRecords = FilteredProducts.Count;

      return FilteredProducts;
    }
    #endregion

    #region StartsWith Method
    private bool StartsWith(string searchValue, string dataValue)
    {
      if (string.IsNullOrEmpty(searchValue)) {
        return true;
      }
      else if (string.IsNullOrEmpty(dataValue)) {
        return false;
      }
      else {
        return dataValue.StartsWith(searchValue, StringComparison.InvariantCultureIgnoreCase);
      }
    }
    #endregion
  }
}