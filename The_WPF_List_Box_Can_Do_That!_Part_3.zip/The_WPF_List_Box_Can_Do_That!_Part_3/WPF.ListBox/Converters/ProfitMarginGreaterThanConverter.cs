﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace WPF.ListBox
{
  public class ProfitMarginGreaterThanConverter : IMultiValueConverter
  {
    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
    {
      decimal ret = 0;
      decimal cost = 0;
      decimal price = 0;
      decimal margin = 50;

      if (values.Count() > 1) {
        // First parameter is cost
        cost = System.Convert.ToDecimal(values[0]);
        // Second parameter is price
        price = System.Convert.ToDecimal(values[1]);
        if (parameter != null) {
          // parameter is value to be greater than
          margin = System.Convert.ToDecimal(parameter);
        }
        // Calculate the profit margin
        ret = Math.Round(((price - cost) / cost), 1);
      }

      return (ret * 100) > margin;
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }
}
