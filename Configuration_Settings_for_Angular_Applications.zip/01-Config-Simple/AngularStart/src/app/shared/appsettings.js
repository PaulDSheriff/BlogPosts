"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AppSettings = (function () {
    function AppSettings() {
        this.defaultUrl = "http://www.fairwaytech.com";
        this.defaultPrice = 1;
    }
    return AppSettings;
}());
exports.AppSettings = AppSettings;
//# sourceMappingURL=appsettings.js.map