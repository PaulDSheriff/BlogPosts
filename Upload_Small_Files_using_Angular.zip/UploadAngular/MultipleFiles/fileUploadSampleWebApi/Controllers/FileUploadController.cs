﻿using System;
using System.IO;
using Microsoft.AspNetCore.Mvc;

namespace fileUploadSampleWebApi.Controllers
{
  [Route("api/[controller]")]
  public class FileUploadController : Controller
  {
    const string FILE_PATH = @"D:\Samples\";

    [HttpPost]
    public IActionResult Post([FromBody]FileToUpload theFile)
    {
      // Create unique file name
      var filePath = FILE_PATH + DateTime.Now.ToString().Replace("/", "")
          .Replace(":", "").Replace(" ", "") + "-" + theFile.FileName;

      // Remove file type from base64 encoding, if any
      if (theFile.FileAsBase64.Contains(","))
      {
        theFile.FileAsBase64 = theFile.FileAsBase64
          .Substring(theFile.FileAsBase64.IndexOf(",") + 1);
      }

      // Convert base64 encoded string to binary
      theFile.FileAsByteArray = Convert.FromBase64String(theFile.FileAsBase64);

      // Write binary file to server path
      using (var fs = new FileStream(filePath, FileMode.CreateNew))
      {
        fs.Write(theFile.FileAsByteArray, 0, theFile.FileAsByteArray.Length);
        fs.Close();
        fs.Dispose();
      }

      return Ok();
    }
  }
}
