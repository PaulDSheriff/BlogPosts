﻿using System.Web.Mvc;

namespace LinqToXmlSample.Controllers
{
  public class USStateController : Controller
  {
    public ActionResult Index() {
      USStateManager mgr = new USStateManager();
      string fileName = Server.MapPath("/Xml") + @"\USStates.xml";

      return View(mgr.GetStateCodes(fileName));
    }
  }
}