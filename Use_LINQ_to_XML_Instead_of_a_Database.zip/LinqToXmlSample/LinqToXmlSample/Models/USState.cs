﻿
namespace LinqToXmlSample
{
public class USState
{
  public string StateCode { get; set; }
  public string StateName { get; set; }
  public string Capital { get; set; }
}
}
