﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace LinqToXmlSample
{
  public class USStateManager
  {
    public List<USState> GetStateCodes(string fileName) {
      XElement xelem = null;

      xelem = XElement.Load(fileName);
      // Fill a list of USState objects
      var coll = from elem in xelem.Descendants("USState")
                 select new USState
                 {
                   StateCode = GetValue<string>(elem.Element("StateCode"), ""),
                   StateName = GetValue<string>(elem.Element("StateName"), ""),
                   Capital = GetValue<string>(elem.Element("Capital"), "")
                 };

      return coll.ToList();
    }

    private T GetValue<T>(XElement elem, T defaultValue) {
      if (elem == null || string.IsNullOrEmpty(elem.Value)) {
        return defaultValue;
      }
      else {
        return (T)Convert.ChangeType(elem.Value, typeof(T)); ;
      }
    }
  }
}
