﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Linq;

namespace BootstrapCheckBoxes2.Controllers
{
  public class CheckBoxSamplesController : Controller
  {
    public ActionResult Check06()
    {
      MusicalTastes entity = new MusicalTastes();

      entity.IsCountry = true;

      return View(entity);
    }

    [HttpPost]
    public ActionResult Check06(MusicalTastes entity)
    {
      System.Diagnostics.Debugger.Break();

      return View(entity);
    }
  }
}