﻿
namespace BootstrapCheckBoxes2
{
  public class MusicalTastes
  {
    public bool IsJazz { get; set; }
    public bool IsCountry { get; set; }
    public bool IsRock { get; set; }
  }
}
