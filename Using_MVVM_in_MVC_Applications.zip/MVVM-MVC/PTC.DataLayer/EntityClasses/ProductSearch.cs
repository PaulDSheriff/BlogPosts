﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTC.DataLayer.EntityClasses
{
  public class ProductSearch
  {
    /// <summary>
    /// Constructor for ProductSearch class
    /// </summary>
    public ProductSearch() : base() {
      Init();
    }

    public void Init() {
      // Initialize all search variables
      ProductName = string.Empty;
    }

    /// <summary>
    /// Get/Set the product name to search on
    /// </summary>
    public string ProductName { get; set; }
  }
}
