﻿PTC Sample
----------------------------------
You will need to create the table contained in the \SqlScripts\Product.sql file.

You will need to modify the connection string in the Web.config file to your database where you install the product table.