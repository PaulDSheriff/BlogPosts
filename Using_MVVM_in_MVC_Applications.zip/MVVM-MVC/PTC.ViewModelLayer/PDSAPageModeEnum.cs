﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTC.ViewModelLayer
{
  /// <summary>
  /// Enumeration for the current page mode
  /// </summary>
  public enum PDSAPageModeEnum
  {
    /// <summary>
    /// List mode
    /// </summary>
    List,
    /// <summary>
    /// Add Mode
    /// </summary>
    Add,
    /// <summary>
    /// Edit Mode
    /// </summary>
    Edit
  }
}
