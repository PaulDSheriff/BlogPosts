﻿using System;
using System.Collections.Generic;
using System.Linq;
using PTC.DataLayer;
using PTC.DataLayer.EntityClasses;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Collections.Specialized;

namespace PTC.ViewModelLayer
{
  public class ProductViewModel
  {
    #region Constructor
    /// <summary>
    /// Constructor for ProductViewModel.
    /// </summary>
    public ProductViewModel()
      : base() {
      Init();
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the collection of Product data
    /// </summary>
    public List<Product> DataCollection { get; set; }
    /// <summary>
    /// Get/Set the data to use for searching
    /// </summary>
    public ProductSearch SearchEntity { get; set; }
    /// <summary>
    /// Get/Set the Action to Perform
    /// </summary>
    public string EventAction { get; set; }
    /// <summary>
		/// Get/Set Event Argument
		/// </summary>
    public string EventArgument { get; set; }
    /// <summary>
    /// Get/Set a message to display to the user
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// Get/Set what mode this page is currently in
    /// </summary>
    public PDSAPageModeEnum PageMode { get; set; }
    /// <summary>
    /// Get/Set whether or not the current state of this view model is valid
    /// </summary>
    public bool IsValid { get; set; }
    /// <summary>
    /// Get/Set the entity to add/edit
    /// </summary>
    public Product Entity { get; set; }
    /// <summary>
		/// Get/Set a collection of messages to display.
		/// </summary>
    public List<string> Messages { get; set; }
    #endregion

    #region Init Method
    /// <summary>
    /// Initialize all public/private properties
    /// </summary>
    public void Init() {
      // Initialize properties in this class
      DataCollection = new List<Product>();
      SearchEntity = new ProductSearch();
      EventAction = string.Empty;
      EventArgument = string.Empty;
      Message = string.Empty;
      Messages = new List<string>();
      PageMode = PDSAPageModeEnum.List;
      IsValid = true;
      Entity = new Product();
    }
    #endregion

    #region HandleRequest Method
    public void HandleRequest() {
      // Make sure we have a valid event command
      EventAction = (EventAction == null ? "" : EventAction.ToLower());

      Message = string.Empty;
      switch (EventAction) {
        case "add":
          IsValid = true;
          PageMode = PDSAPageModeEnum.Add;
          break;

        case "edit":
          IsValid = true;
          PageMode = PDSAPageModeEnum.Edit;
          GetEntity();
          break;

        case "search":
          PageMode = PDSAPageModeEnum.List;
          break;

        case "cancel":
          PageMode = PDSAPageModeEnum.List;
          break;

        case "save":
          Save();
          break;

        case "delete":
          Delete();
          break;

        case "resetsearch":
          PageMode = PDSAPageModeEnum.List;
          SearchEntity = new ProductSearch();
          break;
      }

      if (PageMode == PDSAPageModeEnum.List) {
        BuildCollection();

        if (PageMode == PDSAPageModeEnum.List) {
          if (DataCollection.Count == 0) {
            Message = "No Product Data Found.";
          }
        }
      }
    }
    #endregion

    #region BuildCollection Method
    /// <summary>
    /// Fill in the DataCollection with products from the database
    /// </summary>
    protected void BuildCollection() {
      PTCData db = null;

      try {
        db = new PTCData();

        // Get the collection
        DataCollection = db.Products.ToList();

        // Filter the collection
        if (DataCollection != null && DataCollection.Count > 0) {
          if (!string.IsNullOrEmpty(SearchEntity.ProductName)) {
            DataCollection = DataCollection.FindAll(
              p => p.ProductName
                  .StartsWith(SearchEntity.ProductName,
                  StringComparison.InvariantCultureIgnoreCase));
          }
        }
      }
      catch (Exception ex) {
        Publish(ex, "Error while loading products.");
      }
    }
    #endregion

    #region GetEntity Method
    /// <summary>
    /// Call data layer to get a single object
    /// </summary>
    protected virtual void GetEntity() {
      PTCData db = null;

      try {
        db = new PTCData();

        // Get the entity
        if (!string.IsNullOrEmpty(EventArgument)) {
          Entity = db.Products.Find(Convert.ToInt32(EventArgument));
        }
      }
      catch (Exception ex) {
        Publish(ex, "Error Retrieving Product With ID=" + EventArgument);
      }
    }
    #endregion

    #region Publish Methods
    public void Publish(Exception ex, string message) {
      Publish(ex, message, null);
    }

    public void Publish(Exception ex, string message,
                        NameValueCollection nvc) {
      // Update view model properties
      Message = message;

      // TODO: Publish exception here

    }
    #endregion

    #region ValidationErrorsToMessage Method
    protected void ValidationErrorsToMessages(DbEntityValidationException ex) {
      foreach (DbEntityValidationResult result in ex.EntityValidationErrors) {
        foreach (DbValidationError item in result.ValidationErrors) {
          Messages.Add(item.ErrorMessage);
        }
      }
    }
    #endregion

    #region Save Method
    protected void Save() {
      IsValid = true;

      if (PageMode == PDSAPageModeEnum.Add) {
        Insert();
      }
      else {
        Update();
      }
    }
    #endregion

    #region Insert Method
    protected void Insert() {
      PTCData db = null;

      try {
        db = new PTCData();

        // Do editing here
        db.Products.Add(Entity);
        db.SaveChanges();

        PageMode = PDSAPageModeEnum.List;
      }
      catch (DbEntityValidationException ex) {
        IsValid = false;
        ValidationErrorsToMessages(ex);
      }
      catch (Exception ex) {
        Publish(ex, "Error Inserting New Product: '" + Entity.ProductName + "'");
      }
    }
    #endregion

    #region Update Method
    protected void Update() {
      PTCData db = null;

      try {
        db = new PTCData();

        // Do editing here
        db.Entry(Entity).State = EntityState.Modified;
        db.SaveChanges();

        PageMode = PDSAPageModeEnum.List;
      }
      catch (DbEntityValidationException ex) {
        IsValid = false;
        ValidationErrorsToMessages(ex);
      }
      catch (Exception ex) {
        Publish(ex, "Error Updating Product With ID=" + Entity.ProductId.ToString());
      }
    }
    #endregion

    #region Delete Method
    /// <summary>
    /// Delete an object by looking up the record using the primary key in the EventArgument property
    /// </summary>
    public virtual void Delete() {
      PTCData db = null;

      try {
        db = new PTCData();

        if (!string.IsNullOrEmpty(EventArgument)) {
          Entity = db.Products.Find(Convert.ToInt32(EventArgument));

          db.Products.Remove(Entity);
          db.SaveChanges();

          PageMode = PDSAPageModeEnum.List;
        }
      }
      catch (Exception ex) {
        Publish(ex, "Error Deleting Product With ID=" + Entity.ProductName);
      }
    }
    #endregion
  }
}
