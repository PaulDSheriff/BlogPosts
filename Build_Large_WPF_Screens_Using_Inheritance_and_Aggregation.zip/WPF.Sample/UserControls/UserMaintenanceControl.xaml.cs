﻿using System.Windows.Controls;

namespace WPF.Sample.UserControls
{
  public partial class UserMaintenanceControl : UserControl
  {
    public UserMaintenanceControl()
    {
      InitializeComponent();
    }
  }
}
