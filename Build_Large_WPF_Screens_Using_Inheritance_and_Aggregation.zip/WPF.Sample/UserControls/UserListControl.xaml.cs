﻿using System.Windows.Controls;

namespace WPF.Sample.UserControls
{
  public partial class UserListControl : UserControl
  {
    public UserListControl()
    {
      InitializeComponent();
    }
  }
}
