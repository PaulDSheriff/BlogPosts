﻿using System.Windows;
using System.Windows.Controls;
using WPF.Sample.ViewModels;

namespace WPF.Sample.UserControls
{
  public partial class UserDetailControl : UserControl
  {
    public UserDetailControl()
    {
      InitializeComponent();
    }

    // Create a reference to the view model
    private UserMaintenanceViewModel _viewModel = null;

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // DataContext is an instance of the UserMaintenanceViewModel class
      _viewModel = (UserMaintenanceViewModel)this.DataContext;
    }

    private void SaveButton_Click(object sender, RoutedEventArgs e)
    {
      // Save User
      _viewModel.Save();

      MessageBox.Show("User: " + _viewModel.Entity.UserName + " has been saved.");
    }

    private void DeleteButton_Click(object sender, RoutedEventArgs e)
    {
      // Delete User
      _viewModel.Delete();

      MessageBox.Show("User: " + _viewModel.Entity.UserName + " has been deleted.");
    }
  }
}
