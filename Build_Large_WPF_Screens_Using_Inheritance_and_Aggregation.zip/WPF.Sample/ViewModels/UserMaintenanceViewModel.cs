﻿namespace WPF.Sample.ViewModels
{
  public class UserMaintenanceViewModel : UserDetailViewModel
  {
  }
}
