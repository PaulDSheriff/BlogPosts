﻿DataWrapper.Samples.ViewModelLayer
------------------------------------------
This project contains view model classes
These classes call the Manager classes to retrieve and modify data
These view model classes are called from your ASP.NET controller classes or your WPF controls