﻿using System.Web.Mvc;

namespace DataWrapper.Samples.Controllers
{
  public class HomeController : Controller
  {
    public ActionResult Index()
    {
      return View();
    }
  }
}