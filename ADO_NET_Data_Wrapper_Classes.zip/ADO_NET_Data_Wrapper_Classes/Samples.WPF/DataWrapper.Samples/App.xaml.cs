﻿using System.Windows;
using DataWrapper.Samples.AppLayer;

namespace DataWrapper.Samples
{
  public partial class App : Application
  {
    protected override void OnStartup(StartupEventArgs e)
    {
      base.OnStartup(e);


    }
  }
}
