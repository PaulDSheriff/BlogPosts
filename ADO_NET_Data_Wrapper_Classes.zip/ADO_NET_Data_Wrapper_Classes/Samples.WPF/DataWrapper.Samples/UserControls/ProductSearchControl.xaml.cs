﻿using System.Windows.Controls;

namespace DataWrapper.Samples.UserControls
{
  public partial class ProductSearchControl : UserControl
  {
    public ProductSearchControl()
    {
      InitializeComponent();
    }    
  }
}
