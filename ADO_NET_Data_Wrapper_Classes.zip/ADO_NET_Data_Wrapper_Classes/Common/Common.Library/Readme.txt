﻿Common.Library
------------------------------------------
Place classes and other items in here that are NOT UI-Specific in this project.
  No references to WPF or ASP.NET, etc.
