﻿Common.DataLayer.Oracle
------------------------------------------
To use Oracle, you must define a compiler constant ORACLE
You must also add the appropriate Oracle provider
You will probably need to change the using statements to use the appropriate Oracle provider namespaces