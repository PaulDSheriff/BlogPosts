﻿Common.DataLayer.SqlServer
------------------------------------------
Place classes in here that are specific to interacting with SQL Server
