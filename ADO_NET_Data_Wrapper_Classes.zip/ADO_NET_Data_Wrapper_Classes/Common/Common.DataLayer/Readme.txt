﻿Common.DataLayer
------------------------------------------
The classes in this DLL are the wrapper around ADO.NET
