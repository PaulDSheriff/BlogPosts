﻿using System.Web.Mvc;
using FileUploadSamples.ViewModels;

namespace FileUploadSamples.Controllers
{
  public class FileStorageSamplesController : Controller
  {
    #region Sample 1
    public ActionResult Sample01()
    {
      FileStorageViewModel vm = new FileStorageViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Sample01(FileStorageViewModel vm)
    {
      // Store onto file system
      vm.Save();

      // Look at properties of View Model
      System.Diagnostics.Debugger.Break();

      // TODO: Do something with the file data

      return View(vm);
    }
    #endregion
  }
}