﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace PTC.Controllers
{
  public class ProductController : Controller
  {
    public ActionResult Product() {
       return View();
    }

    [HttpPost]
    public ActionResult Product(ProductViewModel vm) {
      if (vm.EventAction == "cancel") {
        vm.HandleRequest();
      }
      else {
        vm.IsValid = ModelState.IsValid;
        if (ModelState.IsValid) {
          // Handle action by user
          vm.HandleRequest();

          // Rebind controls
          ModelState.Clear();
        }
      }

      return View(vm);
    }
  }
}