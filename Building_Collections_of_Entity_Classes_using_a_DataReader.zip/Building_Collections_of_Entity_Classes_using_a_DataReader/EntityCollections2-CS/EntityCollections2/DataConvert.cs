﻿using System;

namespace EntityCollections2
{
  public class DataConvert
  {
    public static T ConvertTo<T>(object value, T defaultValue) where T : struct
    {
      if (value.Equals(DBNull.Value))
        return defaultValue;
      else
        return (T)value;
    }
  }
}
