﻿Public Class DataConvert
  Public Shared Function ConvertTo(Of T As Structure)(value As Object, defaultValue As T) As T
    If value.Equals(DBNull.Value) Then
      Return defaultValue
    Else
      Return DirectCast(value, T)
    End If
  End Function
End Class
