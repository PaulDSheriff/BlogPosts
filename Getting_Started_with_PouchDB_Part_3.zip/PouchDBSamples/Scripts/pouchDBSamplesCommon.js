﻿let pouchDBSamplesCommon = (function () {
  //*************************************
  //* Private Functions
  //*************************************
  function displayMessage(msg) {
    $("#messageArea").removeClass("hidden");
    $("#message").text(msg);
    console.log(msg);
  }

  function displayJSON(data) {
    $("#jsonArea").removeClass("hidden");
    $("#json").text(JSON.stringify(data, undefined, 2));
  }

  function hideMessageAreas() {
    $("#messageArea").addClass("hidden");
    $("#message").text("");
    $("#jsonArea").addClass("hidden");
    $("#json").text("");
  }

  //************************************
  //* Public Functions
  //************************************
  return {
    displayMessage: displayMessage,
    displayJSON: displayJSON,
    hideMessageAreas: hideMessageAreas
  }
})();
