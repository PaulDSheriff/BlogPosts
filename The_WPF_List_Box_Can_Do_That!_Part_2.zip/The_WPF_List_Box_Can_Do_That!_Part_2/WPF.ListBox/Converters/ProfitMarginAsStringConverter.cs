﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;

namespace WPF.ListBox
{
  public class ProfitMarginAsStringConverter : IMultiValueConverter
  {
    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
    {
      decimal ret = 0;
      decimal cost = 0;
      decimal price = 0;

      if (values.Count() > 1) {
        // First parameter is cost
        cost = System.Convert.ToDecimal(values[0]);
        // Second parameter is price
        price = System.Convert.ToDecimal(values[1]);
        // Calculate the profit margin
        ret = Math.Round(((price - cost) / cost), 1);
      }

      return ret.ToString("P");
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }
}
