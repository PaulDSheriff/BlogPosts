﻿using System.Windows.Controls;

namespace WPF.ListBox.Display
{
  public partial class Sample03 : UserControl
  {
    public Sample03()
    {
      InitializeComponent();
    }
  }
}
