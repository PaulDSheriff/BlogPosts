﻿using System.Windows;
using System.Windows.Controls;

namespace WPF.ListBox.Display
{
  public partial class Sample02 : UserControl
  {
    public Sample02()
    {
      InitializeComponent();
    }

    private void LessButton_Click(object sender, RoutedEventArgs e)
    {
      ProductList.ItemTemplate = (DataTemplate)this.FindResource("ProductSmallTemplate");
    }

    private void MoreButton_Click(object sender, RoutedEventArgs e)
    {
      ProductList.ItemTemplate = (DataTemplate)App.Current.FindResource("ProductLargeTemplate");
    }
  }
}
