﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace WPF.ListBox
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void MenuItem_Click(object sender, RoutedEventArgs e)
    {
      // Display a user control
      LoadUserControl(((MenuItem)sender).Tag.ToString());
    }

    private void LoadUserControl(string controlName)
    {
      Type ucType = null;
      UserControl uc = null;

      // Create a Type from controlName parameter
      ucType = Type.GetType(controlName);
      if (ucType == null) {
        MessageBox.Show("The Control: " + controlName
                          + " does not exist.");
      }
      else {
        // Close current user control in content area
        contentArea.Children.Clear();

        // Create an instance of this control
        uc = (UserControl)Activator.CreateInstance(ucType);
        if (uc != null) {
          // Display control in content area
          contentArea.Children.Add(uc);
        }
      }
    }

    private void Exit_Click(object sender, RoutedEventArgs e)
    {
      this.Close();
    }
  }
}
