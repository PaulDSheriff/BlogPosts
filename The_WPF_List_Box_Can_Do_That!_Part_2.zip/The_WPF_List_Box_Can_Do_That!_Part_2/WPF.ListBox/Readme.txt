﻿This sample shows how to change the display of items in a WPF ListBox.


\Samples-Display
-------------------------------------------------------
Sample01 - Horizontal ListBox
Sample02 - Change templates at runtime
Sample03 - Using a multi-binding converter
