namespace DataLayer
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CreditCard")]
    public partial class CreditCard
    {
        public Guid CreditCardId { get; set; }

        [Required]
        [StringLength(20)]
        public string CardType { get; set; }

        [Required]
        [StringLength(100)]
        public string NameOnCard { get; set; }

        [Required]
        [StringLength(25)]
        public string CardNumber { get; set; }

        [Required]
        [StringLength(4)]
        public string SecurityCode { get; set; }

        public short ExpMonth { get; set; }

        public short ExpYear { get; set; }

        [Required]
        [StringLength(10)]
        public string BillingPostalCode { get; set; }
    }
}
