﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
  public partial class PTC
  {
    protected override DbEntityValidationResult ValidateEntity(DbEntityEntry entityEntry, IDictionary<object, object> items) {
      List<DbValidationError> list = new List<DbValidationError>();

      if (entityEntry.Entity is CreditCard) {
        CreditCard entity = entityEntry.Entity as CreditCard;

        list = ValidateCreditCard(entity);

        if (list.Count > 0) {
          return new DbEntityValidationResult(entityEntry, list);
        }
      }
      
      return base.ValidateEntity(entityEntry, items);
    }

    protected List<DbValidationError> ValidateCreditCard(CreditCard entity) {
      List<DbValidationError> list =
        new List<DbValidationError>();

      // Check Name on Card
      if (entity.NameOnCard.ToLower() == entity.NameOnCard) {
        list.Add(new DbValidationError("NameOnCard",
          "Name on Card must not be all lower case."));
      }

      // Check Card Number
      entity.CardNumber = entity.CardNumber
        .Replace("-", "").Replace(" ", "");
      if (entity.CardNumber.Length < 13 ||
          entity.CardNumber.Length > 16) {
        list.Add(new DbValidationError("CardNumber",
          "Card Number is not valid"));
      }

      // Check Security Code
      if (entity.SecurityCode.Length < 3 ||
          entity.SecurityCode.Length > 4) {
        list.Add(new DbValidationError("SecurityCode",
          "Security Code is not valid"));
      }

      // Check Month and Year
      if (entity.ExpMonth < 1 ||
          entity.ExpMonth > 12) {
        list.Add(new DbValidationError("ExpMonth",
          "Invalid Month."));
      }
      else {
        if (entity.ExpYear < DateTime.Now.Year ||
            entity.ExpYear > DateTime.Now.Year +
                Convert.ToInt32(ConfigurationManager.AppSettings["YearsInFuture"])) {
          list.Add(new DbValidationError("ExpYear",
            string.Format("Expiration Year must be greater than { 0 } and less than { 1}.",
                DateTime.Now.Year.ToString(), 
              ConfigurationManager.AppSettings["YearsInFuture"])));
        }
        else {
          if (entity.ExpMonth < DateTime.Now.Month &&
              entity.ExpYear == DateTime.Now.Year) {
            list.Add(new DbValidationError("ExpYear",
              "Expiration Month/Year must be greater than this month."));
          }
        }
      }

      return list;
    }

  }
}
