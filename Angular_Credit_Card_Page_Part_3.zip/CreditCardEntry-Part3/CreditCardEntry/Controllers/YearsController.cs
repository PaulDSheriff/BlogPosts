﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ViewModelLayer;

namespace CreditCardEntry.Controllers
{
  public class YearsController : ApiController
  {
    public IHttpActionResult Get() {
      IHttpActionResult ret;
      CreditCardViewModel vm = new CreditCardViewModel();

      vm.LoadYears(
        Convert.ToInt32(
          ConfigurationManager.AppSettings["YearsInFuture"]));

      if (vm.Years.Count() > 0) {
        ret = Ok(vm.Years);
      }
      else {
        ret = NotFound();
      }

      return ret;
    }

  }
}