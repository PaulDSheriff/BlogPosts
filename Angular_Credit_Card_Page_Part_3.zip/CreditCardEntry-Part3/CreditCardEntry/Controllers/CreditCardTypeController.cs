﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ViewModelLayer;

namespace CreditCardEntry.Controllers
{
  public class CreditCardTypeController : ApiController
  {
    public IHttpActionResult Get() {
      IHttpActionResult ret;
      CreditCardViewModel vm = new CreditCardViewModel();

      vm.LoadCardTypes();
      if (vm.CardTypes.Count() > 0) {
        ret = Ok(vm.CardTypes);
      }
      else {
        ret = NotFound();
      }

      return ret;
    }

  }
}