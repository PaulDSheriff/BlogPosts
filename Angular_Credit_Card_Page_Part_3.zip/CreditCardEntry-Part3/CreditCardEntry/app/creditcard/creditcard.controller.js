﻿(function () {
  "use strict";

  angular.module("app")
    .controller("CreditCardController", CreditCardController);

  function CreditCardController($http, $location) {
    var vm = this;
    var dataService = $http;

    // Expose public properties
    vm.cardTypes = [];
    vm.months = [];
    vm.years = [];

    vm.selectedCardType = {};
    vm.selectedMonth = {};

    vm.creditCard = {
      creditCardId: null,
      cardType: null,
      nameOnCard: null,
      cardNumber: null,
      securityCode: null,
      expMonth: null,
      expYear: null,
      billingPostalCode: null
    };

    vm.uiState = {
      isMessageAreaHidden: true,
      isLoading: true,
      messages: []
    };

    // Expose public functions
    vm.saveClick = saveClick;

    // Initialize Controller
    loadCardTypes();
    loadYears();
    loadMonths();

    // Load Credit Card Types
    function loadCardTypes() {
      dataService.get("/api/CreditCardType")
        .then(function (result) {
          vm.cardTypes = result.data;

          if (vm.cardTypes.length > 0) {
            vm.selectedCardType = vm.cardTypes[0];
          }
        },
        function (error) {
          handleException(error);
        });
    }

    // Load years
    function loadYears() {
      var year = new Date().getFullYear();

      dataService.get("/api/Years")
        .then(function (result) {
          vm.years = result.data;

          vm.creditCard.expYear = year;
        },
        function (error) {
          handleException(error);
        });
    }

    // Load months
    function loadMonths() {
      var today = new Date();

      // Get the language from the browser
      var language =
         navigator.languages &&
         navigator.languages[0] || // Chrome / Firefox
         navigator.language ||     // All browsers
         navigator.userLanguage;   // IE <= 10

      dataService.get("/api/MonthNames/" + language)
        .then(function (result) {
          // Transform the data to use nn - monthName format
          for (var index = 0;
                   index < result.data.length;
                   index++) {
            var month = {
              monthNumber: index + 1,
              monthName: (index + 1).toString()
                + "-" + result.data[index].monthName
            };
            vm.months.push(month);
          }

          // Figure out which month to select
          // Make it next month by default
          vm.creditCard.expMonth = today.getMonth() + 2;
          // If past December, make it January of next year
          if (vm.creditCard.expMonth > 12) {
            vm.creditCard.expMonth = 1;
            vm.creditCard.expYear = vm.creditCard.expYear + 1;
          }
          vm.selectedMonth =
            vm.months[vm.creditCard.expMonth - 1];

          vm.uiState.isLoading = false;
        },
        function (error) {
          handleException(error);
        });
    }

    function saveClick(creditCardForm) {
      if (creditCardForm.$valid) {
        vm.uiState.isMessageAreaHidden = true;
        creditCardForm.$setPristine();
        insertData();
      }
      else {
        vm.uiState.isMessageAreaHidden = false;
      }
    }

    function insertData() {
      // Clean up object before sending to server
      cleanUpData();

      // Post credit card info to server
      dataService.post(
          "/api/CreditCard", vm.creditCard)
        .then(function (result) {
          // Update credit card object
          vm.creditCard = result.data;

          // Redirect back to home page
          $location.path("/");

        }, function (error) {
          handleException(error);
        });
    }

    function cleanUpData() {
      // Get card type
      vm.creditCard.cardType =
          vm.selectedCardType.cardType;
      // Get expiration month
      vm.creditCard.expMonth =
          vm.selectedMonth.monthNumber;
    }

    function handleException(error) {
      vm.uiState.isMessageAreaHidden = false;
      vm.uiState.isLoading = false;
      vm.uiState.messages = [];

      switch (error.status) {
        case 400:   // 'Bad Request'
          // Model state errors
          var errors = error.data.modelState;

          // Loop through and get all 
          // validation errors
          for (var key in errors) {
            for (var i = 0; i < errors[key].length;
                    i++) {
              vm.uiState.messages.push({
                property: key,
                message: errors[key][i]
              });
            }
          }

          break;

        case 404:  // 'Not Found'
          vm.uiState.messages.push(
            {
              message: "The data you were " +
                        "requesting could not be found"
            });
          break;

        case 500:  // 'Internal Error'
          vm.uiState.messages.push(
            {
              message: error.data.exceptionMessage
            });
          break;

        default:
          vm.uiState.messages.push(
            {
              message: "Status: " +
                      error.status +
                      " - Error Message: " +
                      error.statusText
            });
          break;
      }
    }

  }
})();
