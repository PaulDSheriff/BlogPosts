﻿(function () {
  "use strict";

  angular.module("app")
   .directive('pdsaValidatenotlowercase',
    function () {
      return {
        require: 'ngModel',
        link: function (scope, element,
                        attributes, ngModel) {
          ngModel.$validators
            .pdsavalidatenotlowercase =
            function (value) {
              if (value) {
                return value.toLowerCase() != value;
              }

              return true;
            }
        }
      };
    })
  .directive('pdsaValidatecreditcard',
    function () {
      return {
        require: 'ngModel',
        link: function (scope, element,
                        attributes, ngModel) {
          ngModel.$validators
           .pdsavalidatecreditcard =
            function (value) {
              if (value) {
                value = value.toString().split("-").join("")
                    .split(" ").join("");
                return value.length >= 13 &&
                       value.length <= 16;
              }

              return true;
            }
        }
      };
    })
  .directive('pdsaValidatesecuritycode',
    function () {
      return {
        require: 'ngModel',
        link: function (scope, element,
                        attributes, ngModel) {
          ngModel.$validators
            .pdsavalidatesecuritycode =
            function (value) {
              if (value) {
                return value.length === 3 ||
                       value.length === 4;
              }

              return true;
            }
        }
      };
    });
})();
