﻿(function () {
  'use strict';

  // Create angular routing
  angular.module('app')
    .config(['$routeProvider', function ($routeProvider) {
      $routeProvider
      .when('/',
      {
        templateUrl: 'app/index/index-splash.html',
        controllerAs: 'vm',
        controller: 'IndexController'
      })
      .when('/creditcard',
      {
        templateUrl: 'app/creditcard/creditcard.html',
        controllerAs: 'vm',
        controller: 'CreditCardController'
      })
      .otherwise(
      {
        redirectTo: '/'
      });
    }]);
})();
