﻿using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Formatting;
using System.Web;
using System.Web.Http;
using System.Web.Routing;

namespace CreditCardEntry
{
  public class WebApiApplication : System.Web.HttpApplication
  {
    protected void Application_Start() {
      GlobalConfiguration.Configure(WebApiConfig.Register);

      // Handle self-referencing in Entity Framework
      HttpConfiguration config =
        GlobalConfiguration.Configuration;
      config.Formatters.JsonFormatter
        .SerializerSettings.ReferenceLoopHandling =
           Newtonsoft.Json.ReferenceLoopHandling.Ignore;

      // Convert to camelCase
      var jsonFormatter = config.Formatters
         .OfType<JsonMediaTypeFormatter>().FirstOrDefault();
      jsonFormatter.SerializerSettings.ContractResolver =
         new CamelCasePropertyNamesContractResolver();

    }
  }
}
