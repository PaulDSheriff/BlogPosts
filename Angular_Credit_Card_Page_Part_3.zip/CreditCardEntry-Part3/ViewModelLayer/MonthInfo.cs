﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModelLayer
{
  public partial class MonthInfo
  {
    public MonthInfo(short number, string name) {
      MonthNumber = number;
      MonthName = name;
    }
    public short MonthNumber { get; set; }
    public string MonthName { get; set; }
  }
}
