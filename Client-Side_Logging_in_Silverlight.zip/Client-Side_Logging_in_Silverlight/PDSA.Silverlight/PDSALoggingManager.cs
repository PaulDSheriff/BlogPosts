﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.IsolatedStorage;
using System.Reflection;
using System.Text;
using System.Diagnostics;

namespace PDSA.Silverlight
{
  /// <summary>
  /// This class is used to log client-side Silverlight messages to isolated storage
  /// </summary>
  public class PDSALoggingManager
  {
    #region Constructor
    /// <summary>
    /// Constructor for PDSALoggingManager
    /// </summary>
    public PDSALoggingManager()
    {
      LogFileName = "PDSALogging";
      LogSystemInfo = false;
      Delimiter = Environment.NewLine;
      CallingClassName = string.Empty;
      TheLog = new StringBuilder(1024);
    }
    #endregion

    #region Constants
    private const char EXTRA_VALUES = '-';
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the current Log data in memory
    /// </summary>
    public StringBuilder TheLog { get; set; }
    /// <summary>
    /// Get/Set the calling class name
    /// </summary>
    public string CallingClassName { get; set; }
    /// <summary>
    /// Get/Set the log file name to use in isolated storage
    /// </summary>
    public string LogFileName { get; set; }
    /// <summary>
    /// Get/Set whether or not to log System information. The default is false
    /// </summary>
    public bool LogSystemInfo { get; set; }
    /// <summary>
    /// Get/Set the delimiter to use to separate items in the log. The default is Environment.Newline
    /// </summary>
    public string Delimiter { get; set; }
    #endregion

    #region Instance Property
    private static PDSALoggingManager _Instance = null;
    /// <summary>
    /// A static/Shared instance of the PDSALoggingManager class.
    /// </summary>
    public static PDSALoggingManager Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new PDSALoggingManager();

        return _Instance;
      }
      set
      {
        _Instance = value;
      }
    }
    #endregion

    #region Log Methods
    /// <summary>
    /// Logs an informational entry
    /// </summary>
    /// <param name="value">The value to log</param>
    public void Log(string value)
    {
      this.Log(value, "Informational", null);
    }

    /// <summary>
    /// Logs an informational entry
    /// </summary>
    /// <param name="value">The value to log</param>
    /// <param name="extraValues">A collection of extra values to write to the log</param>
    public void Log(string value, Dictionary<string, string> extraValues)
    {
      this.Log(value, "Informational", extraValues);
    }

    /// <summary>
    /// Logs an Exception entry
    /// </summary>
    /// <param name="value">The exception data to log</param>
    public void LogException(Exception ex)
    {
      this.Log(ex.ToString(), "Exception", null);
    }

    /// <summary>
    /// Logs an Exception entry with extra values
    /// </summary>
    /// <param name="value">The exception data to log</param>
    /// <param name="extraValues">A collection of extra values to write to the log</param>
    public void LogException(Exception ex, Dictionary<string, string> extraValues)
    {
      this.Log(ex.ToString(), "Exception", extraValues);
    }

    /// <summary>
    /// This is the method that all other "log" methods call to write to the log providers
    /// </summary>
    /// <param name="value">The value to Log</param>
    /// <param name="logType">The type of log entry to create</param>
    /// <param name="extraValues">A collection of extra values to write to the log</param>
    public void Log(string value, string logType, Dictionary<string, string> extraValues)
    {
      IsolatedStorageFile file = null;
      string message = string.Empty;

      try
      {
        // Get Calling Class Name
        CallingClassName = GetCallingClassName();
        // Format this log entry
        message = Format(value, logType, extraValues);
        // Get a reference to a file in Isolated Storage
        file = IsolatedStorageFile.GetUserStoreForSite();
        using (IsolatedStorageFileStream fs = new IsolatedStorageFileStream(LogFileName, FileMode.Append, file))
        {
          using (StreamWriter sw = new StreamWriter(fs))
          {
            // Write the information to the Isolated Storage file
            sw.WriteLine(message);
          }
        }
      }
      catch (Exception ex)
      {
        TheLog.Append("Exception Occurred in Log() method" + Delimiter + ex.ToString());
      }
      finally
      {
        if (file != null)
          file.Dispose();
      }
    }
    #endregion

    #region Format Method
    /// <summary>
    /// Format the values of the logging provider for publishing to a log destination
    /// </summary>
    /// <param name="value">The value to Log</param>
    /// <param name="logType">The type of log entry to create</param>
    /// <param name="extraValues">A collection of extra values to write to the log</param>
    /// <returns>A string formatted with information to log</returns>
    protected virtual string Format(string value, string logType,
                    Dictionary<string, string> extraValues)
    {
      StringBuilder sb = new StringBuilder(512);

      if (string.IsNullOrEmpty(Delimiter))
        Delimiter = Environment.NewLine;

      if (LogSystemInfo)
        sb.Append(new string('-', 200) + Delimiter);

      sb.Append("'" + logType + "'");
      sb.Append(" log entry written on " + DateTime.Now.ToString());
      if (!string.IsNullOrEmpty(CallingClassName))
        sb.Append(", from class: '" + CallingClassName + "'");
      sb.Append(Delimiter);
      sb.Append("   " + value + Delimiter);
      // Add on Extra Values
      sb.Append(FormatKeyValuePairs(extraValues));
      if (LogSystemInfo)
      {
        PDSASystemInfo si = new PDSASystemInfo();

        sb.Append(si.GetAllSystemInfo(Delimiter));
        sb.Append(Delimiter);
        sb.Append(new string('-', 200) + Delimiter);
      }

      // Append to the main log property
      TheLog.Append(sb.ToString());

      return sb.ToString();
    }
    #endregion

    #region FormatKeyValuePairs
    /// <summary>
    /// Formats the values for extra user-defined values 
    /// </summary>
    /// <param name="extraValues">A NameValueCollection object of extra information to log</param>
    /// <returns>A string formatted with the extra values</returns>
    protected virtual string FormatKeyValuePairs(Dictionary<string, string> extraValues)
    {
      StringBuilder sb = new StringBuilder(512);

      if (extraValues != null)
      {
        sb.Append("Extra Values Passed In From Application" + Delimiter);
        foreach (KeyValuePair<String, String> entry in extraValues)
        {
          sb.Append("   " + entry.Key);
          sb.Append("=");
          sb.Append(entry.Value);
          sb.Append(Delimiter);
        }
      }
      return sb.ToString();
    }
    #endregion

    #region GetCallingClassName Method
    /// <summary>
    /// Gets the name of the class that called the Logging System.
    /// </summary>
    /// <returns>A class name</returns>
    public string GetCallingClassName()
    {
      int loop = 0;
      string ret = string.Empty;
      string currentName = Assembly.GetExecutingAssembly().FullName;
      
      try
      {
        StackFrame sf = new StackFrame(loop);
        while (sf.GetMethod() != null)
        {
          // Don't get any methods contained in this assembly.
          if (sf.GetMethod().DeclaringType.Assembly.FullName != currentName)
          {
            ret = sf.GetMethod().DeclaringType.FullName;
            break;
          }

          loop++;
          sf = new System.Diagnostics.StackFrame(loop);
        }
      }
      catch
      {
        // Do nothing
      }

      return ret;
    }
    #endregion

    #region ReadLog Method
    /// <summary>
    /// Reads the current log data from memory if the 'TheLog' property has data. Otherwise the log data from the isolated storage file is read and returned.
    /// </summary>
    /// <returns>The log data</returns>
    public string ReadLog()
    {
      string ret = string.Empty;
      IsolatedStorageFile file = null;

      if (TheLog.Length > 0)
      {
        ret = TheLog.ToString();
      }
      else
      {
        try
        {
          file = IsolatedStorageFile.GetUserStoreForSite();
          if (file.FileExists(LogFileName))
          {
            using (IsolatedStorageFileStream fs = new IsolatedStorageFileStream(LogFileName, FileMode.OpenOrCreate, file))
            {
              using (StreamReader sr = new StreamReader(fs))
              {
                ret = sr.ReadToEnd();
              }
            }
          }
        }
        catch (Exception ex)
        {
          TheLog.Append("Exception Occurred in ReadLog() method" + Delimiter + ex.ToString());
        }
        finally
        {
          if (file != null)
            file.Dispose();
        }
      }

      return ret;
    }
    #endregion

    #region DeleteLog Method
    /// <summary>
    /// Delete the isolated storage file and clear the in-memory data in the 'TheLog' property
    /// </summary>
    public void DeleteLog()
    {
      IsolatedStorageFile file = null;

      try
      {
        file = IsolatedStorageFile.GetUserStoreForSite();
        if (file.FileExists(LogFileName))
        {
          file.DeleteFile(LogFileName);
          TheLog.Clear();
        }
      }
      catch (Exception ex)
      {
        TheLog.Append("Exception Occurred in DeleteLog() method" + Delimiter + ex.ToString());
      }
      finally
      {
        if (file != null)
          file.Dispose();
      }
    }
    #endregion

    #region Reset Method
    /// <summary>
    /// Reset all objects
    /// </summary>
    public void Reset()
    {
      TheLog.Clear();
      LogFileName = "PDSALogging";
      LogSystemInfo = true;
      TheLog = new StringBuilder(2048);
    }
    #endregion
  }
}