﻿using System;
using System.Reflection;
using System.Windows.Controls;
using System.Windows.Data;

namespace DataAccessMethods
{
  public class PDSAListView
  {
    #region CreateGridViewColumns Method for Type
    /// <summary>
    /// Used to build the &lt;GridView&gt; and the &lt;GridViewColumn&gt; controls for a WPF ListView. 
    /// This is used when you want to build a ListView of columns using Reflection of a Type
    /// NOTE: You can't use this routine when you have bound the ListView to an ObjectDataProvider.
    /// </summary>
    /// <example>
    ///  lstData.View = PDSAWPFListView.CreateGridViewColumns(typeOf(Product));
    ///  lstData.DataContext = dt;
    /// </example>
    /// <param name="anyType">A Type to extract properties from</param>
    /// <returns>A GridView Object</returns>
    public static GridView CreateGridViewColumns(Type anyType)
    {     
      // Create the GridView
      GridView gv = new GridView();
      GridViewColumn gvc;

      // Get the public properties.
      PropertyInfo[] propInfo = anyType.GetProperties(BindingFlags.Public | BindingFlags.Instance);

      foreach (PropertyInfo item in propInfo)
      {
        gvc = new GridViewColumn();
        gvc.DisplayMemberBinding = new Binding(item.Name);
        gvc.Header = item.Name;
        gvc.Width = Double.NaN;
        gv.Columns.Add(gvc);
      }

      return gv;
    }
    #endregion
  }
}
