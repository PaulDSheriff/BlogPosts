﻿using System;
using System.Windows.Controls;
using System.Windows.Data;
using WPF.ListBox.EntityClasses;
using WPF.ListBox.ViewModelLayer;

namespace WPF.ListBox.FilterSearch
{
  public partial class Sample03 : UserControl
  {
    public Sample03()
    {
      InitializeComponent();
    }

    private string _ProductFilter;

    public string ProductFilter
    {
      get { return _ProductFilter; }
      set {
        _ProductFilter = value;
        CollectionViewSource.GetDefaultView(ProductsList.ItemsSource).Refresh();
      }
    }

    private void ProductsCollection_Filter(object sender, FilterEventArgs e)
    {
      if (e.Item != null && !string.IsNullOrEmpty(ProductFilter)) {
        Product prod = (Product)e.Item;

        e.Accepted = prod.Name
          .StartsWith(ProductFilter, StringComparison.InvariantCultureIgnoreCase);
      }
    }
  }
}
