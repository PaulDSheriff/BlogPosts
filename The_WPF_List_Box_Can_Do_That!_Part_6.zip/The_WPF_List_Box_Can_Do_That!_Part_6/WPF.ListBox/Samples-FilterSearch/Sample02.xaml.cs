﻿using System.Windows;
using System.Windows.Controls;
using WPF.ListBox.ViewModelLayer;

namespace WPF.ListBox.FilterSearch
{
  public partial class Sample02 : UserControl
  {
    public Sample02()
    {
      InitializeComponent();

      _viewModel = (ProductViewModel)this.Resources["viewModel"];
    }

    private readonly ProductViewModel _viewModel = null;

    private void SearchButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.SearchProducts();
    }

    private void RefreshButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.LoadProducts();
    }
  }
}
