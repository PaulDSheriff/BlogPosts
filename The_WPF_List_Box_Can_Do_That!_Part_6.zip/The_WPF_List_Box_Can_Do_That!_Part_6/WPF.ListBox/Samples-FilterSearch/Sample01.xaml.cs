﻿using System.Windows.Controls;

namespace WPF.ListBox.FilterSearch
{
  public partial class Sample01 : UserControl
  {
    public Sample01()
    {
      InitializeComponent();
    }
  }
}
