﻿This sample shows how to search and filter in a WPF ListBox.


\Samples-FilterSearch
-------------------------------------------------------
Sample01 - Simple Text Search
Sample02 - Mult-Field Searching
Sample03 - Using filtering and data-binding