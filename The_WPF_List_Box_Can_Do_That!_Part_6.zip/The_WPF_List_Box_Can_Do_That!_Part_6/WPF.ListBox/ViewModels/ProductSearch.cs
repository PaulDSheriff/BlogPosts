﻿using Common.Library;

namespace WPF.ListBox.ViewModelLayer
{
  public class ProductSearch : CommonBase
  {
    #region Public Properties
    /// <summary>
    /// Get/Set Name
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// Get/Set Color
    /// </summary>
    public string Color { get; set; }

    /// <summary>
    /// Get/Set Size
    /// </summary>
    public string Size { get; set; }

    public void Clear()
    {
      Name = string.Empty;
      Color = string.Empty;
      Size = string.Empty;
      RaisePropertyChanged("Name");
      RaisePropertyChanged("Color");
      RaisePropertyChanged("Size");
    }
    #endregion
  }
}
