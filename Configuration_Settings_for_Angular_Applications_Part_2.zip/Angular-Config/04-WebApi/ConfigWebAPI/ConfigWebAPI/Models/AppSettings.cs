﻿using System;

namespace ConfigWebApi.Models
{
  public class AppSettings
  {
    public string DefaultUrl { get; set; }
    public decimal DefaultPrice { get; set; }
  }
}