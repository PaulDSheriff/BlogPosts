﻿using System.Web.Http;
using System.Web.Http.Cors;
using ConfigWebApi.Models;

namespace ConfigWebApi.Controllers
{
  [EnableCors(origins: "*", headers: "*", methods: "*")]
  public class ConfigController : ApiController
  {
    [HttpGet]
    public IHttpActionResult Get()
    {
      IHttpActionResult ret;
      AppSettings settings = new AppSettings();

      // TODO: Write code here to retrieve 
      //       settings from XML file or SQL table
      // For now, just hard-code some default values
      settings.DefaultPrice = 25;
      settings.DefaultUrl = "http://www.fairwaytech.com/api";

      ret = Ok(settings);

      return ret;
    }
  }
}