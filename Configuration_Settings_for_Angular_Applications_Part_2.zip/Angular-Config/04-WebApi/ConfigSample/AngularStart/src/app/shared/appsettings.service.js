"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Observable_1 = require("rxjs/Observable");
require("rxjs/add/observable/of");
require("rxjs/add/operator/map");
require("rxjs/add/operator/catch");
require("rxjs/add/observable/throw");
var SETTINGS_LOCATION = "http://localhost:8314/api/config";
var SETTINGS_KEY = "configuration";
// ****************************************************
// Application Settings Class
// ****************************************************
var AppSettings = (function () {
    function AppSettings() {
        this.defaultUrl = "http://www.fairwaytech.com";
        this.defaultPrice = 1;
    }
    return AppSettings;
}());
exports.AppSettings = AppSettings;
// ****************************************************
// Application Settings Service Class
// ****************************************************
var AppSettingsService = (function () {
    function AppSettingsService(http) {
        this.http = http;
    }
    AppSettingsService.prototype.getSettings = function () {
        var _this = this;
        var settings = localStorage.getItem(SETTINGS_KEY);
        if (settings) {
            return Observable_1.Observable.of(JSON.parse(settings));
        }
        else {
            return this.http.get(SETTINGS_LOCATION)
                .map(function (response) {
                var settings = response.json();
                if (settings) {
                    _this.saveSettings(settings);
                }
                return settings;
            })
                .catch(this.handleErrors);
        }
    };
    AppSettingsService.prototype.deleteSettings = function () {
        localStorage.removeItem(SETTINGS_KEY);
    };
    AppSettingsService.prototype.saveSettings = function (settings) {
        localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    };
    AppSettingsService.prototype.handleErrors = function (error) {
        // Just log error
        switch (error.status) {
            case 404:
                console.log("Error calling Web API at: " + SETTINGS_LOCATION);
                break;
        }
        // Return default configuration values
        return Observable_1.Observable.of(new AppSettings());
    };
    return AppSettingsService;
}());
AppSettingsService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http])
], AppSettingsService);
exports.AppSettingsService = AppSettingsService;
//# sourceMappingURL=appsettings.service.js.map