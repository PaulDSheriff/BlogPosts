﻿import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';

const SETTINGS_LOCATION = "assets/appsettings.json";

// ****************************************************
// Application Settings Class
// ****************************************************
export class AppSettings {
  defaultUrl: string = "http://www.fairwaytech.com"
  defaultPrice: number = 1
}

// ****************************************************
// Application Settings Service Class
// ****************************************************
@Injectable()
export class AppSettingsService {
  constructor(private http: Http) {
  }

  getSettings(): Observable<AppSettings> {   
    return this.http.get(SETTINGS_LOCATION)
      .map(response => response.json() || {})
      .catch(this.handleErrors);
  }

  private handleErrors(error: any): Observable<AppSettings> {
    // Just log error
    switch (error.status) {
      case 404:
        console.error("Can't find file: " + SETTINGS_LOCATION);
        break;
      default:
        console.error(error);
        break;
    }

    // Return default configuration values
    return Observable.of<AppSettings>(new AppSettings());
  }
}