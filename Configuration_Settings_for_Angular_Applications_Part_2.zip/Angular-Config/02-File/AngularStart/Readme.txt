﻿Changes from last sample
------------------------
Add imports for Http, observable/map, observable/catch
Add SETTINGS_LOCATION constant for file name
Add constructor to inject Http
Modify getSettings() method to call http
Added handleErrors() method
  NOTE: We don't throw an error, instead we return default configuration info