﻿import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

// ****************************************************
// Application Settings Class
// ****************************************************
export class AppSettings {
  defaultUrl: string = "http://www.fairwaytech.com"
  defaultPrice: number = 10
}

// ****************************************************
// Application Settings Service Class
// ****************************************************
@Injectable()
export class AppSettingsService {
  getSettings(): Observable<AppSettings> {    
    return Observable.of<AppSettings>(new AppSettings());
  }
}