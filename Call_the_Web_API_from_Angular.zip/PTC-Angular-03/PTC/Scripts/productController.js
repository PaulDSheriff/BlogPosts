﻿(function () {
  'use strict';

  angular.module('ptcApp')
    .controller('PTCController', PTCController);

  function PTCController($scope, $http) {
    var vm = $scope;
    var dataService = $http;

    // Expose a 'product' object
    vm.product = {
      ProductName: 'Pluralsight Subscription'
    };
    // Create a list of categories
    vm.categories = [
      { CategoryName: 'Videos' },
      { CategoryName: 'Books' },
      { CategoryName: 'Articles' }
    ];
    vm.products = [];

    productList();

    function handleException(error) {
      alert(error.data.ExceptionMessage);
    }

    function productList() {      
      dataService.get("/api/Product")
        .then(function (result) {
          vm.products = result.data;

        }, function (error) {
          handleException(error);
        });
    }
  }
})();
