﻿\index.html - The starting page

\app\index Folder
---------------------------------------------------------------------------------------
index-splash.html - Need this to avoid a recursive call on the ng-view directive.
index.controller.js - Controller for index page
index.module.js - Module for this application
index.route.js - Routing for this application


\app\creditcard Folder
---------------------------------------------------------------------------------------
creditcard.controller.js - Controller for credit card entry
creditcard.html - HTML for credit card page




Credit Card Information
------------------------------------------------------------
Visa and Visa Electron Credit Cards
  13 or 16 digits
Mastercard and Discover Credit Cards
  16 digits
American Express Credit Cards
  15 digits
Diner's Club
  14 digits