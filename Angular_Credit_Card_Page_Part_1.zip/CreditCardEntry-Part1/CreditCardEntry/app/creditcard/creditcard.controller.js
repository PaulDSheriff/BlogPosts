﻿(function () {
  "use strict";

  angular.module("app").controller("CreditCardController",
    CreditCardController);

  function CreditCardController($http, $location) {
    var vm = this;
    var dataService = $http;

    // Create public properties
    vm.cardTypes = [];
    vm.months = [];
    vm.years = [];

    vm.selectedCardType = {};
    vm.selectedMonth = {};

    vm.creditCard = {
      creditCardId: null,
      cardType: null,
      nameOnCard: null,
      cardNumber: null,
      securityCode: null,
      expMonth: null,
      expYear: null,
      billingPostalCode: null
    };

    vm.uiState = {
      isMessageAreaHidden: true,
      isLoading: true,
      messages: []
    };

    // Load drop downs
    loadCardTypes();
    loadYears();
    loadMonths();

    // Load Credit Card Types
    function loadCardTypes() {
      vm.cardTypes.push({ cardType: 'Visa' });
      vm.cardTypes.push({ cardType: 'MasterCard' });
      vm.cardTypes.push({ cardType: 'American Express' });
      vm.cardTypes.push({ cardType: 'Discover' });

      vm.selectedCardType = vm.cardTypes[0];
    }

    // Load years
    function loadYears() {
      var year = new Date().getFullYear();

      for (var i = 0; i < 20 ; i++) {
        vm.years.push((year + i));
      }

      vm.creditCard.expYear = year;
    }

    // Load months
    function loadMonths() {
      var today = new Date();

      vm.months.push({ monthNumber: 1, monthName: 'January' });
      vm.months.push({ monthNumber: 2, monthName: 'February' });
      vm.months.push({ monthNumber: 3, monthName: 'March' });
      vm.months.push({ monthNumber: 4, monthName: 'April' });
      vm.months.push({ monthNumber: 5, monthName: 'May' });
      vm.months.push({ monthNumber: 6, monthName: 'June' });
      vm.months.push({ monthNumber: 7, monthName: 'July' });
      vm.months.push({ monthNumber: 8, monthName: 'August' });
      vm.months.push({ monthNumber: 9, monthName: 'September' });
      vm.months.push({ monthNumber: 10, monthName: 'October' });
      vm.months.push({ monthNumber: 11, monthName: 'November' });
      vm.months.push({ monthNumber: 12, monthName: 'December' });

      // Figure out which month to select
      // Make it next month by default
      vm.creditCard.expMonth = today.getMonth() + 2;
      // If past December, then make it January of the next year
      if (vm.creditCard.expMonth > 12) {
        vm.creditCard.expMonth = 1;
        vm.creditCard.expYear = vm.creditCard.expYear + 1;
      }
      vm.selectedMonth = vm.months[vm.creditCard.expMonth - 1];

      // Set the page UI flag as not loading anymore
      vm.uiState.isLoading = false;
    }
  }
})();