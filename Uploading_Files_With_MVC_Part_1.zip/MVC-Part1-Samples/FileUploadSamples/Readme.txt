﻿\StyleSamples
------------------------
Sample01.cshmtl - Normal look and feel of file upload control
Sample02.cshmtl - Style file upload control as a button
Sample03.cshmtl - Style file upload control as a text box and a glyph

Notes
--------------------------
'name' attribute must be set on file upload input
  The 'name' attribute must match the parameter name on the controller method
Must add the attribute to the form when uploading input
  enctype="multipart/form-data"
