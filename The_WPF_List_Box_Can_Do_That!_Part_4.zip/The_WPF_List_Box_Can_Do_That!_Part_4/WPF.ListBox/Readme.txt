﻿This sample shows how to perform sorting in a WPF ListBox.


\Samples-Sorting
-------------------------------------------------------
Sample01 - Sort using XAML
Sample02 - Sort using Code
