﻿using System.Windows.Controls;

namespace WPF.ListBox.Sorting
{
  public partial class Sample01 : UserControl
  {
    public Sample01()
    {
      InitializeComponent();
    }
  }
}
