﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace WPF.ListBox.Sorting
{
  public partial class Sample02 : UserControl
  {
    public Sample02()
    {
      InitializeComponent();
    }

    private void SortTheData(object sender, RoutedEventArgs e)
    {
      if (ProductList != null) {
        ICollectionView dataView = CollectionViewSource.GetDefaultView(ProductList.ItemsSource);

        // Change sort order
        dataView.SortDescriptions.Clear();
        dataView.SortDescriptions.Add(new SortDescription((sender as RadioButton).Tag.ToString(),
          ListSortDirection.Ascending));

        ProductList.ItemsSource = dataView;
      }
    }
  }
}
