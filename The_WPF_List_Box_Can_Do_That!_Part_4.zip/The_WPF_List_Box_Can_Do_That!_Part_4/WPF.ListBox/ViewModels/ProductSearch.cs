﻿using Common.Library;

namespace WPF.ListBox.ViewModelLayer
{
  public class ProductSearch : CommonBase
  {
    #region Private Variables
    private string _Name;
    private string _Color;
    private string _Size;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set Name
    /// </summary>
    public string Name
    {
      get { return _Name; }
      set {
        _Name = value;
        RaisePropertyChanged("Name");
      }
    }

    /// <summary>
    /// Get/Set Color
    /// </summary>
    public string Color
    {
      get { return _Color; }
      set {
        _Color = value;
        RaisePropertyChanged("Color");
      }
    }

    /// <summary>
    /// Get/Set Size
    /// </summary>
    public string Size
    {
      get { return _Size; }
      set {
        _Size = value;
        RaisePropertyChanged("Size");
      }
    }


    public void Clear()
    {
      Name = string.Empty;
      Color = string.Empty;
      Size = string.Empty;
    }
    #endregion
  }
}
