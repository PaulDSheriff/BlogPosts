﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic;
using System.Xml.Linq;

namespace AppleTunesLibrary
{
  public class AppleSongReader
  {
    public List<Song> Songs { get; set; }
    protected List<XElement> _songElements = null;

    public virtual List<Song> GetAllSongs(string libraryFile)
    {
      Song song = null;

      // Load iTunes XML library
      XElement doc = XElement.Load(libraryFile);

      // Create song collection
      Songs = new List<Song>();

      // Get all songs
      IEnumerable<XElement> songs =
              from dict in doc.Elements("dict")
                              .Elements("dict")
                              .Elements("dict")
              select dict;

      foreach (XElement songNode in songs) {
        // Get all children elements for song
        _songElements = songNode.Elements().ToList();

        // Get song information
        song = new Song();
        song.SongName = GetValue<string>("Name", "Unknown Name");
        song.Artist = GetValue<string>("Artist", "Unknown Artist");
        song.Album = GetValue<string>("Album", "Unknown Album");
        song.Genre = GetValue<string>("Genre", "Unknown Genre");
        song.Year = GetValue<int>("Year", 1900);
        song.Location = GetValue<string>("Location", "Unknown Location");

        // Add song to collection
        this.Songs.Add(song);
      }

      // Sort songs by artist
      Songs = Songs.OrderBy("Artist").ToList();

      return this.Songs;
    }

    protected virtual T GetValue<T>(string keyName, T defaultValue)
    {
      T ret;
      string value = null;
      XElement elem;

      // Attempt to locate key
      elem = _songElements.Find(k => k.Value == keyName);
      if (elem != null) {
        // Get value from next sibling node and clean it up
        value = CleanString(((XElement)elem.NextNode).Value);
      }

      // Convert value into return type
      if (value != null) {
        try {
          ret = (T)Convert.ChangeType(value, typeof(T));
        }
        catch {
          ret = (T)defaultValue;
        }
      }
      else {
        ret = defaultValue;
      }

      return ret;
    }

    protected virtual string CleanString(string value)
    {
      return value.Replace("file://localhost/", "")
            .Replace("%20", " ")
            .Replace("/", @"\")
            .Replace("&amp;", "&")
            .Replace("&#38;", "&")
            .Replace("&lt;", "<")
            .Replace("&gt;", ">")
            .Replace("%23", "#")
            .Replace("%25", "%")
            .Replace("%5B", "[")
            .Replace("%5D", "]")
            .Replace("%C2%AD", "­­­-")
            .Replace("%C3%A0", "à")
            .Replace("%C2%A1", "¡")
            .Replace("%C3%A4", "ä")
            .Replace("%C3%A9", "é")
            .Replace("%C3%BC", "ü")
            .Replace("%C3%9F", "ß")
            .Replace("%C3%A1", "á")
            .Replace("%C5%91", "ő")
            .Replace("%C3%A8", "è")
            .Replace("%C3%B6", "ö")
            .Replace("%C3%AF", "ï")
            .Replace("%C3%B3", "ó")
            .Replace("%C3%AD", "í")
            .Replace("%E5%B9%BD", "幽")
            .Replace("%E5%A5%B3", "女");
    }
  }
}