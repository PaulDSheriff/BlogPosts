﻿using System.Configuration;
using System.Windows;
using System.Windows.Input;
using AppleTunesLibrary;

namespace iTunesReader
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();

      // Get default library path/file name
      txtFileName.Text = ConfigurationManager.AppSettings["libraryFile"];
    }

    private void btnGetSongs_Click(object sender, RoutedEventArgs e)
    {
      AppleSongReader reader = new AppleSongReader();

      // Read all iTunes songs
      Mouse.OverrideCursor = Cursors.Wait;
      reader.GetAllSongs(txtFileName.Text);
      Mouse.OverrideCursor = null;

      // Place song list into ListView control
      lstSongs.DataContext = reader.Songs;

      // Report total songs read
      lblCount.Content = reader.Songs.Count.ToString("###,###");
    }
  }
}
