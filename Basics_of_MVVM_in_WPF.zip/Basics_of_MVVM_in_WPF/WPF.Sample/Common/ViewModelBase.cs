﻿namespace Common.Library
{
  /// <summary>
  /// Base class for all view models
  /// </summary>
  public class ViewModelBase : CommonBase
  {
  }
}
