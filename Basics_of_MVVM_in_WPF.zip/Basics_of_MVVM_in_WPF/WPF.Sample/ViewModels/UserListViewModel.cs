﻿using System;
using System.Collections.ObjectModel;
using Common.Library;

namespace WPF.Sample.ViewModels
{
  public class UserListViewModel : ViewModelBase
  {
    #region Constructor
    public UserListViewModel() : base()
    {
      Users = new ObservableCollection<User>();

      LoadUsers();
    }
    #endregion

    #region Private Variables
    private ObservableCollection<User> _Users = new ObservableCollection<User>();
    #endregion

    #region Public Properties
    public ObservableCollection<User> Users
    {
      get { return _Users; }
      set {
        _Users = value;
        RaisePropertyChanged("Users");
      }
    }
    #endregion

    #region LoadUsers Method
    public virtual void LoadUsers()
    {
      SampleDbContext db = null;

      try {
        db = new SampleDbContext();

        Users = new ObservableCollection<User>(db.Users);
      }
      catch (Exception ex) {
        System.Diagnostics.Debug.WriteLine(ex.ToString());
      }
    }
    #endregion
  }
}