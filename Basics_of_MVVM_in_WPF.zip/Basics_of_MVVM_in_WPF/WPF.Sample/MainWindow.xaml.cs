﻿using System.Windows;
using WPF.Sample.UserControls;

namespace WPF.Sample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void MenuExit_Click(object sender, RoutedEventArgs e)
    {
      this.Close();
    }

    private void MenuUsers_Click(object sender, RoutedEventArgs e)
    {
      // User list using all code-behind
      //contentArea.Children.Add(new UserListControlHardCoded());

      // User list using a view model
      contentArea.Children.Add(new UserListControl());
    }
  }
}
