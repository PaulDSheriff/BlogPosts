﻿using System;
using System.Linq;
using System.Windows.Controls;

namespace WPF.Sample.UserControls
{
  public partial class UserListControlHardCoded : UserControl
  {
    public UserListControlHardCoded()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, System.Windows.RoutedEventArgs e)
    {
      LoadUsers();
    }

    private void LoadUsers()
    {
      SampleDbContext db = null;

      try {
        db = new SampleDbContext();

        lstData.DataContext = db.Users.ToList();
      }
      catch (Exception ex) {
        System.Diagnostics.Debug.WriteLine(ex.ToString());
      }
    }
  }
}
