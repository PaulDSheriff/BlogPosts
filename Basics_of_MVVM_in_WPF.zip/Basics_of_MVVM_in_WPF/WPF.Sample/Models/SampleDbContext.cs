﻿using System.Data.Entity;

namespace WPF.Sample
{
  public partial class SampleDbContext : DbContext
  {
    public SampleDbContext() : base("name=MVVMSample")
    {
    }

    public virtual DbSet<User> Users { get; set; }
  }
}
