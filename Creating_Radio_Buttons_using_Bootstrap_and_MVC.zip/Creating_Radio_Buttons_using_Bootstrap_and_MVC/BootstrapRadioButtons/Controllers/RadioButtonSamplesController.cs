﻿using System.Web.Mvc;

namespace BootstrapRadioButtons.Controllers
{
  public class RadioButtonSamplesController : Controller
  {
    public ActionResult Radio01()
    {
      return View();
    }

    public ActionResult Radio02()
    {
      return View();
    }

    public ActionResult Radio03()
    {
      return View();
    }

    public ActionResult Radio04()
    {
      return View();
    }

    public ActionResult Radio05()
    {
      return View();
    }
  }
}