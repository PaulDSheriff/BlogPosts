﻿
namespace BootstrapRadioButtons
{
  public class Person
  {
    public bool IsMale { get; set; }
  }
}
