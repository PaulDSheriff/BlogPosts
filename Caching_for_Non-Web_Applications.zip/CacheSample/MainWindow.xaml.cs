﻿using System.Windows;

namespace CacheSample {
	public partial class MainWindow : Window {
		public MainWindow() {
			InitializeComponent();
		}

		private void btnSample1_Click(object sender, RoutedEventArgs e) {
			winSample1 win = new winSample1();

			win.Show();
		}

		private void btnSample2_Click(object sender, RoutedEventArgs e) {
			winSample2 win = new winSample2();

			win.Show();
		}

		private void btnSample3_Click(object sender, RoutedEventArgs e) {
			winSample3 win = new winSample3();

			win.Show();
		}

		private void btnSample4_Click(object sender, RoutedEventArgs e) {
			winSample4 win = new winSample4();

			win.Show();
		}
	}
}
