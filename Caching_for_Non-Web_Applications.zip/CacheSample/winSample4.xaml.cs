﻿using System.Runtime.Caching;
using System.Windows;

namespace CacheSample {
	public partial class winSample4 : Window {
		public winSample4() {
			InitializeComponent();
		}

		private const string THE_KEY = "MyKey4";

		private void btnCreate_Click(object sender, RoutedEventArgs e) {
			MemoryCache.Default[THE_KEY] = "Value 4";
		}

		private void btnGet_Click(object sender, RoutedEventArgs e) {
			if (MemoryCache.Default[THE_KEY] != null) {
				MessageBox.Show(MemoryCache.Default[THE_KEY].ToString());
			}
			else {
				MessageBox.Show("Cache Item Does Not Exist");
			}
		}

		private void btnCount_Click(object sender, RoutedEventArgs e) {
			MessageBox.Show(MemoryCache.Default.GetCount().ToString());
		}
	}
}
