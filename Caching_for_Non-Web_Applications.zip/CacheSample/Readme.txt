﻿Add Reference to System.Runtime.Caching

Sample1 - Add - Absolute Expiration
        - Add - Sliding Expiration (CacheItemPolicy)
				- Remove
				-- NOTES:
					  -	Does NOT allow you to set a UpdateCallback
					  - Returns a true if key/value is added
						- Does not update an existing value

Sample2 - AddOrGetExisting - Absolute Expiration
        - AddOrGetExisting - Sliding Expiration (CacheItemPolicy)
				- AddOrGetExisting() Does NOT allow you to set a UpdateCallback
				- Remove
				-- NOTES:
				  	-	Does NOT allow you to set a UpdateCallback
					  - Returns a null if key/value is added, otherwise returns new cache value
						- Does not update an existing value

Sample3 - Set - Absolute Expiration
        - Set - Sliding Expiration (CacheItemPolicy)
        - Set() will add an entry, or update if Key already exists
				- Set() allows you to set a UpdateCallback - Called before item is removed from cache
				- Set() allows you to set a RemovedCallback - Called after item is removed from cache
				-- NOTES:
					  -- You can't set both a UpdateCallback and RemovedCallback at the same time
					  -- Set() does not return anything
						-- Set() either inserts or updates the existing value
												
Sample4 - Place value into cache
				- Read value from cache
				- Contains()
				- Count()