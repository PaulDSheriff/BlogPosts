﻿using System;
using System.Runtime.Caching;
using System.Windows;

namespace CacheSample {
	public partial class winSample3 : Window {
		public winSample3() {
			InitializeComponent();
		}

		private const string THE_KEY = "MyKey3";

		private void btnSet_Click(object sender, RoutedEventArgs e) {
			MemoryCache.Default.Set(THE_KEY, "Value 3", DateTimeOffset.Now.AddSeconds(5));
		}

		private void btnSetUsingPolicy_Click(object sender, RoutedEventArgs e) {
			CacheItemPolicy pol = new CacheItemPolicy();
			pol.SlidingExpiration = new TimeSpan(0, 0, 5);

			MemoryCache.Default.Set(THE_KEY, "Value 3", pol);
		}

		private void btnGet_Click(object sender, RoutedEventArgs e) {
			if (MemoryCache.Default.Get(THE_KEY) != null) {
				MessageBox.Show(MemoryCache.Default.Get(THE_KEY).ToString());
			}
			else {
				MessageBox.Show("Cache Item Does Not Exist");
			}
		}

		private void btnSetUsingPolicyUpdate_Click(object sender, RoutedEventArgs e) {
			CacheItemPolicy pol = new CacheItemPolicy();
			pol.AbsoluteExpiration = DateTimeOffset.Now.AddSeconds(3);
			pol.UpdateCallback = UpdateHandler;

			MemoryCache.Default.Set(THE_KEY, "Update 3", pol);

			MessageBox.Show("Bring up Output Window and watch for messages.");
		}

		private void UpdateHandler(CacheEntryUpdateArguments e) {
			Console.WriteLine("Update Handler: " + e.Key);
			Console.WriteLine("Update Handler: " + e.RemovedReason.ToString());

			// NOTE: You may update the UpdatedCacheItem property if you want to assign a new value
			//       You must also set a new cache item policy
			//e.UpdatedCacheItem = new CacheItem(e.Key, "My New Value");
			//CacheItemPolicy pol = new CacheItemPolicy();
			//pol.AbsoluteExpiration = DateTimeOffset.Now.AddSeconds(10);
			//pol.UpdateCallback = UpdateHandler;
			//e.UpdatedCacheItemPolicy = pol;
		}

		private void btnSetUsingPolicyRemoved_Click(object sender, RoutedEventArgs e) {
			CacheItemPolicy pol = new CacheItemPolicy();
			pol.SlidingExpiration = new TimeSpan(0, 0, 3);
			pol.RemovedCallback = RemovedHandler;

			MemoryCache.Default.Set(THE_KEY, "Remove 3", pol);

			MessageBox.Show("Bring up Output Window and watch for messages.");
		}

		private void RemovedHandler(CacheEntryRemovedArguments e) {
			Console.WriteLine("Removed Handler: " + e.RemovedReason.ToString());
			Console.WriteLine("Removed Handler: " + e.CacheItem.Key);
		}

		private void btnRemove_Click(object sender, RoutedEventArgs e) {
			MemoryCache.Default.Remove(THE_KEY);
		}
	}
}
