﻿using System;
using System.Runtime.Caching;
using System.Windows;

namespace CacheSample {
	public partial class winSample1 : Window {
		public winSample1() {
			InitializeComponent();
		}

		private const string THE_KEY = "MyKey1";

		private void btnAdd_Click(object sender, RoutedEventArgs e) {
			bool ret;

			ret = MemoryCache.Default.Add(THE_KEY, "Value 1", DateTimeOffset.Now.AddSeconds(5));
			if (ret) {
				MessageBox.Show("Key did NOT exist");
			}
			else {
				MessageBox.Show("The Key did already exist");
			}
		}

		private void btnAddUsingPolicy_Click(object sender, RoutedEventArgs e) {
			bool ret;

			CacheItemPolicy pol = new CacheItemPolicy();
			pol.SlidingExpiration = new TimeSpan(0, 0, 5);
			ret = MemoryCache.Default.Add(THE_KEY, "Value 1", pol);
			if (ret) {
				MessageBox.Show("Key did NOT exist");
			}
			else {
				MessageBox.Show("The Key did already exist");
			}
		}

		private void btnGet_Click(object sender, RoutedEventArgs e) {
			if (MemoryCache.Default.Get(THE_KEY) != null) {
				MessageBox.Show(MemoryCache.Default.Get(THE_KEY).ToString());
			}
			else {
				MessageBox.Show("Cache Item Does Not Exist");
			}
		}

		private void btnContains_Click(object sender, RoutedEventArgs e) {
			if (MemoryCache.Default.Contains(THE_KEY)) {
				MessageBox.Show("Cache Item Exists");
			}
			else {
				MessageBox.Show("Cache Item Does NOT Exist");
			}
		}

		private void btnRemove_Click(object sender, RoutedEventArgs e) {
			MemoryCache.Default.Remove(THE_KEY);
		}

		private void btnCount_Click(object sender, RoutedEventArgs e) {
			MessageBox.Show(MemoryCache.Default.GetCount().ToString());
		}
	}
}
