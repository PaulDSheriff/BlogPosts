﻿\app folder
-----------------------------------------
All the samples are located in this folder

Samples using 'template'
------------------------------------------------------------
\sample01 - Basic sample
\sample02 - Add otherwise

Sample using 'templateUrl'
------------------------------------------------------------
\sample03 - Basic sample
