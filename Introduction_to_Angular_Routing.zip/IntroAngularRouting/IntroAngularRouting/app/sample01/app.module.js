﻿(function () {
  'use strict';

  angular.module('app', ['ngRoute']);
  
  angular.module('app')
    .config(function ($routeProvider) {
      $routeProvider
      .when('/',
      {
        template: ''
      })
      .when('/page1',
      {
        template: '<p>This is some text for Page1</p>'
      })
      .when('/page2',
      {
        template: '<h2>Page 2</h2>'
      });
    });
})();