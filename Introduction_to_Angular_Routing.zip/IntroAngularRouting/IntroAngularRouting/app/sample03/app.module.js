﻿(function () {
  'use strict';

  // NOTE: the templateUrl: for the root ('/') must include a path
  //       unless you use 'controller' and 'controllerAs'
  angular.module('app', ['ngRoute']);

  angular.module('app')
    .config(function ($routeProvider) {
      $routeProvider
      .when('/',
      {
        template: ''
      })
      .when('/page1',
      {
        templateUrl: 'page1.template.html'
      })
      .when('/page2',
      {
        templateUrl: 'page2.template.html'
      })
      .when('/error',
      {
        templateUrl: 'badlink.template.html'
      })
      .otherwise('/error');
    });
})();