﻿using System.Collections.Generic;
using System.ComponentModel;
using LINQSamples.EntityClasses;
using LINQSamples.RepositoryClasses;

namespace Common.Library
{
  public class ViewModelBase : INotifyPropertyChanged
  {
    #region Properties
    private string _ResultText;
    private bool _UseQuerySyntax = true;
    private List<Product> _Products;
    
    public string ResultText
    {
      get { return _ResultText; }
      set {
        _ResultText = value;
        RaisePropertyChanged("ResultText");
      }
    }

    public bool UseQuerySyntax
    {
      get { return _UseQuerySyntax; }
      set {
        _UseQuerySyntax = value;
        RaisePropertyChanged("UseQuerySyntax");
      }
    }

    public List<Product> Products
    {
      get { return _Products; }
      set {
        _Products = value;
        RaisePropertyChanged("Products");
      }
    }
    #endregion

    #region LoadProductsCollection
    public List<Product> LoadProductsCollection()
    {
      Products = new ProductRepository().GetAll();

      return Products;
    }
    #endregion

    #region INotifyPropertyChanged
    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// </summary>
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// The event is only invoked if data binding is used
    /// </summary>
    /// <param name="propertyName">The property name that is changing</param>
    protected void RaisePropertyChanged(string propertyName)
    {
      // Grab a handler
      PropertyChangedEventHandler handler = this.PropertyChanged;
      // Only raise event if handler is connected
      if (handler != null) {
        PropertyChangedEventArgs args = new PropertyChangedEventArgs(propertyName);

        // Raise the PropertyChanged event.
        handler(this, args);
      }
    }
    #endregion
  }
}
