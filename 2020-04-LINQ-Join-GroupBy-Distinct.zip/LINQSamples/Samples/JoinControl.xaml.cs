﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class JoinControl : UserControl
  {
    public JoinControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (JoinViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly JoinViewModel _viewModel = null;

    private void JoinInner_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.InnerJoin();
    }

    private void LeftJoin_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.LeftOuterJoin();
    }

    private void RightJoin_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.SimulateRightOuterJoin();
    }
  }
}
