﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class DistinctControl : UserControl
  {
    public DistinctControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (DistinctViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly DistinctViewModel _viewModel = null;

    private void DistinctLoopingUsingControlBreak_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.DistinctLoopingUsingControlBreak();
    }

    private void DistinctLoopingUsingList_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.DistinctLoopingUsingList();
    }

    private void DistinctLoopingUsingGroupBy_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.DistinctUsingGroupByFirstOrDefault();
    }

    private void Distinct_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Distinct();
    }
  }
}
