﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class GroupByControl : UserControl
  {
    public GroupByControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (GroupByViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly GroupByViewModel _viewModel = null;

    private void GroupBy_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GroupBy();
    }

    private void GroupByWhere_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GroupByWhere();
    }

    private void Subquery_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GroupedSubquery();
    }
  }
}
