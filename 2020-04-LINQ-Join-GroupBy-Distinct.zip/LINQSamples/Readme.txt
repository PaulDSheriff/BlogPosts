﻿Join
-----------------------------------------------
Inner Join
Left Outer Join
Simulate Right Outer Join

Group By
-----------------------------------------------
GroupBy
GroupBy Where (Simulate Having clause)
Grouped Subquery

Distinct
-----------------------------------------------
Distinct using control-break logic
Distinct using Any() on a List<T>
Distinct using GroupBy() and FirstOrDefault()
Distinct