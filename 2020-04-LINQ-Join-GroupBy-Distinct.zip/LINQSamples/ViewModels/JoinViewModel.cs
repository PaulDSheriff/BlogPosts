﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.Library;
using LINQSamples.EntityClasses;
using LINQSamples.RepositoryClasses;

namespace LINQSamples.ViewModels
{
  public class JoinViewModel : ViewModelBase
  {
    #region InnerJoin
    /// <summary>
    /// Join a Sales Order Detail collection with Products
    /// </summary>
    public void InnerJoin()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(2048);

      // Load all Sales Data
      List<SalesOrderDetail> Sales = new SalesOrderDetailRepository().GetAll();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query syntax
        var query = (from prod in Products
                     join sale in Sales on prod.ProductID equals sale.ProductID
                     select new
                     {
                       prod.ProductID,
                       ProductName = prod.Name,
                       prod.ProductNumber,
                       sale.SalesOrderID,
                       sale.OrderQty,
                       sale.LineTotal
                     });

        foreach (var item in query) {
          sb.AppendLine($"Sales Order: {item.SalesOrderID}");
          sb.AppendLine($"  Product ID: {item.ProductID}");
          sb.AppendLine($"  Product Name: {item.ProductName}");
          sb.AppendLine($"  Product Number: {item.ProductNumber}");
          sb.AppendLine($"  Order Qty: {item.OrderQty}");
          sb.AppendLine($"  Total: {item.LineTotal:c}");
        }
      }
      else {
        // Method syntax
        var query = Products.Join(Sales, prod => prod.ProductID,
          sale => sale.ProductID,
          (prod, sale) => new
          {
            prod.ProductID,
            ProductName = prod.Name,
            prod.ProductNumber,
            sale.SalesOrderID,
            sale.OrderQty,
            sale.LineTotal
          });

        foreach (var item in query) {
          sb.AppendLine($"Sales Order: {item.SalesOrderID}");
          sb.AppendLine($"  Product ID: {item.ProductID}");
          sb.AppendLine($"  Product Name: {item.ProductName}");
          sb.AppendLine($"  Product Number: {item.ProductNumber}");
          sb.AppendLine($"  Order Qty: {item.OrderQty}");
          sb.AppendLine($"  Total: {item.LineTotal:c}");
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion

    #region LeftOuterJoin
    /// <summary>
    /// Perform a left join between Sales Order Detail and Products
    /// </summary>
    public void LeftOuterJoin()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(2048);

      // Load all Sales Data
      List<SalesOrderDetail> Sales =
        new SalesOrderDetailRepository().GetAll();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query syntax
        var query = (from prod in Products
                     join sale in Sales on prod.ProductID equals sale.ProductID into sales
                     from sale in sales.DefaultIfEmpty()
                     select new
                     {
                       prod.ProductID,
                       ProductName = prod.Name,
                       prod.ProductNumber,
                       sale?.SalesOrderID,
                       sale?.OrderQty,
                       sale?.LineTotal
                     });

        foreach (var item in query) {
          sb.AppendLine($"Sales Order: {item.SalesOrderID}");
          sb.AppendLine($"  Product ID: {item.ProductID}");
          sb.AppendLine($"  Product Name: {item.ProductName}");
          sb.AppendLine($"  Product Number: {item.ProductNumber}");
          sb.AppendLine($"  Order Qty: {item.OrderQty}");
          sb.AppendLine($"  Total: {item.LineTotal:c}");
        }
      }
      else {
        // Method syntax
        var query = Products.SelectMany(
          sale => Sales.Where(s => sale.ProductID == s.ProductID).DefaultIfEmpty(),
          (prod, sale) => new
          {
            prod.ProductID,
            ProductName = prod.Name,
            prod.ProductNumber,
            sale?.SalesOrderID,
            sale?.OrderQty,
            sale?.LineTotal
          });

        foreach (var item in query) {
          sb.AppendLine($"Sales Order: {item.SalesOrderID}");
          sb.AppendLine($"  Product ID: {item.ProductID}");
          sb.AppendLine($"  Product Name: {item.ProductName}");
          sb.AppendLine($"  Product Number: {item.ProductNumber}");
          sb.AppendLine($"  Order Qty: {item.OrderQty}");
          sb.AppendLine($"  Total: {item.LineTotal:c}");
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion

    #region SimulateRightOuterJoin
    /// <summary>
    /// LINQ does not support a right outer join
    /// Simply swap the tables from the Left Outer Join shown above and we get the behavior of a right outer join
    /// </summary>
    public void SimulateRightOuterJoin()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(2048);

      // Load all Sales Data
      List<SalesOrderDetail> Sales = new SalesOrderDetailRepository().GetAll();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query syntax
        var query = (from sale in Sales
                     join prod in Products on sale.ProductID equals prod.ProductID
                       into products
                     from prod in products.DefaultIfEmpty()
                     select new
                     {
                       prod?.ProductID,
                       ProductName = prod?.Name,
                       prod?.ProductNumber,
                       sale.SalesOrderID,
                       sale.OrderQty,
                       sale.LineTotal
                     });


        foreach (var item in query) {
          sb.AppendLine($"Sales Order: {item.SalesOrderID}");
          sb.AppendLine($"  Product ID: {item.ProductID}");
          sb.AppendLine($"  Product Name: {item.ProductName}");
          sb.AppendLine($"  Product Number: {item.ProductNumber}");
          sb.AppendLine($"  Order Qty: {item.OrderQty}");
          sb.AppendLine($"  Total: {item.LineTotal:c}");
        }
      }
      else {
        // Method syntax
        var query = Sales.SelectMany(
          sales => Products.Where(p => sales.ProductID == p.ProductID).DefaultIfEmpty(),
          (sale, prod) => new
          {
            prod?.ProductID,
            ProductName = prod?.Name,
            prod?.ProductNumber,
            sale.SalesOrderID,
            sale.OrderQty,
            sale.LineTotal
          });

        foreach (var item in query) {
          sb.AppendLine($"Sales Order: {item.SalesOrderID}");
          sb.AppendLine($"  Product ID: {item.ProductID}");
          sb.AppendLine($"  Product Name: {item.ProductName}");
          sb.AppendLine($"  Product Number: {item.ProductNumber}");
          sb.AppendLine($"  Order Qty: {item.OrderQty}");
          sb.AppendLine($"  Total: {item.LineTotal:c}");
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion
  }
}
