﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.Library;
using LINQSamples.EntityClasses;
using LINQSamples.RepositoryClasses;

namespace LINQSamples.ViewModels
{
  public class GroupByViewModel : ViewModelBase
  {
    #region GroupBy
    /// <summary>
    /// Group products by Size property
    /// </summary>
    public void GroupBy()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(2048);
      IEnumerable<IGrouping<string, Product>> grouped;

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query syntax
        grouped = (from prod in Products
                   group prod by prod.Size into sizes
                   select sizes);
      }
      else {
        // Method syntax
        grouped = Products.GroupBy(prod => prod.Size);
      }

      // Loop through each size
      foreach (var group in grouped) {
        sb.AppendLine($"Size: {group.Key}");
        // Loop through the products in each size
        foreach (var prod in group) {
          sb.Append($"  ProductID: {prod.ProductID}");
          sb.Append($"  Name: {prod.Name}");
          sb.AppendLine($"  Color: {prod.Color}");
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion

    #region GroupByWhere
    /// <summary>
    /// Group products by Size property and the group has more than 2 members
    /// This simulates a HAVING clause in SQL
    /// </summary>
    public void GroupByWhere()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(2048);
      IEnumerable<IGrouping<string, Product>> grouped;

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query syntax
        grouped = (from prod in Products
                   group prod by prod.Size into sizes
                   where sizes.Count() > 2
                   select sizes);
      }
      else {
        // Method syntax
        grouped = Products.GroupBy(prod => prod.Size)
                          .Where(sizes => sizes.Count() > 2)
                          .Select(sizes => sizes);
      }

      // Loop through each size
      foreach (var group in grouped) {
        sb.AppendLine($"Size: {group.Key}");

        // Loop through the products in each size
        foreach (var prod in group) {
          sb.Append($"  ProductID: {prod.ProductID}");
          sb.Append($"  Name: {prod.Name}");
          sb.AppendLine($"  Color: {prod.Color}");
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion

    #region GroupedSubquery
    /// <summary>
    /// Group Sales Orders by ID, then add Products into new Sales Order object using a subquery
    /// </summary>
    public void GroupedSubquery()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(2048);

      // Load all Sales Data
      List<SalesOrderDetail> Sales = new SalesOrderDetailRepository().GetAll();

      // Load all Product Data
      LoadProductsCollection();

      // Get all products for a sales order id
      if (UseQuerySyntax) {
        // Query syntax
        var grouped = (from sale in Sales
                       group sale by sale.SalesOrderID into sales
                       select new
                       {
                         SalesOrderID = sales.Key,
                         Products = (from prod in Products
                                     join sale in Sales on prod.ProductID equals sale.ProductID
                                     where sale.SalesOrderID == sales.Key
                                     select prod).ToList()
                       });

        // Loop through each size
        foreach (var group in grouped) {
          sb.AppendLine($"Sales ID: {group.SalesOrderID}");

          // Loop through the products in each size
          foreach (var prod in group.Products) {
            sb.Append($"  ProductID: {prod.ProductID}");
            sb.Append($"  Name: {prod.Name}");
            sb.AppendLine($"  Color: {prod.Color}");
          }
        }
      }
      else {
        // Method syntax
        var grouped = Sales.GroupBy(sale => sale.SalesOrderID)
          .Select(sales => new
          {
            SalesOrderID = sales.Key,
            Products = Products.Join(sales,
                                      prod => prod.ProductID,
                                      sale => sale.ProductID,
                                      (prod, sale) => prod)
          });

        // Loop through each size
        foreach (var group in grouped) {
          sb.AppendLine($"Sales ID: {group.SalesOrderID}");
          // Loop through the products in each size
          foreach (var prod in group.Products) {
            sb.Append($"  ProductID: {prod.ProductID}");
            sb.Append($"  Name: {prod.Name}");
            sb.AppendLine($"  Color: {prod.Color}");
          }
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion
  }
}
