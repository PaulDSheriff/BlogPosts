﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.Library;
using LINQSamples.EntityClasses;

namespace LINQSamples.ViewModels
{
  public class DistinctViewModel : ViewModelBase
  {
    #region DisplayDistinctColors Method
    protected void DisplayDistinctColors(List<string> colors)
    {
      StringBuilder sb = new StringBuilder(1024);

      // Build string of Distinct Colors
      foreach (var color in colors) {
        sb.AppendLine($"Color: {color}");
      }
      sb.AppendLine($"Total Colors: {colors.Count}");

      ResultText = sb.ToString();
    }
    #endregion

    #region DistinctLoopingUsingControlBreak
    /// <summary>
    /// Put distinct product colors into another collection using looping
    /// </summary>
    public void DistinctLoopingUsingControlBreak()
    {
      System.Diagnostics.Debugger.Break();

      List<string> colors = new List<string>();
      // Assign a color that would NEVER appear in the list
      string lastColor = "zzz";

      // Load all Product Data
      LoadProductsCollection();

      // Loop through all products ordered by color name
      foreach (Product prod in Products.OrderBy(p => p.Color)) {
        // Check to see if the color matches the last color
        if (prod.Color != lastColor) {
          // Add color to colors collection if unique
          colors.Add(prod.Color);
          // Move this color into the lastColor variable
          lastColor = prod.Color;
        }
      }

      // Display Distinct Colors
      DisplayDistinctColors(colors);

      Products = null;
    }
    #endregion

    #region DistinctLoopingUsingList
    /// <summary>
    /// Put distinct product colors into another collection using looping
    /// </summary>
    public void DistinctLoopingUsingList()
    {
      System.Diagnostics.Debugger.Break();

      List<string> colors = new List<string>();

      // Load all Product Data
      LoadProductsCollection();

      // Loop through all products
      foreach (Product prod in Products) {
        // Check to see if the colors collection has the current color
        if (!colors.Any(c => c == prod.Color)) {
          // Add unique color to colors collection
          colors.Add(prod.Color);
        }
      }

      // Display Distinct Colors
      DisplayDistinctColors(colors);

      Products = null;
    }
    #endregion

    #region DistinctUsingGroupByFirstOrDefault
    /// <summary>
    /// Put distinct product colors into another collection using LINQ
    /// </summary>
    public void DistinctUsingGroupByFirstOrDefault()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(1024);
      List<string> grouped;

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        grouped = (from prod in Products
                   group prod by prod.Color into colors
                   select colors.FirstOrDefault().Color).ToList();
      }
      else {
        // Method Syntax
        grouped = Products.GroupBy(p => p.Color)
                         .Select(prod => prod.FirstOrDefault().Color).ToList();
      }

      // Display Distinct Colors
      DisplayDistinctColors(grouped);

      Products = null;
    }
    #endregion

    #region Distinct
    /// <summary>
    /// Put distinct product colors into another collection using LINQ
    /// </summary>
    public void Distinct()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(1024);
      List<string> colors;

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        colors = (from prod in Products
                  select prod.Color).Distinct().ToList();
      }
      else {
        // Method Syntax
        colors = Products.Select(prod => prod.Color)
                          .Distinct().ToList();
      }

      // Display Distinct Colors
      DisplayDistinctColors(colors);

      Products = null;
    }
    #endregion
  }
}
