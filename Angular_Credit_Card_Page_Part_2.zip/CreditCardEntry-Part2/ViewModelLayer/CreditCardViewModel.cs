﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Globalization;
using System.Linq;

namespace ViewModelLayer
{
    public class CreditCardViewModel
    {
    public CreditCardViewModel() {
      IsValid = true;
      Messages = new List<DbEntityValidationResult>();

      DefaultLanguage = string.Empty;
      Language = string.Empty;

      Entity = new CreditCard();

      CardTypes = new List<CreditCardType>();
      Months = new List<MonthInfo>();
      Years = new List<int>();
    }

    public bool IsValid { get; set; }
    public List<DbEntityValidationResult> Messages { get; set; }

    public string DefaultLanguage { get; set; }
    public string Language { get; set; }

    public CreditCard Entity { get; set; }

    public List<CreditCardType> CardTypes { get; set; }
    public List<MonthInfo> Months { get; set; }
    public List<int> Years { get; set; }

    public void LoadCardTypes() {
      PTC db = new PTC();

      CardTypes = db.CreditCardTypes
                  .Where(c => (c.IsActive))
                  .OrderBy(c => c.CardType).ToList();
    }

    public void LoadMonths() {
      string[] monthNames = null;

      try {
        // Try to get month names
        monthNames = (new CultureInfo(Language))
                        .DateTimeFormat.MonthNames;
      }
      catch (CultureNotFoundException) {
        // Default to a known language
        monthNames = (new System.Globalization
                        .CultureInfo(DefaultLanguage))
                          .DateTimeFormat.MonthNames;
      }

      // Create Months Array
      for (int index = 0; index < monthNames.Length; index++) {
        // NOTE: Month array is 13 entries long
        if (!string.IsNullOrEmpty(monthNames[index])) {
          Months.Add(new MonthInfo(Convert.ToInt16(index + 1),
                                   monthNames[index]));
        }
      }

      if (Entity.ExpMonth == 0) {
        // Figure out which month to select
        // Make it next month by default
        Entity.ExpMonth = Convert.ToInt16(DateTime.Now.Month + 1);
        Entity.ExpYear = Convert.ToInt16(DateTime.Now.Year);
        // If past December, then make it January of the next year
        if (Entity.ExpMonth > 12) {
          Entity.ExpMonth = 1;
          Entity.ExpYear += 1;
        }
      }
    }

    public void LoadYears(int yearsInFuture = 20) {
      List<int> ret = new List<int>();

      Years = new List<int>();
      for (int i = DateTime.Now.Year;
           i <= (DateTime.Now.Year + yearsInFuture); i++) {
        Years.Add(i);
      }
    }
  }
}
