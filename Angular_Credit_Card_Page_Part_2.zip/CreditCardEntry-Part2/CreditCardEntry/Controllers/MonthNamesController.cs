﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ViewModelLayer;

namespace CreditCardEntry.Controllers
{
  public class MonthNamesController : ApiController
  {
    public IHttpActionResult Get(string id) {
      IHttpActionResult ret;
      CreditCardViewModel vm = new CreditCardViewModel();

      // Set default language
      vm.DefaultLanguage =
        ConfigurationManager.AppSettings["DefaultLanguage"];

      // Set the language passed in
      vm.Language = (string.IsNullOrEmpty(id) ?
                     vm.DefaultLanguage : id);

      vm.LoadMonths();
      if (vm.Months.Count() > 0) {
        ret = Ok(vm.Months);
      }
      else {
        ret = NotFound();
      }

      return ret;
    }

  }
}