namespace DataLayer
{
  using System;
  using System.Data.Entity;
  using System.ComponentModel.DataAnnotations.Schema;
  using System.Linq;

  public partial class PTC : DbContext
  {
    public PTC()
        : base("name=PTC") {
    }

    public virtual DbSet<CreditCard> CreditCards { get; set; }
    public virtual DbSet<CreditCardType> CreditCardTypes { get; set; }

    protected override void OnModelCreating(DbModelBuilder modelBuilder) {
      modelBuilder.Entity<CreditCard>()
          .Property(e => e.CardType)
          .IsUnicode(false);

      modelBuilder.Entity<CreditCard>()
          .Property(e => e.NameOnCard)
          .IsUnicode(false);

      modelBuilder.Entity<CreditCard>()
          .Property(e => e.CardNumber)
          .IsUnicode(false);

      modelBuilder.Entity<CreditCard>()
          .Property(e => e.SecurityCode)
          .IsUnicode(false);

      modelBuilder.Entity<CreditCard>()
          .Property(e => e.BillingPostalCode)
          .IsUnicode(false);

      modelBuilder.Entity<CreditCardType>()
          .Property(e => e.CardType)
          .IsUnicode(false);
    }
  }
}
