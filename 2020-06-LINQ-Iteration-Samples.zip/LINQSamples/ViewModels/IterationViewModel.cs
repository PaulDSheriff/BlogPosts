﻿using System.Collections.Generic;
using System.Linq;
using Common.Library;
using LINQSamples.EntityClasses;
using LINQSamples.RepositoryClasses;

namespace LINQSamples.ViewModels
{
  public class IterationViewModel : ViewModelBase
  {
    #region ForEach Method
    /// <summary>
    /// ForEach allows you to iterate over a collection
    /// In this sample, assign the Length of the Name property to a property called NameLength
    /// When using the Query syntax, assign the result to a temporary variable.
    /// </summary>
    public void ForEach()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    let tmp = prod.NameLength = prod.Name.Length
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products.ForEach(prod => prod.NameLength = prod.Name.Length);
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region ForEachCallingMethod Method
    /// <summary>
    /// You can call any method within a ForEach
    /// This method passes in each Product object into the SalesForProduct() method
    /// In the SalesForProduct() method, the total sales for each Product is calculated
    /// The total is placed into each Product objects' ResultText property
    /// </summary>
    public void ForEachCallingMethod()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    let tmp = prod.TotalSales = SalesForProduct(prod)
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products.ForEach(prod => prod.TotalSales = SalesForProduct(prod));
      }

      ResultText = $"Total Products: {Products.Count}";
    }

    private decimal SalesForProduct(Product prod)
    {
      List<SalesOrderDetail> sales;

      // Get All Sales Data
      sales = new SalesOrderDetailRepository().GetAll();

      return sales.Where(s => s.ProductID == prod.ProductID)
                  .Sum(s => s.LineTotal);
    }
    #endregion

    #region Skip Method
    /// <summary>
    /// Use Skip() to move past a specified number of items in a collection
    /// </summary>
    public void Skip()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    select prod).Skip(20).ToList();
      }
      else {
        // Method Syntax
        Products = Products.Skip(20).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region SkipWhile Method
    /// <summary>
    /// Use SkipWhile() to move past a specified number of items in the collection based on a condition
    /// </summary>
    public void SkipWhile()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    orderby prod.Name
                    select prod).SkipWhile(prod => prod.Name.StartsWith("A")).ToList();
      }
      else {
        // Method Syntax
        Products = Products.OrderBy(prod => prod.Name).SkipWhile(prod => prod.Name.StartsWith("A")).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Take Method
    /// <summary>
    /// Use Take() to select a specified number of items in a collection
    /// </summary>
    public void Take()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    select prod).Take(5).ToList();
      }
      else {
        // Method Syntax
        Products = Products.Take(5).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region TakeWhile Method
    /// <summary>
    /// Use TakeWhile() to select a specified number of items in a collection based on a condition
    /// </summary>
    public void TakeWhile()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    orderby prod.Name
                    select prod).TakeWhile(prod => prod.Name.StartsWith("A")).ToList();
      }
      else {
        // Method Syntax
        Products = Products.OrderBy(prod => prod.Name).TakeWhile(prod => prod.Name.StartsWith("A")).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion
  }
}
