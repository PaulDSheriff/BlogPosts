﻿Iteration
-----------------------------------------------
ForEach
Skip
SkipWhile
Take
TakeWhile



Resources
----------------------------------------------------
https://docs.microsoft.com/en-us/dotnet/csharp/linq/