import { Category } from "./category";

export const CATEGORIES_MOCK: Category[] = [
  {
    categoryId: 1,
    categoryName: "Services"
  },
  {
    categoryId: 2,
    categoryName: "Training"
  },
  {
    categoryId: 3,
    categoryName: "Information"
  }  
];
