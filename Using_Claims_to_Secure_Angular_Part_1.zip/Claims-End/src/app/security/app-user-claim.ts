export class AppUserClaim  {
  claimId: number = 0;
  userId: number = 0;
  claimType: string = "";
  claimValue: string = "";
}
