﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using UploadSample.Models;

namespace UploadSample.Controllers
{
  public class HomeController : Controller
  {
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
      _logger = logger;
      FileNameOnServer = string.Empty;
      FileContentLength = 0;
      FileContentType = string.Empty;
    }

    public string FileNameOnServer { get; set; }
    public long FileContentLength { get; set; }
    public string FileContentType { get; set; }

    public IActionResult Index()
    {
      return View();
    }

    public IActionResult Sample1()
    {
      return View();
    }

    public IActionResult Sample2()
    {
      return View();
    }

    public IActionResult Sample3()
    {
      return View();
    }

    public IActionResult Sample4()
    {
      return View();
    }

    public IActionResult Sample5()
    {
      return View();
    }

    [HttpPost]
    public async Task<IActionResult> UploadFile(IFormFile fileToUpload)
    {
      if (fileToUpload != null && fileToUpload.Length > 0) {
        // User selected a file
        // Get a temporary path
        FileNameOnServer = Path.GetTempPath();
        // Add the file name to the path
        FileNameOnServer += fileToUpload.FileName;
        // Get the file's length
        FileContentLength = fileToUpload.Length;
        // Get the file's type
        FileContentType = fileToUpload.ContentType;

        // Create a stream to write the file to
        using var stream = System.IO.File.Create(FileNameOnServer);
        // Upload file and copy to the stream
        await fileToUpload.CopyToAsync(stream);

        // Return a success page
        return View("UploadComplete", this);
      }
      else {
        // User did not select a file
        return View("Index");
      }
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
      return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
  }
}