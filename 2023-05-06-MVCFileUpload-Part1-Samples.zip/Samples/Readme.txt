Install Font Awesome
Right-click on the Project 
Select Add | Client-Side Library... from the menu
In the pop-up form, choose 'cdnjs' as Provider
Type 'font-awesome' in the Library input text box, press Enter
Click 'Install'
Open the Shared\_Layout.cshtml page
Add the stylesheet in the <head>
 <link rel="stylesheet" href="~/lib/font-awesome/css/all.css" />