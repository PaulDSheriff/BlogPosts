﻿using System.Linq;
using Common.Library;
using LINQSamples.EntityClasses;

namespace LINQSamples.ViewModels
{
  public class SearchViewModel : ViewModelBase
  {
    #region Where
    /// <summary>
    /// Filter products using where. If the data is not found, an empty list is returned
    /// </summary>
    public void WhereClause()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    where prod.Name.StartsWith("L")
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products = Products.Where(prod => prod.Name.StartsWith("L")).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Find
    /// <summary>
    /// Locate a specific product using the Find() method
    /// NOTE: Find() only works on List<T> not IEnumerable<T>
    /// </summary>
    public void Find()
    {
      System.Diagnostics.Debugger.Break();

      Product value;

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod).ToList()
                .Find(prod => prod.Name.Contains("a"));
      }
      else {
        // Method Syntax
        value = Products.Find(prod => prod.Name.Contains("a"));
      }

      if (value == null) {
        ResultText = "Not Found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion

    #region First
    /// <summary>
    /// Locate a specific product using First(). First() searches forward in the list.
    /// NOTE: First() throws an exception if the result does not produce any values
    /// </summary>
    public void First()
    {
      System.Diagnostics.Debugger.Break();

      Product value = null;

      // Load all Product Data
      LoadProductsCollection();

      try {
        if (UseQuerySyntax) {
          // Query Syntax
          value = (from prod in Products
                   select prod)
                    .First(prod => prod.Color == "Red");
        }
        else {
          // Method Syntax
          value = Products.First(prod => prod.Color == "Red");
        }

        ResultText = $"Found: {value.Name}";
      }
      catch {
        ResultText = "Not Found";
      }

      Products = null;
    }
    #endregion

    #region FirstOrDefault
    /// <summary>
    /// Locate a specific product using FirstOrDefault(). FirstOrDefault() searches forward in the list.
    /// NOTE: FirstOrDefault() returns a null if no value is found
    /// </summary>
    public void FirstOrDefault()
    {
      System.Diagnostics.Debugger.Break();

      Product value;

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod)
                  .FirstOrDefault(prod => prod.Color == "Red");
      }
      else {
        // Method Syntax
        value = Products.FirstOrDefault(prod => prod.Color == "Red");
      }

      if (value == null) {
        ResultText = "Not Found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion

    #region Last
    /// <summary>
    /// Locate a specific product using Last(). Last() searches from the end of the list backwards.
    /// NOTE: Last returns the last value from a collection, or throws an exception if no value is found
    /// </summary>
    public void Last()
    {
      System.Diagnostics.Debugger.Break();

      Product value = null;

      // Load all Product Data
      LoadProductsCollection();

      try {
        if (UseQuerySyntax) {
          // Query Syntax
          value = (from prod in Products
                   select prod).Last(prod => prod.Color == "Red");
        }
        else {
          // Method Syntax
          value = Products.Last(prod => prod.Color == "Red");
        }

        ResultText = $"Found: {value.Name}";
      }
      catch {
        ResultText = "Not Found";
      }

      Products = null;
    }
    #endregion

    #region LastOrDefault
    /// <summary>
    /// Locate a specific product using LastOrDefault(). LastOrDefault() searches from the end of the list backwards.
    /// NOTE: LastOrDefault returns the last value in a collection, or null if no values are found
    /// </summary>
    public void LastOrDefault()
    {
      System.Diagnostics.Debugger.Break();

      Product value;

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod)
                  .LastOrDefault(prod => prod.Color == "Red");
      }
      else {
        // Method Syntax
        value = Products.LastOrDefault(prod => prod.Color == "Red");
      }

      if (value == null) {
        ResultText = "Not Found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion

    #region Single
    /// <summary>
    /// Locate a specific product using Single()
    /// NOTE: Single() expects only a single element to be found in the collection, otherwise an exception is thrown
    /// </summary>
    public void Single()
    {
      System.Diagnostics.Debugger.Break();

      Product value = null;

      // Load all Product Data
      LoadProductsCollection();

      try {
        if (UseQuerySyntax) {
          // Query Syntax
          value = (from prod in Products
                   select prod)
                    .Single(prod => prod.ProductID == 706);
        }
        else {
          // Method Syntax
          value = Products.Single(prod => prod.ProductID == 706);
        }

        ResultText = $"Found: {value.Name}";
      }
      catch {
        ResultText = "Not Found, or multiple elements found";
      }

      Products = null;
    }
    #endregion

    #region SingleOrDefault
    /// <summary>
    /// Locate a specific product using SingleOrDefault()
    /// NOTE: SingleOrDefault() expects only a single element to be found in the collection, otherwise an exception is thrown
    /// </summary>
    public void SingleOrDefault()
    {
      System.Diagnostics.Debugger.Break();

      Product value = null;

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod)
                  .SingleOrDefault(prod => prod.ProductID == 706);
      }
      else {
        // Method Syntax
        value = Products.SingleOrDefault(prod => prod.ProductID == 706);
      }

      if (value == null) {
        ResultText = "Not Found, or multiple elements found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion
  }
}
