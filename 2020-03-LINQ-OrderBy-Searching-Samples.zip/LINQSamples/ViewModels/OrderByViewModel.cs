﻿using System.Linq;
using Common.Library;

namespace LINQSamples.ViewModels
{
  public class OrderByViewModel : ViewModelBase
  {
    #region OrderBy
    /// <summary>
    /// Order products by Name
    /// </summary>
    public void OrderBy()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    orderby prod.Name
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products = Products.OrderBy(prod => prod.Name).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region OrderByDescending Method
    /// <summary>
    /// Order products by name in descending order
    /// </summary>
    public void OrderByDescending()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    orderby prod.Name descending
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products = Products.OrderByDescending(prod => prod.Name).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region OrderByTwoFields Method
    /// <summary>
    /// Order products by Color, then Name
    /// </summary>
    public void OrderByTwoFields()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    orderby prod.Color descending, prod.Name
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products = Products.OrderByDescending(prod => prod.Color)
                            .ThenBy(prod => prod.Name).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion
  }
}
