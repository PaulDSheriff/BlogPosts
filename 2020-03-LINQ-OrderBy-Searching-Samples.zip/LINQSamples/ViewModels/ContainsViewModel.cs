﻿using System.Collections.Generic;
using System.Linq;
using Common.Library;
using LINQSamples.EntityClasses;

namespace LINQSamples.ViewModels
{
  public class ContainsViewModel : ViewModelBase
  {
    #region Contains
    /// <summary>
    /// Use Contains to see if a collection contains a specific value
    /// </summary>
    public void Contains()
    {
      System.Diagnostics.Debugger.Break();

      bool value;
      List<int> numbers = new List<int> { 1, 2, 3, 4, 5 };

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from num in numbers
                 select num).Contains(3);
      }
      else {
        // Method Syntax
        value = numbers.Contains(3);
      }

      ResultText = $"Is the number in collection? {value}";
    }
    #endregion

    #region Any
    /// <summary>
    /// Use Any() to see if at least one item in a collection meets a specified condition
    /// </summary>
    public void Any()
    {
      System.Diagnostics.Debugger.Break();

      bool value;

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod).Any(prod => prod.Name.Contains("z"));
      }
      else {
        // Method Syntax
        value = Products.Any(prod => prod.Name.Contains("z"));
      }

      ResultText = $"Do any Name properties contain an 'z'? {value}";
    }
    #endregion

    #region All
    /// <summary>
    /// Use All() to see if all items in a collection meet a specified condition
    /// </summary>
    public void All()
    {
      System.Diagnostics.Debugger.Break();

      bool value;

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod).All(prod => prod.Name.Contains(" "));
      }
      else {
        // Method Syntax
        value = Products.All(prod => prod.Name.Contains(" "));
      }

      ResultText = $"Do all Name properties contain a space? {value}";
    }
    #endregion

    #region ContainsUsingComparer
    /// <summary>
    /// Use Contains to see if a collection contains a specific object
    /// Use an EqualityComparer class to perform the comparison
    /// </summary>
    public void ContainsUsingComparer()
    {
      System.Diagnostics.Debugger.Break();

      bool value;
      ProductIdComparer pc = new ProductIdComparer();
      Product prodToFind = new Product { ProductID = 744 };

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod).Contains(prodToFind, pc);
      }
      else {
        // Method Syntax
        value = Products.Contains(prodToFind, pc);
      }

      ResultText = $"Product ID: 706 is in Products Collection = {value}";
    }
    #endregion
  }
}
