﻿using System.Collections.Generic;

namespace LINQSamples.EntityClasses
{
  public class ProductIdComparer : EqualityComparer<Product>
  {
    public override bool Equals(Product fromList, Product toFind)
    {
      return (fromList.ProductID == toFind.ProductID);
    }

    public override int GetHashCode(Product obj)
    {
      return obj.ProductID.GetHashCode();
    }
  }
}
