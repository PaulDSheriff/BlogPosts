﻿Order By
-----------------------------------------------
OrderBy
OrderBy (Desc)
OrderBy Two Fields

Searching
-----------------------------------------------
Where
Find
First
FirstOrDefault
Last
LastOrDefault
Single
SingleOrDefault

Contains
-----------------------------------------------
All
Any
Contains
