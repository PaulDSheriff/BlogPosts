﻿'use strict';

$(document).ready(function () {
  // Trigger home page
  window.location.replace(window.location.href + "#home");

  // Respond to changes in hash
  window.onhashchange = function () {
    spaController.changePage("contentarea", window.location.hash);
  }
});