﻿'use strict';

var spaController = (function () {
  // ************************************
  // Private Functions
  // ************************************
  function loadPage(contentArea, pageName) {
    // Use Ajax to retrieve partial page
    $.ajax({
      url: pageName + ".html",
      dataType: "html",
      success: function (html) {
        $(contentArea).html(html);
      },
      error: function (error) {
        console.log(error);
      }
    });
  }
  // ************************************
  // Public Functions
  // ************************************
  return {
    loadPage: function (contentArea, pageName) {
      loadPage(contentArea, pageName);
    }
  };
})();