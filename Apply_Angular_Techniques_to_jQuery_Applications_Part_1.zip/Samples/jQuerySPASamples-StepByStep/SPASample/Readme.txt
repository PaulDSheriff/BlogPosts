﻿Add jQuery
Add Bootstrap
Add Default.html


Samples
-------------------------------------------------------------------------------
Sample 1 - Simple example of loadig partial HTML into one page
Sample 2 - Create functions
         - Fix the back button
Sample 3 - Add .css and .js file to partial page
Sample 4 - Move loadPage() function into spa-common.js file
Sample 5 - Add document title
Sample 6 - Move home, about and contact pages to \common folder
         - Add data-page-path attribute
Sample 7 - Fix up the bootstrap menu after pressing back button
Sample 8 - Move all JavaScript/jQuery to .js files