﻿'use strict';

function testing() {
  alert("Hello from About Page");
}