﻿'use strict';

var spaController = (function () {
  // ************************************
  // Private Functions
  // ************************************
  function loadPage(contentArea, pageName) {
    // Use Ajax to retrieve partial page
    $.ajax({
      url: pageName + ".html",
      dataType: "html",
      success: function (html) {
        $(contentArea).html(html);
      },
      error: function (error) {
        console.log(error);
      }
    });
  }

  function resetMenu(hashValue) {
    // Set focus to menu that matches current page
    $("a[href='" + hashValue + "']").focus();
    // Remove outline around anchor when setting focus
    $("a[href='" + hashValue + "']").css("outline", "0");
  }

  function changePage(contentArea, hashValue) {
    // Get path for partial page
    var path = $("a[href='" + hashValue + "']").data("page-path") || "";
    // Remove # to create the page file name
    var pageName = hashValue.substr(1);
    // Load the partial HTML page
    loadPage(contentArea, path + pageName);
    // Set document title
    window.document.title = $("a[href='" + hashValue + "']").attr("title");

    // Reset menu focus
    resetMenu(hashValue);
  }
  // ************************************
  // Public Functions
  // ************************************
return {
  loadPage: function (contentArea, pageName) {
    loadPage(contentArea, pageName);
  },
  changePage: function (contentArea, hashValue) {
    changePage(contentArea, hashValue);
  }
};
})();