﻿'use strict';

$(document).ready(function () {
  var content = $("[data-spa-start]")[0].nodeName;
  var start = $(content).data('spa-start');
  // Trigger home page
  window.location.replace(window.location.href + start);

  // Respond to changes in hash
  window.onhashchange = function () {
    spaController.changePage(content, window.location.hash);
  }
});