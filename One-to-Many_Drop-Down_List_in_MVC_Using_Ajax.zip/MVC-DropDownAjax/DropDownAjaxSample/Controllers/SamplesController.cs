﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace DropDownAjaxSample.Controllers
{
  public class SamplesController : Controller
  {
    public ActionResult Sample01()
    {
      ProductViewModel vm = new ProductViewModel();

      vm.LoadCategories();

      vm.ProductCategories.Insert(0,
        new ProductCategory { ProductCategoryID = -1, Name = "<-- Select a Category -->" });

      return View(vm);
    }

    [HttpPost]
    public JsonResult GetProductsByCategory(string id)
    {
      ProductViewModel vm = new ProductViewModel();
      List<Product> ret;

      ret = vm.GetProductsByCategory(Convert.ToInt32(id));
      if (ret.Count == 0)
      {
        ret.Add(new Product { ProductID = -1, Name = "No Products for Category" });
      }

      return Json(ret);
    }
  }
}