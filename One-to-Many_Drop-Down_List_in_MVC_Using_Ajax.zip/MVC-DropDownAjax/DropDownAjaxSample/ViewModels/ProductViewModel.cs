﻿using System.Collections.Generic;
using System.Linq;

namespace DropDownAjaxSample
{
public class ProductViewModel
{
  public List<ProductCategory> ProductCategories { get; set; }
  public List<Product> Products { get; set; }

  public virtual List<ProductCategory> LoadCategories()
  {
    ProductCategories = new List<ProductCategory>();

    using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext())
    {
      ProductCategories = db.ProductCategories.OrderBy(p => p.Name).ToList();
    }

    return ProductCategories;
  }

  public virtual List<Product> GetProductsByCategory(int productCategoryId)
  {
    Products = new List<Product>();

    using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext())
    {
      Products = db.Products
        .Where(p => p.ProductCategoryID == productCategoryId)
        .OrderBy(p => p.Name).ToList();
    }

    return Products;
  }
}
}
