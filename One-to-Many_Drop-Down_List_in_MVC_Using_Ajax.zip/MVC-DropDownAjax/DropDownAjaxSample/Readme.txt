﻿This sample uses the AdventureWorksLT database included as a sample in SQL Server

Sample01
-------------------
Load the Categories drop-down list using MVC
In the onchange of the Categories drop-down list call a JavaScript function.
  This function gets the ProductCategoryID from the Categories drop-down
  It uses an ajax call to call a controller method and passes the category id to that method.
  This method retrieves the data from EF and returns it to the ajax call
  The products drop-down list is then populated from this list of data


Resource:
https://www.c-sharpcorner.com/article/ajax-call-for-dropdown-lists-in-mvc/