﻿using System.Data.Entity;

namespace DropDownAjaxSample
{
  public partial class AdventureWorksLTDbContext : DbContext
  {
    public AdventureWorksLTDbContext() : base("name=AdventureWorksLT")
    {
    }

    public virtual DbSet<Product> Products { get; set; }
    public virtual DbSet<ProductCategory> ProductCategories { get; set; }
  }
}
