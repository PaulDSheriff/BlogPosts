﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyClasses;

namespace MyClassesTest {
	[TestClass]
	public class AssertClassTest {
		[TestMethod]
		public void AreEqualTest() {
			int x = 1;
			int y = 1;

			Assert.AreEqual(x, y);
		}

		[TestMethod]
		public void AreNotEqualTest() {
			int x = 1;
			int y = 2;

			Assert.AreNotEqual(x, y);
		}

		[TestMethod]
		public void AreSameTest() {
			FileProcess x = new FileProcess();
			FileProcess y = x;

			Assert.AreSame(x, y);
		}

		[TestMethod]
		public void AreNotSameTest() {
			FileProcess x = new FileProcess();
			FileProcess y = new FileProcess();

			Assert.AreNotSame(x, y);
		}

		[TestMethod]
		public void IsInstanceOfTypeTest() {
			PersonManager mgr = new PersonManager();
			Person per;

			per = mgr.CreatePerson("Paul", "Sheriff", true);

			Assert.IsInstanceOfType(per, typeof(Supervisor));
		}

		[TestMethod]
		public void IsNullTest() {
			PersonManager mgr = new PersonManager();
			Person per;

			per = mgr.CreatePerson("", "Sheriff", true);

			Assert.IsNull(per);
		}
	}
}
