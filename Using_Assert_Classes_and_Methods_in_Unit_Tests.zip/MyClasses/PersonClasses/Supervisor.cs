﻿using System;
using System.Collections.Generic;

namespace MyClasses {
	public class Supervisor : Person {
		public List<Employee> Employees { get; set; }
	}
}
