﻿using System.Windows;
using System.Reflection;
using System;

namespace EntityCollectionsReflection
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region Window_Loaded Event Procedure
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      DisplayRowsRead();
    }
    #endregion

    #region DisplayRowsRead Method
    private void DisplayRowsRead()
    {
      if (lstData.Items.Count > 0)
        txtRowsRead.Text = lstData.Items.Count.ToString("###,###");
      else
        txtRowsRead.Text = "0";
    }
    #endregion

    private void btnHardCoded_Click(object sender, RoutedEventArgs e)
    {
      ProductHardCodedManager mgr = new ProductHardCodedManager();

      lstData.View = PDSAListView.CreateGridViewColumns(typeof(Product));
      lstData.DataContext = mgr.GetProducts();
      DisplayRowsRead();
    }

    private void btnDataTable_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();

      lstData.View = PDSAListView.CreateGridViewColumns(typeof(Product));
      lstData.DataContext = mgr.GetProductsDataTable();
      DisplayRowsRead();
    }

    private void btnDataReader_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();

      lstData.View = PDSAListView.CreateGridViewColumns(typeof(Product));
      lstData.DataContext = mgr.GetProductsDataReader();
      DisplayRowsRead();
    }

    private void btnSetProperty1_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();
      typeof(Product).InvokeMember("ProductName",
        BindingFlags.SetProperty,
          Type.DefaultBinder, entity,
           new Object[] { "A New Product" });

      MessageBox.Show(entity.ProductName);
    }

    private void btnSetProperty2_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();

      typeof(Product).GetProperty("ProductName").
        SetValue(entity, "A New Product", null);

      MessageBox.Show(entity.ProductName);
    }
  }
}
