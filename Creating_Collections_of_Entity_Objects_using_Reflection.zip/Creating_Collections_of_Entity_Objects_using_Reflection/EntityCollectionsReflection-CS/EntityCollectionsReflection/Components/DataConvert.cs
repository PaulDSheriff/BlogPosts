﻿using System;

namespace EntityCollectionsReflection
{
  public class DataConvert
  {
    public static T ConvertTo<T>(object value, object defaultValue) where T : struct
    {
      if (value == DBNull.Value)
        return (T)defaultValue;
      else
        return (T)value;
    }
  }
}
