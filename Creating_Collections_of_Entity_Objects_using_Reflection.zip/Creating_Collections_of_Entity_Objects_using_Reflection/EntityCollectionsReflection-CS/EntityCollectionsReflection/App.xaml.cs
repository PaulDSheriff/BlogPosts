﻿using System.Windows;

namespace EntityCollectionsReflection
{
  /// <summary>
  /// Interaction logic for App.xaml
  /// </summary>
  public partial class App : Application
  {
  }
}
