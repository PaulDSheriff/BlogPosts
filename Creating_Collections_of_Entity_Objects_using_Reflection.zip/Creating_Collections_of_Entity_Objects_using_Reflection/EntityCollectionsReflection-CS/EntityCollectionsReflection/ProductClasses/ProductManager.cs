﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EntityCollectionsReflection
{
  public class ProductManager : ManagerBase
  {
    #region GetProductsDataTable Method
    /// <summary>
    /// This method uses Reflection to create an entity collection using a DataTable
    /// Your Entity class should use nullable types
    /// </summary>
    /// <returns>A List of Product objects</returns>
    public List<Product> GetProductsDataTable()
    {
      DataTable dt = new DataTable();
      SqlDataAdapter da = null;
      List<Product> ret = null;

      da = new SqlDataAdapter("SELECT * FROM Product",
                              AppSettings.Instance.ConnectString);

      da.Fill(dt);

      // Build Collection of Entity Objets using Reflection
      ret = base.BuildCollection<Product>(typeof(Product), dt);

      return ret;
    }
    #endregion

    #region GetProductsDataReader Method
    /// <summary>
    /// This method uses Reflection to create an entity collection using a DataReader
    /// Your Entity class should use nullable types
    /// </summary>
    /// <returns>A List of Product objects</returns>
    public List<Product> GetProductsDataReader()
    {
      SqlCommand cmd = null;
      List<Product> ret = null;

      cmd = new SqlCommand("SELECT * FROM Product");
      using (cmd.Connection = new
              SqlConnection(AppSettings.Instance.ConnectString))
      {
        cmd.Connection.Open();
        using (var rdr = cmd.ExecuteReader())
        {
          // Build Collection of Entity Objets using Reflection
          ret = BuildCollection<Product>(typeof(Product), rdr);
        }
      }

      return ret;
    }
    #endregion
  }
}
