﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;

namespace EntityCollectionsReflection
{
  public class ProductHardCodedManager
  {
    #region GetProducts
    public List<Product> GetProducts()
    {
      SqlCommand cmd = null;
      List<Product> ret = new List<Product>();
      Product entity = null;

      // Get all the properties in Entity Class
      PropertyInfo[] props = typeof(Product).GetProperties();

      cmd = new SqlCommand("SELECT * FROM Product");
      using (cmd.Connection = new
              SqlConnection(AppSettings.Instance.ConnectString))
      {
        cmd.Connection.Open();
        using (var rdr = cmd.ExecuteReader())
        {
          while (rdr.Read())
          {
            // Create new instance of Product Class
            entity = new Product();

            // Set all properties from the column names
            // NOTE: This assumes your column names are the 
            //       same name as your class property names
            foreach (PropertyInfo col in props)
            {
              // The following is the slow method of setting properties
              if (rdr[col.Name] == DBNull.Value)
                typeof(Product).InvokeMember(col.Name, BindingFlags.SetProperty,
                  Type.DefaultBinder, entity, new Object[] { null });
              else
                typeof(Product).InvokeMember(col.Name, BindingFlags.SetProperty,
                  Type.DefaultBinder, entity, new Object[] { rdr[col.Name] });

              if (rdr[col.Name].Equals(DBNull.Value))
                col.SetValue(entity, null, null);
              else
                col.SetValue(entity, rdr[col.Name], null);
            }

            ret.Add(entity);
          }
        }
      }

      return ret;
    }
    #endregion
  }
}
