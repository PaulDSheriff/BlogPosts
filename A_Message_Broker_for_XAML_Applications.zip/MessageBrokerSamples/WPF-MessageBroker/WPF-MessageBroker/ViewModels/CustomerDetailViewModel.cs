﻿using Common.Library;
using WPF_MessageBroker.Entities;

namespace WPF_MessageBroker.ViewModels
{
  public class CustomerDetailViewModel : ViewModelBase
  {
    #region Constructor
    public CustomerDetailViewModel() : base()
    {
      MessageBroker.Instance.MessageReceived += Instance_MessageReceived;
    }
    #endregion

    #region MessageReceived Event
    private void Instance_MessageReceived(object sender, MessageBrokerEventArgs e)
    {
      switch (e.MessageName) {
        case ApplicationMessages.CUSTOMER_DETAIL_CHANGED:
          SelectedItem = ((Customer)e.MessagePayload);
          break;
      }
    }
    #endregion

    #region Properties
    private Customer _SelectedItem;

    public Customer SelectedItem
    {
      get { return _SelectedItem; }
      set {
        _SelectedItem = value;
        RaisePropertyChanged("SelectedItem");
      }
    }
    #endregion

    #region Dispose Method
    public void Dispose()
    {
      MessageBroker.Instance.MessageReceived -= Instance_MessageReceived;
    }
    #endregion
  }
}
