﻿using System.Collections.ObjectModel;
using WPF_MessageBroker.Entities;
using WPF_MessageBroker.Models;
using Common.Library;

namespace WPF_MessageBroker.ViewModels
{
  public class ProductDetailViewModel : ViewModelBase
  {
    #region Constructor
    public ProductDetailViewModel() : base()
    {
      LoadAll();

      // Display name of this component
      MessageBroker.Instance.SendMessage(ApplicationMessages.DISPLAY_STATUS_MESSAGE, "Product List");
    }
    #endregion

    #region Properties
    private ObservableCollection<Product> _DataCollection;
    private Product _SelectedItem;

    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }

    public Product SelectedItem
    {
      get { return _SelectedItem; }
      set {
        _SelectedItem = value;
        RaisePropertyChanged("SelectedItem");
      }
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      ProductManager mgr = new ProductManager();

      DataCollection = new ObservableCollection<Product>(mgr.GetProducts());
      if (DataCollection.Count > 0) {
        SelectedItem = DataCollection[0];
      }
    }
    #endregion
  }
}
