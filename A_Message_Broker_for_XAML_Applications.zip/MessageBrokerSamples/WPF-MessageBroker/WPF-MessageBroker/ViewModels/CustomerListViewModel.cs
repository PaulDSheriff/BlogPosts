﻿using System.Collections.ObjectModel;
using WPF_MessageBroker.Entities;
using WPF_MessageBroker.Models;
using Common.Library;

namespace WPF_MessageBroker.ViewModels
{
  public class CustomerListViewModel : ViewModelBase
  {
    #region Constructor
    public CustomerListViewModel() : base()
    {
      MessageBroker.Instance.SendMessage(ApplicationMessages.DISPLAY_STATUS_MESSAGE, "Customer Information");
    }
    #endregion

    #region Properties
    private ObservableCollection<Customer> _DataCollection;
    private Customer _SelectedItem;

    public ObservableCollection<Customer> DataCollection
    {
      get { return _DataCollection; }
      set {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }

    public Customer SelectedItem
    {
      get { return _SelectedItem; }
      set {
        _SelectedItem = value;
        RaisePropertyChanged("SelectedItem");
        MessageBroker.Instance.SendMessage(ApplicationMessages.CUSTOMER_DETAIL_CHANGED, _SelectedItem);
      }
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      CustomerManager mgr = new CustomerManager();

      DataCollection = new ObservableCollection<Customer>(mgr.GetCustomers());
      if (DataCollection.Count > 0) {
        SelectedItem = DataCollection[0];
      }
    }
    #endregion
  }
}