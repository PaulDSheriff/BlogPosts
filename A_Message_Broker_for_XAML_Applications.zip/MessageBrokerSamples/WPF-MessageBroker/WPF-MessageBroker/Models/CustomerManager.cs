﻿using System.Collections.Generic;
using WPF_MessageBroker.Entities;

namespace WPF_MessageBroker.Models
{
  public class CustomerManager
  {
    #region GetCustomers Method
    public List<Customer> GetCustomers() {
      return new List<Customer> {
        new Customer {
          CustomerId = 1,
          CompanyName= "ABC Company",
          Phone = "(615) 888-1111"
        },
        new Customer {
          CustomerId = 2,
          CompanyName= "XYZ Company",
          Phone = "(615) 999-2222"
        },
        new Customer {
          CustomerId = 3,
          CompanyName= "TTT Company",
          Phone = "(615) 777-3333"
        },
        new Customer {
          CustomerId = 4,
          CompanyName= "RRR Company",
          Phone = "(615) 555-4444"
        }
      };
    }
    #endregion
  }
}
