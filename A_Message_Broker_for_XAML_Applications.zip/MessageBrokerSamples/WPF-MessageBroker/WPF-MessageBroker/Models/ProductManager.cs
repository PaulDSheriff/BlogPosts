﻿using System;
using System.Collections.Generic;
using WPF_MessageBroker.Entities;

namespace WPF_MessageBroker.Models
{
  public class ProductManager
  {
    #region GetProducts Method
    public List<Product> GetProducts()
    {
      return new List<Product> {
        new Product {
          ProductId = 1,
          ProductName = "Product 1 - MOCK",
          IntroductionDate = DateTime.Now,
          Cost = 100,
          Price = 200,
          IsDiscontinued = false
        },
        new Product {
          ProductId = 2,
          ProductName = "Product 2 - MOCK",
          IntroductionDate = DateTime.Now.AddDays(-1),
          Cost = 200,
          Price = 400,
          IsDiscontinued = false
        },
        new Product {
          ProductId = 3,
          ProductName = "Product 3 - MOCK",
          IntroductionDate = DateTime.Now,
          Cost = 300,
          Price = 600,
          IsDiscontinued = false
        },
        new Product {
          ProductId = 4,
          ProductName = "Product 4 - MOCK",
          IntroductionDate = DateTime.Now,
          Cost = 400,
          Price = 800,
          IsDiscontinued = false
        }
      };
    }
    #endregion
  }
}
