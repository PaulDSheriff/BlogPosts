﻿using System.Windows;

namespace WPF_MessageBroker
{
  public partial class App : Application
  {
  }
}
