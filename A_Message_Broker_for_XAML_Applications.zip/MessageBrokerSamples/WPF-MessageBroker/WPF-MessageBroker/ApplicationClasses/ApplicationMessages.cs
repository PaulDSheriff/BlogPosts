﻿using Common.Library;

namespace WPF_MessageBroker
{
  public partial class ApplicationMessages : MessageBrokerMessages
  {
    public const string CUSTOMER_DETAIL_CHANGED = "CustomerDetailChanged";
  }
}
