﻿using Common.Library;

namespace WPF_MessageBroker.Entities
{
  public class Customer : CommonBase
  {
    #region Private Variables
    private int _CustomerId = 0;
    private string _CompanyName = string.Empty;
    private string _Phone = string.Empty;
    #endregion

    #region Public Properties
    public int CustomerId
    {
      get { return _CustomerId; }
      set {
        _CustomerId = value;
        RaisePropertyChanged("CustomerId");
      }
    }

    public string CompanyName
    {
      get { return _CompanyName; }
      set {
        _CompanyName = value;
        RaisePropertyChanged("CompanyName");
      }
    }

    public string Phone
    {
      get { return _Phone; }
      set {
        _Phone = value;
        RaisePropertyChanged("Phone");
      }
    }
    #endregion
  }
}
