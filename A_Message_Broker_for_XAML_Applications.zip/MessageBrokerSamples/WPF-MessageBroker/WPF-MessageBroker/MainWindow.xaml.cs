﻿using System.Windows;
using System.Windows.Controls;
using Common.Library;
using WPF_MessageBroker.UserControls;

namespace WPF_MessageBroker
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();

      // Initialize the Message Broker Events
      MessageBroker.Instance.MessageReceived += Instance_MessageReceived;
    }

    private const string APP_MSG = "Sample of Message Broker";

    private void Instance_MessageReceived(object sender, MessageBrokerEventArgs e)
    {
      switch (e.MessageName) {
        case ApplicationMessages.DISPLAY_STATUS_MESSAGE:
          statusBar.Text = e.MessagePayload.ToString();
          break;

        case ApplicationMessages.DISPLAY_USER_CONTROL:
          contentArea.Children.Clear();
          contentArea.Children.Add((UserControl)e.MessagePayload);
          break;

        case ApplicationMessages.CLOSE_USER_CONTROL:
          contentArea.Children.Clear();
          statusBar.Text = APP_MSG;
          break;
      }
    }

    private void btnProductList_Click(object sender, RoutedEventArgs e)
    {
      ucProductList uc = new ucProductList();

      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }

    private void btnCustomerList_Click(object sender, RoutedEventArgs e)
    {
      ucCustomer uc = new ucCustomer();
      
      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }

    private void btnClose_Click(object sender, RoutedEventArgs e)
    {
      MessageBroker.Instance.SendMessage(ApplicationMessages.CLOSE_USER_CONTROL, null);
    }

    private void Window_Unloaded(object sender, RoutedEventArgs e)
    {
      // Unhook the event handler from the global message broker
      MessageBroker.Instance.MessageReceived -= Instance_MessageReceived;
    }
  }
}