﻿using System.Windows.Controls;
using Common.Library;
using WPF_MessageBroker.ViewModels;

namespace WPF_MessageBroker.UserControls
{
  public partial class ucCustomerDetail : UserControl
  {
    public CustomerDetailViewModel ViewModel { get; set; }

    public ucCustomerDetail()
    {
      InitializeComponent();

      ViewModel = (CustomerDetailViewModel)this.Resources["viewModel"];
    }

    private void btnCancel_Click(object sender, System.Windows.RoutedEventArgs e)
    {
      MessageBroker.Instance.SendMessage(ApplicationMessages.CLOSE_USER_CONTROL, null);
    }

    private void UserControl_Unloaded(object sender, System.Windows.RoutedEventArgs e)
    {
      ViewModel.Dispose();
    }
  }
}
