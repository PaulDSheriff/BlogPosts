﻿using System.Windows;
using System.Windows.Controls;
using Common.Library;
using WPF_MessageBroker.Entities;

namespace WPF_MessageBroker.UserControls
{
  public partial class ucProductList : UserControl
  {
    public ucProductList()
    {
      InitializeComponent();
    }

    private void btnView_Click(object sender, RoutedEventArgs e)
    {
      // Create new Product Detail User Control
      ucProductDetail uc = new ucProductDetail();
      // Get currently selected product
      uc.ViewModel.SelectedItem = ((Product)((Button)sender).Tag);
      // Send message to display this new user control on the main window
      MessageBroker.Instance.SendMessage(ApplicationMessages.DISPLAY_USER_CONTROL, uc);
    }
  }
}
