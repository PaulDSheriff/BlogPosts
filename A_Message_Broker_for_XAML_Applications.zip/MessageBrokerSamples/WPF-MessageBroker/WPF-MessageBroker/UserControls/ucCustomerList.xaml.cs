﻿using System.Windows.Controls;
using WPF_MessageBroker.ViewModels;

namespace WPF_MessageBroker.UserControls
{
  public partial class ucCustomerList : UserControl
  {
    public CustomerListViewModel ViewModel { get; set; }
    public ucCustomerList()
    {
      InitializeComponent();

      ViewModel = (CustomerListViewModel)this.Resources["viewModel"];
    }
  }
}
