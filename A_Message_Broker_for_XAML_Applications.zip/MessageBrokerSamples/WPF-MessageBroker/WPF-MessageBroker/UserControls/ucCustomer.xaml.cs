﻿using System.Windows.Controls;

namespace WPF_MessageBroker.UserControls
{
  public partial class ucCustomer : UserControl
  {
    public ucCustomer()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, System.Windows.RoutedEventArgs e)
    {
      // Load all customers
      // Do this here instead of in the constructor to allow both controls to load before sending the message to update the SelectedItem property
      // Otherwise, the first item selected raises the event before the "Detail" user control has been loaded.
      customerList.ViewModel.LoadAll();
    }
  }
}