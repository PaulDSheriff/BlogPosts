﻿using System.Windows.Controls;
using Common.Library;
using WPF_MessageBroker.Entities;
using WPF_MessageBroker.ViewModels;

namespace WPF_MessageBroker.UserControls
{
  public partial class ucProductDetail : UserControl
  {
    public ProductDetailViewModel ViewModel { get; set; }

    public ucProductDetail()
    {
      InitializeComponent();

      ViewModel = (ProductDetailViewModel)this.Resources["viewModel"];
    }

    public void LoadDetail(Product entity)
    {
      ViewModel.SelectedItem = entity;
    }

    private void btnCancel_Click(object sender, System.Windows.RoutedEventArgs e)
    {
      MessageBroker.Instance.SendMessage(ApplicationMessages.CLOSE_USER_CONTROL, null);
    }

    private void UserControl_Loaded(object sender, System.Windows.RoutedEventArgs e)
    {
      MessageBroker.Instance.SendMessage(ApplicationMessages.DISPLAY_STATUS_MESSAGE, "View Product Detail");
    }
  }
}
