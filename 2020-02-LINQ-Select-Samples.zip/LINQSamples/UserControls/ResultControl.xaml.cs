﻿using System.Windows;
using System.Windows.Controls;
using Common.Library;

namespace LINQSamples.UserControls
{
  public partial class ResultControl : UserControl
  {
    public ResultControl()
    {
      InitializeComponent();
    }

    private ViewModelBase _viewModel = null;

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      _viewModel = (ViewModelBase)this.DataContext;
    }
  }
}
