﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class SelectControl : UserControl
  {
    public SelectControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (SelectViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly SelectViewModel _viewModel = null;

    private void GetAllLooping_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetAllLooping();
    }

    private void GetAll_Click(object sender, System.Windows.RoutedEventArgs e)
    {
      _viewModel.GetAll();
    }
    
    private void GetSpecific_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetSpecificColumns();
    }

    private void Anonymous_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.AnonymousClass();
    }
  }
}
