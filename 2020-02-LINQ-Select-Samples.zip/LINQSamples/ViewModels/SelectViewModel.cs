﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.Library;
using LINQSamples.EntityClasses;

namespace LINQSamples.ViewModels
{
  public class SelectViewModel : ViewModelBase
  {
    #region GetAllLooping
    /// <summary>
    /// Put all products into a collection via looping
    /// </summary>
    public void GetAllLooping()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      LoadProductsCollection();

      List<Product> list = new List<Product>();

      foreach (Product item in Products) {
        list.Add(item);
      }

      ResultText = $"Total Products: {list.Count}";
    }
    #endregion

    #region GetAll
    /// <summary>
    /// Put all products into a collection using LINQ
    /// </summary>
    public void GetAll()
    {
      System.Diagnostics.Debugger.Break();
      
      List<Product> list;

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        list = (from prod in Products
                    select prod).ToList();
      }
      else {
        // Method Syntax
        list = Products.Select(prod => prod).ToList();
      }

      ResultText = $"Total Products: {list.Count}";
    }
    #endregion

    #region GetSpecificColumns
    /// <summary>
    /// Select a few specific properties from products
    /// </summary>
    public void GetSpecificColumns()
    {
      System.Diagnostics.Debugger.Break();

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    select new Product
                    {
                      ProductID = prod.ProductID,
                      Name = prod.Name,
                      ProductNumber = prod.ProductNumber
                    }).ToList();
      }
      else {
        // Method Syntax
        Products = Products.Select(prod => new Product
        {
          ProductID = prod.ProductID,
          Name = prod.Name,
          ProductNumber = prod.ProductNumber
        }).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Anonymous Class
    /// <summary>
    /// Create an anonymous class from selected product properties
    /// </summary>
    public void AnonymousClass()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(2048);

      // Load all Product Data
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        var products = (from prod in Products
                        select new
                        {
                          ProductId = prod.ProductID,
                          ProductName = prod.Name,
                          Identifier = prod.ProductNumber,
                          ProductSize = prod.Size
                        });

        // Loop through anonymous class
        foreach (var prod in products) {
          sb.AppendLine($"ProductId: {prod.ProductId}");
          sb.AppendLine($"    ProductName: {prod.ProductName}");
          sb.AppendLine($"    Identifier: {prod.Identifier}");
          sb.AppendLine($"    ProductSize: {prod.ProductSize}");
        }
      }
      else {
        // Method Syntax
        var products = Products.Select(prod => new
        {
          ProductId = prod.ProductID,
          ProductName = prod.Name,
          Identifier = prod.ProductNumber,
          ProductSize = prod.Size
        });

        // Loop through anonymous class
        foreach (var prod in products) {
          sb.AppendLine($"ProductId: {prod.ProductId}");
          sb.AppendLine($"    ProductName: {prod.ProductName}");
          sb.AppendLine($"    Identifier: {prod.Identifier}");
          sb.AppendLine($"    ProductSize: {prod.ProductSize}");
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion
  }
}
