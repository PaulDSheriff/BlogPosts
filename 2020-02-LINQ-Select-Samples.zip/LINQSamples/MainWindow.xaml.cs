﻿using System.Windows;

namespace LINQSamples
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Exit_Click(object sender, RoutedEventArgs e)
    {
      this.Close();
    }

    private void Select_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new SelectControl());
    }
  }
}
