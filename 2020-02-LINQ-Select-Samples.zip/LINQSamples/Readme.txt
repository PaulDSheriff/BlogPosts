﻿Select
-----------------------------------------------
GetAll By Looping
GetAll
Specific Columns
Anonymous Class

Resources
----------------------------------------------------
https://docs.microsoft.com/en-us/dotnet/csharp/linq/